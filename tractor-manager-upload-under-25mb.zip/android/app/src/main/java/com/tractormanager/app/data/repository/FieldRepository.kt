package com.tractormanager.app.data.repository

import com.tractormanager.app.core.AreaResult
import com.tractormanager.app.core.AreaUnits
import com.tractormanager.app.core.Ids
import com.tractormanager.app.core.PointsCodec
import com.tractormanager.app.core.ValidationFailureException
import com.tractormanager.app.core.Validators
import com.tractormanager.app.core.geo.GeoPoint
import com.tractormanager.app.data.local.FarmerDao
import com.tractormanager.app.data.local.LandField
import com.tractormanager.app.data.local.LandFieldDao
import kotlinx.coroutines.flow.Flow

data class LandFieldInput(
    val farmerId: String,
    val name: String,
    val village: String,
    val points: List<GeoPoint>,
    val notes: String
)

class FieldRepository(
    private val landFieldDao: LandFieldDao,
    private val farmerDao: FarmerDao
) {

    fun observeByFarmer(farmerId: String): Flow<List<LandField>> =
        landFieldDao.observeByFarmer(farmerId)

    fun observeAllActive(): Flow<List<LandField>> = landFieldDao.observeAllActive()

    fun observeField(id: String): Flow<LandField?> = landFieldDao.observeById(id)

    suspend fun getField(id: String): LandField? = landFieldDao.getById(id)

    suspend fun getFieldsForFarmer(farmerId: String): List<LandField> =
        landFieldDao.getActiveByFarmer(farmerId)

    suspend fun countForFarmer(farmerId: String): Int = landFieldDao.countByFarmer(farmerId)

    fun pointsOf(field: LandField): List<GeoPoint> = PointsCodec.decode(field.pointsJson)

    fun measure(points: List<GeoPoint>): AreaResult = AreaUnits.measure(points)

    suspend fun saveField(id: String?, input: LandFieldInput): Result<String> {
        val farmer = farmerDao.getById(input.farmerId)
            ?: return Result.failure(IllegalStateException("शेतकरी सापडला नाही."))
        if (farmer.isDeleted) {
            return Result.failure(IllegalStateException("हा शेतकरी हटवलेला आहे."))
        }

        val area = AreaUnits.measure(input.points)
        val validation = Validators.landField(
            name = input.name,
            points = input.points,
            areaSqm = area.squareMeters,
            village = input.village
        )
        if (!validation.isValid) return Result.failure(ValidationFailureException(validation))

        val now = System.currentTimeMillis()
        return runCatching {
            if (id == null) {
                val newId = Ids.newId()
                landFieldDao.insert(
                    LandField(
                        id = newId,
                        farmerId = input.farmerId,
                        name = input.name.trim(),
                        village = input.village.trim(),
                        pointsJson = PointsCodec.encode(input.points),
                        areaSqm = area.squareMeters,
                        areaAcres = area.acres,
                        areaGuntha = area.guntha,
                        areaHectares = area.hectares,
                        notes = input.notes.trim(),
                        createdAt = now,
                        updatedAt = now
                    )
                )
                newId
            } else {
                val existing = landFieldDao.getById(id)
                    ?: throw IllegalStateException("जमीन सापडली नाही.")
                landFieldDao.update(
                    existing.copy(
                        farmerId = input.farmerId,
                        name = input.name.trim(),
                        village = input.village.trim(),
                        pointsJson = PointsCodec.encode(input.points),
                        areaSqm = area.squareMeters,
                        areaAcres = area.acres,
                        areaGuntha = area.guntha,
                        areaHectares = area.hectares,
                        notes = input.notes.trim(),
                        updatedAt = now
                    )
                )
                id
            }
        }
    }

    suspend fun deleteField(id: String): Result<Unit> = runCatching {
        landFieldDao.softDelete(id, System.currentTimeMillis())
    }
}
