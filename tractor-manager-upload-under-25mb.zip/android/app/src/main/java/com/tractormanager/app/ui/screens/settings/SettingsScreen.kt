package com.tractormanager.app.ui.screens.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.FileDownload
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.core.Money
import com.tractormanager.app.core.NumberText
import com.tractormanager.app.core.Validators
import com.tractormanager.app.data.local.WorkTypeRate
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.AppCard
import com.tractormanager.app.ui.components.AppTextField
import com.tractormanager.app.ui.components.ConfirmDialog
import com.tractormanager.app.ui.components.InfoBanner
import com.tractormanager.app.ui.components.PrimaryButton
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.components.SectionHeader
import com.tractormanager.app.ui.theme.Border
import com.tractormanager.app.ui.theme.Danger
import com.tractormanager.app.ui.theme.Green50
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.InkSoft
import com.tractormanager.app.ui.theme.White

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val viewModel = appViewModel {
        SettingsViewModel(
            it.settingsRepository,
            it.workTypeRepository,
            it.backupRepository,
            it.firebaseSyncRepository
        )
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    var showEnablePin by remember { mutableStateOf(false) }
    var showChangePin by remember { mutableStateOf(false) }
    var showDisablePin by remember { mutableStateOf(false) }
    var showImportConfirm by remember { mutableStateOf(false) }
    var pendingImport by remember { mutableStateOf<Uri?>(null) }

    var url by remember(state.settings.firebaseUrl) { mutableStateOf(state.settings.firebaseUrl) }
    var code by remember(state.settings.syncCode) { mutableStateOf(state.settings.syncCode) }
    var token by remember(state.settings.firebaseToken) { mutableStateOf(state.settings.firebaseToken) }

    var rateDrafts by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    LaunchedEffect(state.workTypes) {
        rateDrafts = state.workTypes.associate { it.id to NumberText.format(it.defaultRate, 2) }
    }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) viewModel.exportBackup(uri)
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            pendingImport = uri
            showImportConfirm = true
        }
    }

    ScreenScaffold(
        title = "सेटिंग्ज",
        subtitle = "सुरक्षा, बॅकअप व दर",
        onBack = onBack,
        snackbarHostState = snackbar
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { SectionHeader(title = "सुरक्षा", subtitle = "ॲपला PIN लावा") }

            item {
                AppCard(containerColor = White) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = Green50,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    Icons.Outlined.Lock,
                                    contentDescription = null,
                                    tint = Green700,
                                    modifier = Modifier
                                        .padding(9.dp)
                                        .size(22.dp)
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "PIN लॉक",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = Green900
                                )
                                Text(
                                    if (state.settings.hasPin) "PIN लागू आहे" else "PIN लावलेला नाही",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = InkSoft
                                )
                            }
                            if (state.settings.hasPin) {
                                Switch(
                                    checked = state.settings.pinEnabled,
                                    onCheckedChange = viewModel::setPinLockEnabled
                                )
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        if (state.settings.hasPin) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedButton(
                                    onClick = { showChangePin = true },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text("PIN बदला", color = Green700)
                                }
                                OutlinedButton(
                                    onClick = { showDisablePin = true },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text("PIN काढा", color = Danger)
                                }
                            }
                        } else {
                            PrimaryButton(
                                text = "PIN लावा",
                                onClick = { showEnablePin = true },
                                icon = Icons.Outlined.Lock
                            )
                        }
                    }
                }
            }

            item { SectionHeader(title = "बॅकअप व पुनर्संचयित", subtitle = "सर्व माहिती सुरक्षित ठेवा") }

            item {
                AppCard(containerColor = White) {
                    Column {
                        InfoBanner(
                            "बॅकअप फाईलमध्ये शेतकरी, जमीन, कामे व जमा नोंदी या सर्व गोष्टी असतात. " +
                                "तुम्ही ती फोनमध्ये किंवा Google Drive वर जतन करू शकता."
                        )
                        Spacer(Modifier.height(12.dp))
                        PrimaryButton(
                            text = "बॅकअप जतन करा",
                            onClick = {
                                exportLauncher.launch(
                                    "tractor_manager_backup_${DateUtils.fileStamp()}.json"
                                )
                            },
                            icon = Icons.Outlined.FileDownload
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                importLauncher.launch(
                                    arrayOf(
                                        "application/json",
                                        "text/plain",
                                        "application/octet-stream"
                                    )
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(
                                Icons.Outlined.FileUpload,
                                contentDescription = null,
                                tint = Green700,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("बॅकअपमधून पुनर्संचयित करा", color = Green700)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "पुनर्संचयित करण्यापूर्वी सध्याचा डेटा स्वयंचलितपणे सुरक्षित केला जातो.",
                            style = MaterialTheme.typography.bodySmall,
                            color = InkSoft
                        )
                    }
                }
            }

            item { SectionHeader(title = "Firebase सिंक", subtitle = "दुसऱ्या फोनशी डेटा जोडा") }

            item {
                AppCard(containerColor = White) {
                    Column {
                        InfoBanner(
                            "Firebase Realtime Database ची URL आणि एक खाजगी सिंक कोड द्या. " +
                                "दोन्ही फोनवर तोच कोड वापरल्यास डेटा एकत्र होतो."
                        )
                        Spacer(Modifier.height(12.dp))
                        AppTextField(
                            value = url,
                            onValueChange = { url = it },
                            label = "Firebase डेटाबेस URL",
                            placeholder = "https://...firebasedatabase.app",
                            keyboardType = KeyboardType.Uri
                        )
                        Spacer(Modifier.height(10.dp))
                        AppTextField(
                            value = code,
                            onValueChange = { code = it },
                            label = "सिंक कोड",
                            placeholder = "उदा. माझे_ट्रॅक्टर_१"
                        )
                        Spacer(Modifier.height(10.dp))
                        AppTextField(
                            value = token,
                            onValueChange = { token = it },
                            label = "Auth टोकन (ऐच्छिक)",
                            placeholder = "आवश्यक असल्यास"
                        )
                        Spacer(Modifier.height(14.dp))
                        PrimaryButton(
                            text = "जतन करून सिंक करा",
                            onClick = { viewModel.saveAndSync(url, code, token) },
                            loading = state.syncing,
                            icon = Icons.Outlined.CloudUpload
                        )
                        Spacer(Modifier.height(4.dp))
                        TextButton(
                            onClick = { viewModel.saveSyncSettings(url, code, token) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                Icons.Outlined.Save,
                                contentDescription = null,
                                tint = Green700,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("फक्त सेटिंग्ज जतन करा", color = Green700)
                        }
                    }
                }
            }

            item { SectionHeader(title = "कामाचे दर", subtitle = "प्रति एकर दर बदला") }

            items(state.workTypes.sortedBy { it.sortOrder }, key = { it.id }) { type ->
                WorkRateCard(
                    type = type,
                    draft = rateDrafts[type.id].orEmpty(),
                    onDraftChange = { value ->
                        rateDrafts = rateDrafts + (type.id to value)
                    },
                    onSave = {
                        viewModel.updateRate(type.id, rateDrafts[type.id]?.toDoubleOrNull())
                    }
                )
            }

            item {
                Text(
                    "ट्रॅक्टर मॅनेजर • आवृत्ती १.०.०",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSoft
                )
            }
        }
    }

    if (showEnablePin) {
        PinDialog(
            title = "PIN लावा",
            requireCurrent = false,
            requireConfirm = true,
            onDismiss = { showEnablePin = false },
            onConfirm = { _, pin ->
                viewModel.enablePin(pin)
                showEnablePin = false
            }
        )
    }

    if (showChangePin) {
        PinDialog(
            title = "PIN बदला",
            requireCurrent = true,
            requireConfirm = true,
            onDismiss = { showChangePin = false },
            onConfirm = { current, pin ->
                viewModel.changePin(current, pin)
                showChangePin = false
            }
        )
    }

    if (showDisablePin) {
        PinDialog(
            title = "PIN काढा",
            requireCurrent = true,
            requireConfirm = false,
            confirmLabel = "PIN काढा",
            destructive = true,
            onDismiss = { showDisablePin = false },
            onConfirm = { current, _ ->
                viewModel.disablePin(current)
                showDisablePin = false
            }
        )
    }

    if (showImportConfirm) {
        ConfirmDialog(
            title = "बॅकअप पुनर्संचयित करायचा?",
            message = "सध्याचा डेटा सुरक्षित बॅकअप घेऊन निवडलेल्या फाईलमधील डेटासोबत एकत्र केला जाईल.",
            confirmLabel = "पुनर्संचयित करा",
            onConfirm = {
                showImportConfirm = false
                pendingImport?.let(viewModel::importBackup)
                pendingImport = null
            },
            onDismiss = {
                showImportConfirm = false
                pendingImport = null
            }
        )
    }
}

@Composable
private fun WorkRateCard(
    type: WorkTypeRate,
    draft: String,
    onDraftChange: (String) -> Unit,
    onSave: () -> Unit
) {
    AppCard(contentPadding = PaddingValues(12.dp), containerColor = White) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    type.name,
                    style = MaterialTheme.typography.titleSmall,
                    color = Green900
                )
                Text(
                    "सध्याचा दर: ${Money.format(type.defaultRate)} / एकर",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSoft
                )
            }
            OutlinedTextField(
                value = draft,
                onValueChange = { text ->
                    onDraftChange(text.filter { it.isDigit() || it == '.' })
                },
                modifier = Modifier.width(108.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Green700,
                    unfocusedBorderColor = Border
                )
            )
            IconButton(onClick = onSave) {
                Icon(
                    Icons.Outlined.Check,
                    contentDescription = "दर जतन करा",
                    tint = Green700
                )
            }
        }
    }
}

@Composable
private fun PinDialog(
    title: String,
    requireCurrent: Boolean,
    requireConfirm: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (current: String, pin: String) -> Unit,
    confirmLabel: String = "जतन करा",
    destructive: Boolean = false
) {
    var current by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    val validation = Validators.pin(pin, if (requireConfirm) confirm else null)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                if (requireCurrent) {
                    AppTextField(
                        value = current,
                        onValueChange = { current = it.filter(Char::isDigit).take(6) },
                        label = "सध्याचा PIN",
                        keyboardType = KeyboardType.NumberPassword
                    )
                    Spacer(Modifier.height(10.dp))
                }
                AppTextField(
                    value = pin,
                    onValueChange = { pin = it.filter(Char::isDigit).take(6) },
                    label = if (requireCurrent) "नवीन PIN" else "PIN (४ ते ६ अंक)",
                    keyboardType = KeyboardType.NumberPassword,
                    error = if (pin.isNotEmpty()) validation.error("pin") else null
                )
                if (requireConfirm) {
                    Spacer(Modifier.height(10.dp))
                    AppTextField(
                        value = confirm,
                        onValueChange = { confirm = it.filter(Char::isDigit).take(6) },
                        label = "नवीन PIN पुन्हा द्या",
                        keyboardType = KeyboardType.NumberPassword,
                        error = if (confirm.isNotEmpty()) validation.error("confirmPin") else null
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val check = Validators.pin(pin, if (requireConfirm) confirm else null)
                    if (requireCurrent && current.isBlank()) return@TextButton
                    if (check.isValid) onConfirm(current, pin)
                }
            ) {
                Text(confirmLabel, color = if (destructive) Danger else Green700)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करा", color = InkSoft)
            }
        },
        containerColor = White,
        shape = RoundedCornerShape(20.dp)
    )
}
