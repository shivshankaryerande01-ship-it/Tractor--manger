package com.tractormanager.app.data.remote

import com.tractormanager.app.BuildConfig
import com.tractormanager.app.data.backup.BackupCodec
import com.tractormanager.app.data.backup.BackupPayload
import com.tractormanager.app.data.backup.BackupRepository
import com.tractormanager.app.data.backup.DataMerger
import com.tractormanager.app.data.repository.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.util.concurrent.TimeUnit

data class SyncOutcome(
    val farmerCount: Int,
    val fieldCount: Int,
    val workCount: Int,
    val paymentCount: Int
)

/**
 * Firebase Realtime Database sync over its REST API. No google-services.json is
 * required, so the app always builds; the database URL and a household sync code
 * are configured in Settings. The optional legacy token is appended as ?auth=.
 */
class FirebaseSyncRepository(
    private val settingsRepository: SettingsRepository,
    private val backupRepository: BackupRepository
) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun sync(): Result<SyncOutcome> = withContext(Dispatchers.IO) {
        runCatching {
            val settings = settingsRepository.current()
            val url = settings.firebaseUrl.ifBlank { BuildConfig.FIREBASE_DB_URL }
            require(url.startsWith("https://")) { "Firebase डेटाबेस URL सेटिंग्जमध्ये द्या." }
            require(settings.syncCode.isNotBlank()) { "सिंक कोड सेटिंग्जमध्ये द्या." }

            val endpoint = buildEndpoint(url, settings.syncCode, settings.firebaseToken)
            val remotePayload = download(endpoint)
            val localPayload = backupRepository.buildCurrentPayload()
            val merged = if (remotePayload == null) {
                localPayload
            } else {
                DataMerger.merge(localPayload, remotePayload)
            }

            backupRepository.createSafetyBackup("sync")
            backupRepository.applySnapshot(merged)
            upload(endpoint, merged)

            SyncOutcome(
                farmerCount = merged.farmers.count { !it.isDeleted },
                fieldCount = merged.fields.count { !it.isDeleted },
                workCount = merged.workRecords.count { !it.isDeleted },
                paymentCount = merged.payments.count { !it.isDeleted }
            )
        }
    }

    private fun buildEndpoint(baseUrl: String, syncCode: String, token: String): String {
        val base = baseUrl.trim().trimEnd('/')
        val code = java.net.URLEncoder.encode(syncCode.trim(), "UTF-8")
        val path = "$base/tractor_manager/$code.json"
        val parsed = path.toHttpUrlOrNull()
            ?: throw IllegalArgumentException("Firebase URL योग्य नाही.")
        val builder = parsed.newBuilder()
        if (token.isNotBlank()) builder.addQueryParameter("auth", token)
        return builder.build().toString()
    }

    private fun download(endpoint: String): BackupPayload? {
        val request = Request.Builder().url(endpoint).get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Firebase वाचन अयशस्वी (HTTP ${response.code}).")
            }
            val body = response.body?.string().orEmpty()
            if (body.isBlank() || body == "null") return null
            return BackupCodec.decode(body).getOrElse {
                throw IllegalStateException("Firebase वरचा डेटा वाचता आला नाही: ${it.message}")
            }
        }
    }

    private fun upload(endpoint: String, payload: BackupPayload) {
        val json = BackupCodec.encode(payload)
        val request = Request.Builder()
            .url(endpoint)
            .put(json.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Firebase वर बॅकअप जतन झाला नाही (HTTP ${response.code}).")
            }
        }
    }
}
