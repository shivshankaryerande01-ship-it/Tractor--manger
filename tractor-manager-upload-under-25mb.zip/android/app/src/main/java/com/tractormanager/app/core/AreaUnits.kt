package com.tractormanager.app.core

import com.tractormanager.app.core.geo.GeoAreaCalculator
import com.tractormanager.app.core.geo.GeoPoint
import java.math.BigDecimal
import java.math.RoundingMode

object AreaUnits {
    const val SQUARE_METERS_PER_ACRE = 4046.8564224
    const val SQUARE_METERS_PER_HECTARE = 10_000.0
    const val GUNTHA_PER_ACRE = 40.0

    fun acresFromSquareMeters(squareMeters: Double): Double =
        if (squareMeters <= 0) 0.0 else squareMeters / SQUARE_METERS_PER_ACRE

    fun gunthaFromAcres(acres: Double): Double = acres * GUNTHA_PER_ACRE

    fun hectaresFromSquareMeters(squareMeters: Double): Double =
        if (squareMeters <= 0) 0.0 else squareMeters / SQUARE_METERS_PER_HECTARE

    fun result(squareMeters: Double): AreaResult {
        val acres = acresFromSquareMeters(squareMeters)
        return AreaResult(
            squareMeters = squareMeters,
            acres = acres,
            guntha = gunthaFromAcres(acres),
            hectares = hectaresFromSquareMeters(squareMeters)
        )
    }

    fun measure(points: List<GeoPoint>): AreaResult =
        result(GeoAreaCalculator.areaSquareMeters(points))
}

data class AreaResult(
    val squareMeters: Double,
    val acres: Double,
    val guntha: Double,
    val hectares: Double
) {
    val isMeasurable: Boolean get() = acres > 0.0001
}

object Money {
    private val TWO = BigDecimal("2")

    fun round(value: Double): Double =
        BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP).toDouble()

    fun multiply(acres: Double, ratePerAcre: Double): Double =
        BigDecimal.valueOf(acres)
            .multiply(BigDecimal.valueOf(ratePerAcre))
            .setScale(2, RoundingMode.HALF_UP)
            .toDouble()

    fun format(value: Double): String {
        val rounded = BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP)
        val negative = rounded.signum() < 0
        val absolute = rounded.abs()
        val integerPart = absolute.toBigInteger().toString()
        val fraction = absolute.subtract(BigDecimal(absolute.toBigInteger()))
            .setScale(2, RoundingMode.HALF_UP)
            .toPlainString()
            .substringAfter('.')
            .trimEnd('0')
        val grouped = groupIndian(integerPart)
        val body = if (fraction.isEmpty()) grouped else "$grouped.$fraction"
        return if (negative) "-₹$body" else "₹$body"
    }

    fun formatPlain(value: Double): String = format(value).removePrefix("₹")

    private fun groupIndian(digits: String): String {
        if (digits.length <= 3) return digits
        val lastThree = digits.takeLast(3)
        var rest = digits.dropLast(3)
        val groups = mutableListOf<String>()
        while (rest.length > 2) {
            groups.add(0, rest.takeLast(2))
            rest = rest.dropLast(2)
        }
        if (rest.isNotEmpty()) groups.add(0, rest)
        return groups.joinToString(",") + "," + lastThree
    }

    fun parse(text: String): Double? {
        val cleaned = text.trim().replace("₹", "").replace(",", "")
        if (cleaned.isEmpty()) return null
        return cleaned.toDoubleOrNull()?.takeIf { it.isFinite() && it >= 0 }
    }
}

object NumberText {
    fun format(value: Double, decimals: Int = 2): String {
        if (!value.isFinite()) return "0"
        var text = BigDecimal.valueOf(value)
            .setScale(decimals, RoundingMode.HALF_UP)
            .stripTrailingZeros()
            .toPlainString()
        if (text.contains('.')) {
            text = text.trimEnd('0').trimEnd('.')
        }
        return if (text.isEmpty()) "0" else text
    }

    fun acres(value: Double): String = "${format(value, 3)} एकर"

    fun areaLine(acres: Double, guntha: Double, hectares: Double): String =
        "${format(acres, 3)} एकर • ${format(guntha, 1)} गुंठे • ${format(hectares, 3)} हेक्टर"
}
