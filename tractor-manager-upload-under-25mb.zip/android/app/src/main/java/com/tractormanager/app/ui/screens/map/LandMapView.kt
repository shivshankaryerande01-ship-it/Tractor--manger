package com.tractormanager.app.ui.screens.map

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.tractormanager.app.core.geo.GeoPoint
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.tilesource.TileSourcePolicy
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.GeoPoint as OsmGeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon

private class EsriSatelliteTileSource : XYTileSource(
    "EsriWorldImagery",
    3,
    19,
    256,
    ".jpg",
    arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"),
    "© Esri, Maxar, Earthstar Geographics",
    TileSourcePolicy(
        4,
        TileSourcePolicy.FLAG_NO_BULK or TileSourcePolicy.FLAG_USER_AGENT_MEANINGFUL
    )
) {
    override fun getTileURLString(pMapTileIndex: Long): String {
        val zoom = MapTileIndex.getZoom(pMapTileIndex)
        val x = MapTileIndex.getX(pMapTileIndex)
        val y = MapTileIndex.getY(pMapTileIndex)
        return "${baseUrl}$zoom/$y/$x.jpg"
    }
}

private val satelliteSource = EsriSatelliteTileSource()

@SuppressLint("ClickableViewAccessibility")
@Composable
fun LandMapView(
    points: List<GeoPoint>,
    currentLocation: GeoPoint?,
    initialCenter: GeoPoint,
    initialZoom: Double,
    cameraTarget: MapCameraTarget?,
    satellite: Boolean,
    selectedPointIndex: Int?,
    onMapTap: (GeoPoint) -> Unit,
    onPointMoved: (Int, GeoPoint) -> Unit,
    onPointClick: (Int) -> Unit,
    onMapReady: (MapView) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val tapCallback by rememberUpdatedState(onMapTap)
    val moveCallback by rememberUpdatedState(onPointMoved)
    val pointClickCallback by rememberUpdatedState(onPointClick)
    val readyCallback by rememberUpdatedState(onMapReady)
    var lastCameraId by remember { mutableIntStateOf(0) }
    var lastOverlaySignature by remember { mutableStateOf("") }
    val appliedSatellite = remember { arrayOfNulls<Boolean>(1) }

    val mapView = remember {
        MapView(context).apply {
            setTileSource(satelliteSource)
            setMultiTouchControls(true)
            setTilesScaledToDpi(false)
            setUseDataConnection(true)
            minZoomLevel = 3.0
            maxZoomLevel = 19.0
            controller.setZoom(initialZoom)
            controller.setCenter(OsmGeoPoint(initialCenter.latitude, initialCenter.longitude))
            setMapOrientation(0f)
        }
    }

    val eventsOverlay = remember(mapView) {
        MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: OsmGeoPoint?): Boolean {
                if (p != null) {
                    tapCallback(GeoPoint(p.latitude, p.longitude))
                }
                return true
            }

            override fun longPressHelper(p: OsmGeoPoint?): Boolean = false
        })
    }

    DisposableEffect(lifecycleOwner, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        mapView.onResume()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            mapView.onPause()
            mapView.onDetach()
        }
    }

    Box(modifier) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { _ ->
                mapView.setOnTouchListener { view, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE ->
                            view.parent?.requestDisallowInterceptTouchEvent(true)
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                            view.parent?.requestDisallowInterceptTouchEvent(false)
                    }
                    false
                }
                readyCallback(mapView)
                mapView
            },
            update = { map ->
                if (appliedSatellite[0] != satellite) {
                    appliedSatellite[0] = satellite
                    map.setTileSource(if (satellite) satelliteSource else TileSourceFactory.MAPNIK)
                    map.invalidate()
                }

                val signature = buildString {
                    append(points.joinToString(";") { "${it.latitude},${it.longitude}" })
                    append("|")
                    append(currentLocation?.latitude)
                    append(",")
                    append(currentLocation?.longitude)
                    append("|")
                    append(selectedPointIndex)
                }
                if (signature != lastOverlaySignature) {
                    lastOverlaySignature = signature
                    map.overlays.clear()
                    map.overlays.add(eventsOverlay)

                    if (points.size >= 2) {
                        val polygon = Polygon(map).apply {
                            this.points = points.map { OsmGeoPoint(it.latitude, it.longitude) }
                            fillColor = Color.argb(55, 46, 125, 50)
                            strokeColor = Color.rgb(46, 125, 50)
                            strokeWidth = 4f
                        }
                        map.overlays.add(polygon)
                    }

                    points.forEachIndexed { index, point ->
                        val marker = Marker(map).apply {
                            position = OsmGeoPoint(point.latitude, point.longitude)
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                            icon = vertexDrawable(context, index + 1, index == selectedPointIndex)
                            isDraggable = true
                            setOnMarkerClickListener { _, _ ->
                                pointClickCallback(index)
                                true
                            }
                            setOnMarkerDragListener(object : Marker.OnMarkerDragListener {
                                override fun onMarkerDragStart(marker: Marker) = Unit
                                override fun onMarkerDrag(marker: Marker) = Unit
                                override fun onMarkerDragEnd(marker: Marker) {
                                    val position = marker.position
                                    if (position != null) {
                                        moveCallback(
                                            index,
                                            GeoPoint(position.latitude, position.longitude)
                                        )
                                    }
                                }
                            })
                        }
                        map.overlays.add(marker)
                    }

                    currentLocation?.let { location ->
                        val marker = Marker(map).apply {
                            position = OsmGeoPoint(location.latitude, location.longitude)
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                            icon = currentLocationDrawable(context)
                            setOnMarkerClickListener { _, _ -> true }
                        }
                        map.overlays.add(marker)
                    }
                    map.invalidate()
                }

                val target = cameraTarget
                if (target != null && target.id != lastCameraId) {
                    lastCameraId = target.id
                    map.controller.animateTo(
                        OsmGeoPoint(target.point.latitude, target.point.longitude),
                        target.zoom,
                        700L
                    )
                }
            }
        )
    }
}

private fun vertexDrawable(context: android.content.Context, number: Int, selected: Boolean): Drawable {
    val density = context.resources.displayMetrics.density
    val size = ((if (selected) 48 else 42) * density).toInt().coerceAtLeast(32)
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    val center = size / 2f
    val radius = center - 7f * density

    paint.style = Paint.Style.FILL
    paint.color = if (selected) Color.rgb(230, 126, 0) else Color.rgb(46, 125, 50)
    canvas.drawCircle(center, center, radius, paint)
    paint.style = Paint.Style.STROKE
    paint.strokeWidth = (if (selected) 3f else 2f) * density
    paint.color = Color.WHITE
    canvas.drawCircle(center, center, radius, paint)

    paint.style = Paint.Style.FILL
    paint.color = Color.WHITE
    paint.textAlign = Paint.Align.CENTER
    paint.textSize = (if (selected) 14f else 12f) * density
    paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    val metrics = paint.fontMetrics
    val textY = center - (metrics.ascent + metrics.descent) / 2f
    canvas.drawText(number.toString(), center, textY, paint)

    return BitmapDrawable(context.resources, bitmap)
}

private fun currentLocationDrawable(context: android.content.Context): Drawable {
    val density = context.resources.displayMetrics.density
    val size = (26 * density).toInt().coerceAtLeast(20)
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    val center = size / 2f

    paint.style = Paint.Style.FILL
    paint.color = Color.argb(55, 21, 101, 192)
    canvas.drawCircle(center, center, center, paint)
    paint.color = Color.rgb(21, 101, 192)
    canvas.drawCircle(center, center, center * 0.55f, paint)
    paint.style = Paint.Style.STROKE
    paint.strokeWidth = 2.5f * density
    paint.color = Color.WHITE
    canvas.drawCircle(center, center, center * 0.55f, paint)

    return BitmapDrawable(context.resources, bitmap)
}
