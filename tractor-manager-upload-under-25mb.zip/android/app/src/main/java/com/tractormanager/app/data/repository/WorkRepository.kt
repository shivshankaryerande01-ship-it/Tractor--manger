package com.tractormanager.app.data.repository

import com.tractormanager.app.core.DuplicateRecordException
import com.tractormanager.app.core.Ids
import com.tractormanager.app.core.ValidationFailureException
import com.tractormanager.app.core.Validators
import com.tractormanager.app.data.local.FarmerDao
import com.tractormanager.app.data.local.LandFieldDao
import com.tractormanager.app.data.local.WorkRecord
import com.tractormanager.app.data.local.WorkRecordDao
import com.tractormanager.app.data.local.WorkRecordRow
import com.tractormanager.app.data.local.WorkTotals
import com.tractormanager.app.domain.BillingCalculator
import kotlinx.coroutines.flow.Flow

class WorkRepository(
    private val workRecordDao: WorkRecordDao,
    private val farmerDao: FarmerDao,
    private val landFieldDao: LandFieldDao
) {

    fun observeAll(): Flow<List<WorkRecordRow>> = workRecordDao.observeAll()

    fun observeBetween(startDay: Long, endDay: Long): Flow<List<WorkRecordRow>> =
        workRecordDao.observeBetween(startDay, endDay)

    fun observeByFarmer(farmerId: String): Flow<List<WorkRecordRow>> =
        workRecordDao.observeByFarmer(farmerId)

    fun observeRecent(limit: Int = 5): Flow<List<WorkRecordRow>> =
        workRecordDao.observeRecent(limit)

    fun observeTotals(startDay: Long, endDay: Long): Flow<WorkTotals> =
        workRecordDao.observeTotals(startDay, endDay)

    suspend fun getForFarmer(farmerId: String): List<WorkRecord> =
        workRecordDao.getForFarmer(farmerId)

    suspend fun saveWork(
        id: String?,
        farmerId: String,
        fieldId: String,
        workTypeId: String,
        workTypeName: String,
        dateEpochDay: Long,
        acres: Double?,
        ratePerAcre: Double?,
        notes: String
    ): Result<String> {
        val validation = Validators.workRecord(
            farmerId = farmerId,
            fieldId = fieldId,
            workType = workTypeName,
            acres = acres,
            rate = ratePerAcre
        )
        if (!validation.isValid) return Result.failure(ValidationFailureException(validation))
        val validAcres = acres ?: return Result.failure(ValidationFailureException(validation))
        val validRate = ratePerAcre ?: return Result.failure(ValidationFailureException(validation))

        val farmer = farmerDao.getById(farmerId)
        if (farmer == null || farmer.isDeleted) {
            return Result.failure(IllegalStateException("शेतकरी सापडला नाही."))
        }
        val field = landFieldDao.getById(fieldId)
        if (field == null || field.isDeleted || field.farmerId != farmerId) {
            return Result.failure(IllegalStateException("निवडलेली जमीन या शेतकऱ्याची नाही."))
        }
        if (dateEpochDay > com.tractormanager.app.core.DateUtils.todayEpochDay() + 1) {
            return Result.failure(IllegalStateException("भविष्यातील तारीख निवडू शकत नाही."))
        }

        val excludeId = id ?: ""
        val duplicate = workRecordDao.countExactDuplicates(
            farmerId = farmerId,
            fieldId = fieldId,
            dateEpochDay = dateEpochDay,
            workTypeId = workTypeId,
            acres = validAcres,
            ratePerAcre = validRate,
            excludeId = excludeId
        )
        if (duplicate > 0) {
            return Result.failure(
                DuplicateRecordException("हेच काम याच तारखेला आधीच नोंदवले आहे. डबल नोंद टाळली.")
            )
        }

        val total = BillingCalculator.total(validAcres, validRate)
        if (total <= 0.0 && validRate > 0.0) {
            return Result.failure(IllegalStateException("एकूण रक्कम तयार झाली नाही. एकर व दर तपासा."))
        }

        val now = System.currentTimeMillis()
        return runCatching {
            if (id == null) {
                val newId = Ids.newId()
                workRecordDao.insert(
                    WorkRecord(
                        id = newId,
                        farmerId = farmerId,
                        fieldId = fieldId,
                        workTypeId = workTypeId,
                        workTypeName = workTypeName.trim(),
                        dateEpochDay = dateEpochDay,
                        acres = validAcres,
                        ratePerAcre = validRate,
                        totalAmount = total,
                        notes = notes.trim(),
                        createdAt = now,
                        updatedAt = now
                    )
                )
                newId
            } else {
                val existing = workRecordDao.getAll().firstOrNull { it.id == id }
                    ?: throw IllegalStateException("कामाची नोंद सापडली नाही.")
                workRecordDao.update(
                    existing.copy(
                        farmerId = farmerId,
                        fieldId = fieldId,
                        workTypeId = workTypeId,
                        workTypeName = workTypeName.trim(),
                        dateEpochDay = dateEpochDay,
                        acres = validAcres,
                        ratePerAcre = validRate,
                        totalAmount = total,
                        notes = notes.trim(),
                        updatedAt = now
                    )
                )
                id
            }
        }
    }

    suspend fun deleteWork(id: String): Result<Unit> = runCatching {
        workRecordDao.softDelete(id, System.currentTimeMillis())
    }
}
