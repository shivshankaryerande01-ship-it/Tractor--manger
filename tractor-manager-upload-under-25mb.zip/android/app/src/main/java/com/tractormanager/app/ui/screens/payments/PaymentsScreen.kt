package com.tractormanager.app.ui.screens.payments

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.core.Money
import com.tractormanager.app.data.local.PaymentRow
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.ConfirmDialog
import com.tractormanager.app.ui.components.DropdownOption
import com.tractormanager.app.ui.components.EmptyState
import com.tractormanager.app.ui.components.LabeledDropdown
import com.tractormanager.app.ui.components.PaymentListCard
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.components.StatusPill
import com.tractormanager.app.ui.theme.Danger
import com.tractormanager.app.ui.theme.Green50
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.InkSoft
import com.tractormanager.app.ui.theme.White
import com.tractormanager.app.util.PdfGenerator
import com.tractormanager.app.util.ShareUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PaymentsScreen(
    onAddPayment: () -> Unit,
    onFarmerClick: (String) -> Unit
) {
    val viewModel = appViewModel {
        PaymentsViewModel(it.farmerRepository, it.paymentRepository, it.reportRepository)
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val pdfGenerator = remember(context) { PdfGenerator(context) }
    var farmerFilter by remember { mutableStateOf("") }
    var deleteId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    fun shareReceipt(row: PaymentRow) {
        if (busy) return
        scope.launch {
            busy = true
            try {
                val bill = viewModel.buildBill(row.payment.farmerId)
                if (bill == null) {
                    snackbar.showSnackbar("पावतीसाठी शेतकरी माहिती सापडली नाही.")
                    return@launch
                }
                val file = withContext(Dispatchers.IO) { pdfGenerator.generateReceipt(bill, row.payment) }
                ShareUtils.sharePdf(
                    context,
                    file,
                    false,
                    "नमस्कार ${bill.farmer.name}, ${Money.format(row.payment.amount)} ची पावती जोडली आहे. — ट्रॅक्टर मॅनेजर"
                )
            } catch (error: Exception) {
                snackbar.showSnackbar(error.message ?: "पावती तयार करता आली नाही.")
            } finally {
                busy = false
            }
        }
    }

    val filterOptions = listOf(DropdownOption("", "सर्व शेतकरी")) + state.farmers.map {
        DropdownOption(it.farmer.id, it.farmer.name, it.farmer.mobile)
    }
    val filtered = remember(state.payments, farmerFilter) {
        if (farmerFilter.isBlank()) state.payments else state.payments.filter { it.payment.farmerId == farmerFilter }
    }
    val filteredReceived = Money.round(filtered.sumOf { it.payment.amount })

    ScreenScaffold(
        title = "पैशाचा हिशोब",
        subtitle = "जमा, बाकी आणि पावत्या",
        snackbarHostState = snackbar,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddPayment,
                containerColor = Green700,
                contentColor = White,
                icon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                text = { Text("पैसे नोंदवा") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Surface(
                    color = Green50,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("एकूण जमा", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                                Text(
                                    Money.format(state.summary.totalReceived),
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = Green900
                                )
                            }
                            StatusPill(state.summary.status)
                        }
                        Spacer(Modifier.height(10.dp))
                        Row {
                            Column(Modifier.weight(1f)) {
                                Text("एकूण बिल", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                                Text(Money.format(state.summary.totalBilled), style = MaterialTheme.typography.titleMedium, color = Green900)
                            }
                            Column(Modifier.weight(1f)) {
                                Text("बाकी", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                                Text(
                                    Money.format(state.summary.outstanding),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Danger
                                )
                            }
                            if (state.summary.advance > 0) {
                                Column(Modifier.weight(1f)) {
                                    Text("जादा जमा", style = MaterialTheme.typography.bodySmall, color = InkSoft)
                                    Text(
                                        Money.format(state.summary.advance),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Green700
                                    )
                                }
                            }
                        }
                    }
                }
            }
            item {
                LabeledDropdown(
                    label = "शेतकरीनुसार पहा",
                    options = filterOptions,
                    selectedId = farmerFilter,
                    onSelected = { farmerFilter = it.id }
                )
            }
            if (!farmerFilter.isBlank()) {
                item {
                    Surface(color = White, shape = RoundedCornerShape(14.dp)) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "या शेतकऱ्याची निवडलेल्या कालावधीतील जमा",
                                style = MaterialTheme.typography.bodySmall,
                                color = InkSoft,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                Money.format(filteredReceived),
                                style = MaterialTheme.typography.titleMedium,
                                color = Green900
                            )
                        }
                    }
                }
            }
            item {
                Text(
                    "पेमेंट इतिहास",
                    style = MaterialTheme.typography.titleMedium,
                    color = Green900,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            if (filtered.isEmpty()) {
                item {
                    EmptyState(
                        title = "पेमेंटची नोंद नाही",
                        message = "अ‍ॅडव्हान्स किंवा आंशिक पेमेंट नोंदवून हिशोब पूर्ण करा.",
                        icon = Icons.Outlined.Payments,
                        actionLabel = "पैसे नोंदवा",
                        onAction = onAddPayment
                    )
                }
            } else {
                items(filtered, key = { it.payment.id }) { row ->
                    PaymentListCard(
                        row = row,
                        onClick = { onFarmerClick(row.payment.farmerId) },
                        trailing = {
                            Row {
                                IconButton(onClick = { shareReceipt(row) }) {
                                    Icon(
                                        Icons.Outlined.ReceiptLong,
                                        contentDescription = "पावती",
                                        tint = Green700
                                    )
                                }
                                IconButton(onClick = { deleteId = row.payment.id }) {
                                    Icon(
                                        Icons.Outlined.Delete,
                                        contentDescription = "हटवा",
                                        tint = Danger
                                    )
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    val pendingDelete = deleteId
    if (pendingDelete != null) {
        ConfirmDialog(
            title = "पेमेंट नोंद हटवायची?",
            message = "हे पेमेंट हटवल्यावर शेतकऱ्याची जमा रक्कम कमी होईल आणि बाकी वाढेल.",
            confirmLabel = "हटवा",
            destructive = true,
            onConfirm = {
                viewModel.deletePayment(pendingDelete)
                deleteId = null
            },
            onDismiss = { deleteId = null }
        )
    }
}
