package com.tractormanager.app.data.repository

import com.tractormanager.app.data.local.WorkTypeDao
import com.tractormanager.app.data.local.WorkTypeRate
import kotlinx.coroutines.flow.Flow

class WorkTypeRepository(private val dao: WorkTypeDao) {

    fun observeAll(): Flow<List<WorkTypeRate>> = dao.observeAll()

    suspend fun getAll(): List<WorkTypeRate> = dao.getAll()

    suspend fun updateRate(id: String, rate: Double): Result<Unit> = runCatching {
        val current = dao.getAll().firstOrNull { it.id == id }
            ?: throw IllegalStateException("कामाचा प्रकार सापडला नाही.")
        if (rate < 0 || rate > 1_000_000) {
            throw IllegalArgumentException("दर योग्य नाही.")
        }
        dao.update(current.copy(defaultRate = com.tractormanager.app.core.Money.round(rate)))
    }
}
