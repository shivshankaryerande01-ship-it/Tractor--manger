package com.tractormanager.app.ui.screens.lock

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Agriculture
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.tractormanager.app.ui.components.ErrorBanner
import com.tractormanager.app.ui.components.PrimaryButton
import com.tractormanager.app.ui.theme.Cloud
import com.tractormanager.app.ui.theme.Green50
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.Ink
import com.tractormanager.app.ui.theme.InkSoft
import com.tractormanager.app.ui.theme.White
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PinLockScreen(
    verifyPin: suspend (String) -> Boolean,
    onUnlocked: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    var attempts by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    fun submit() {
        if (checking) return
        if (pin.length < 4) {
            error = "४ ते ६ अंकांचा PIN टाका."
            return
        }
        checking = true
        error = null
        scope.launch {
            val valid = withContext(Dispatchers.Default) { verifyPin(pin) }
            checking = false
            if (valid) {
                onUnlocked()
            } else {
                attempts += 1
                error = if (attempts >= 3) {
                    "PIN चुकीचा आहे. ३ वेळा चुकल्यास PIN तपासा."
                } else {
                    "PIN चुकीचा आहे. पुन्हा प्रयत्न करा."
                }
                pin = ""
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Cloud)
            .imePadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 28.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier
                    .size(88.dp)
                    .background(Green50, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Outlined.Agriculture,
                    contentDescription = null,
                    tint = Green700,
                    modifier = Modifier.size(46.dp)
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "ट्रॅक्टर मॅनेजर",
                style = MaterialTheme.typography.headlineSmall,
                color = Green900
            )
            Text(
                "तुमचा हिशोब सुरक्षित आहे",
                style = MaterialTheme.typography.bodyMedium,
                color = InkSoft
            )
            Spacer(Modifier.height(30.dp))
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(White, MaterialTheme.shapes.large)
                    .padding(20.dp)
            ) {
                Box(
                    Modifier
                        .size(42.dp)
                        .background(Green50, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.Lock, contentDescription = null, tint = Green700)
                }
                Spacer(Modifier.height(14.dp))
                Text("PIN टाका", style = MaterialTheme.typography.titleLarge, color = Ink)
                Spacer(Modifier.height(4.dp))
                Text(
                    "ॲप उघडण्यासाठी सेट केलेला PIN टाका.",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSoft
                )
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { value ->
                        pin = value.filter { it.isDigit() }.take(6)
                        error = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("PIN") },
                    singleLine = true,
                    isError = error != null,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.NumberPassword,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { submit() }),
                    shape = MaterialTheme.shapes.medium,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Green700,
                        unfocusedBorderColor = com.tractormanager.app.ui.theme.Border,
                        cursorColor = Green700
                    )
                )
                Spacer(Modifier.height(10.dp))
                ErrorBanner(error)
                if (error != null) Spacer(Modifier.height(10.dp))
                PrimaryButton(
                    text = "उघडा",
                    onClick = { submit() },
                    loading = checking,
                    enabled = pin.length >= 4
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "PIN विसरल्यास फोन सेटिंग्जमधून ॲपचा डेटा साफ करावा लागेल. नियमित बॅकअप घ्या.",
                style = MaterialTheme.typography.bodySmall,
                color = InkSoft,
                textAlign = TextAlign.Center
            )
        }
    }
}
