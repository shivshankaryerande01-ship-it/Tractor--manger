package com.tractormanager.app.core

import com.tractormanager.app.core.geo.GeoPoint
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

object Ids {
    fun newId(): String = UUID.randomUUID().toString()
}

object PointsCodec {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun encode(points: List<GeoPoint>): String = json.encodeToString(points)

    fun decode(raw: String): List<GeoPoint> = runCatching {
        json.decodeFromString<List<GeoPoint>>(raw)
    }.getOrDefault(emptyList())
}

class DuplicateMobileException :
    IllegalStateException("हा मोबाईल नंबर आधीच दुसऱ्या शेतकऱ्याकडे नोंदवलेला आहे.")

class DuplicateRecordException(message: String) : IllegalStateException(message)

class ValidationFailureException(val result: ValidationResult) :
    IllegalArgumentException(result.errors.values.firstOrNull() ?: "माहिती तपासा.")
