package com.tractormanager.app.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import com.tractormanager.app.core.geo.GeoPoint
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

class LocationHelper(private val context: Context) {

    fun hasPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    suspend fun currentLocation(): Result<GeoPoint> = currentFix().map { it.point }

    /**
     * Returns the best available fix together with its reported accuracy so the map
     * can show how reliable the GPS reading is.
     */
    suspend fun currentFix(): Result<LocationFix> {
        if (!hasPermission()) {
            return Result.failure(SecurityException("GPS परवानगी दिलेली नाही."))
        }
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return Result.failure(IllegalStateException("या फोनवर स्थान सेवा उपलब्ध नाही."))
        val gpsEnabled = providerEnabled(manager, LocationManager.GPS_PROVIDER)
        val networkEnabled = providerEnabled(manager, LocationManager.NETWORK_PROVIDER)
        if (!gpsEnabled && !networkEnabled) {
            return Result.failure(IllegalStateException("फोनमध्ये GPS बंद आहे. स्थान सेवा सुरू करा."))
        }

        val fallback = lastKnown(manager)
        val recent = fallback?.takeIf { isFreshAndAccurate(it) }
        if (recent != null) {
            return Result.success(recent.toFix())
        }

        val freshFix = withTimeoutOrNull(22_000) { awaitFreshFix(manager, gpsEnabled) }
        val chosen = listOfNotNull(freshFix, fallback)
            .filter { accuracyOf(it) <= 2_000f }
            .minByOrNull { accuracyOf(it) }
        if (chosen != null) {
            return Result.success(chosen.toFix())
        }
        return Result.failure(
            IllegalStateException("अचूक GPS स्थान मिळाले नाही. खुल्या जागेत जाऊन पुन्हा प्रयत्न करा.")
        )
    }

    private fun providerEnabled(manager: LocationManager, provider: String): Boolean =
        runCatching { manager.isProviderEnabled(provider) }.getOrDefault(false)

    private fun accuracyOf(location: Location): Float =
        if (location.hasAccuracy()) location.accuracy else Float.MAX_VALUE

    private fun isFreshAndAccurate(location: Location): Boolean {
        val age = System.currentTimeMillis() - location.time
        return age in 0..(2 * 60 * 1000L) && accuracyOf(location) <= 50f
    }

    @SuppressLint("MissingPermission")
    private fun lastKnown(manager: LocationManager): Location? {
        val locations = listOfNotNull(
            runCatching { manager.getLastKnownLocation(LocationManager.GPS_PROVIDER) }.getOrNull(),
            runCatching { manager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) }.getOrNull()
        ).filter { location ->
            val age = System.currentTimeMillis() - location.time
            age in 0..(15 * 60 * 1000L)
        }
        return locations.minWithOrNull(
            compareBy<Location> { accuracyOf(it) }
                .thenBy { if (it.provider == LocationManager.GPS_PROVIDER) 0 else 1 }
        )
    }

    @SuppressLint("MissingPermission")
    private suspend fun awaitFreshFix(manager: LocationManager, gpsEnabled: Boolean): Location? =
        suspendCancellableCoroutine { continuation ->
            val finished = AtomicBoolean(false)
            val handler = Handler(Looper.getMainLooper())
            var best: Location? = null
            var registeredListener: android.location.LocationListener? = null

            fun finish(location: Location?) {
                if (finished.compareAndSet(false, true)) {
                    registeredListener?.let { runCatching { manager.removeUpdates(it) } }
                    handler.removeCallbacksAndMessages(null)
                    if (continuation.isActive) continuation.resume(location)
                }
            }

            val listener = object : android.location.LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (!location.hasAccuracy()) return
                    val accuracy = location.accuracy
                    val strong = accuracy <= 35f ||
                        (location.provider == LocationManager.GPS_PROVIDER && accuracy <= 70f)
                    if (strong) {
                        finish(location)
                    } else {
                        val currentBest = best
                        if (currentBest == null || accuracy < accuracyOf(currentBest)) {
                            best = location
                        }
                    }
                }

                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) = Unit
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) = Unit
            }
            registeredListener = listener

            val networkEnabled = providerEnabled(manager, LocationManager.NETWORK_PROVIDER)
            val providers = when {
                gpsEnabled && networkEnabled ->
                    listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                gpsEnabled -> listOf(LocationManager.GPS_PROVIDER)
                networkEnabled -> listOf(LocationManager.NETWORK_PROVIDER)
                else -> listOf(LocationManager.GPS_PROVIDER)
            }

            val registered = mutableListOf<String>()
            providers.forEach { provider ->
                runCatching {
                    manager.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
                    registered.add(provider)
                }
            }
            if (registered.isEmpty()) {
                finish(best)
                return@suspendCancellableCoroutine
            }
            handler.postDelayed({ finish(best) }, 18_000)

            continuation.invokeOnCancellation {
                finished.set(true)
                runCatching { manager.removeUpdates(listener) }
                handler.removeCallbacksAndMessages(null)
            }
        }

    private fun Location.toFix(): LocationFix = LocationFix(
        point = GeoPoint(latitude, longitude),
        accuracyMeters = accuracyOf(this),
        provider = provider.orEmpty()
    )
}

data class LocationFix(
    val point: GeoPoint,
    val accuracyMeters: Float,
    val provider: String
)
