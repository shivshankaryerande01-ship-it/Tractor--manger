package com.tractormanager.app.core.geo

import kotlinx.serialization.Serializable
import kotlin.math.abs
import kotlin.math.sin

@Serializable
data class GeoPoint(
    val latitude: Double,
    val longitude: Double
) {
    fun isValid(): Boolean =
        latitude in -90.0..90.0 && longitude in -180.0..180.0

    fun toQuery(): String = "$latitude,$longitude"
}

/**
 * Geodesic polygon area on a sphere, based on the spherical excess formula
 * used for small parcel measurement on satellite maps.
 *
 * The algorithm is independent of the winding order, uses metres internally and
 * returns square metres. Invalid input or fewer than three points returns 0.
 */
object GeoAreaCalculator {

    const val EARTH_RADIUS_METERS = 6_371_009.0
    private const val TWO_PI = Math.PI * 2.0
    private const val MAX_LATITUDE_DEGREES = 90.0

    fun areaSquareMeters(points: List<GeoPoint>): Double {
        if (points.size < 3) return 0.0
        if (points.any { !it.isValid() }) return 0.0
        if (points.distinct().size < 3) return 0.0

        var sum = 0.0
        for (index in points.indices) {
            val first = points[index]
            val second = points[(index + 1) % points.size]
            val lat1 = Math.toRadians(first.latitude.coerceIn(-MAX_LATITUDE_DEGREES, MAX_LATITUDE_DEGREES))
            val lat2 = Math.toRadians(second.latitude.coerceIn(-MAX_LATITUDE_DEGREES, MAX_LATITUDE_DEGREES))
            var deltaLon = Math.toRadians(second.longitude - first.longitude)
            if (deltaLon > Math.PI) deltaLon -= TWO_PI
            if (deltaLon < -Math.PI) deltaLon += TWO_PI
            sum += deltaLon * (2.0 + sin(lat1) + sin(lat2))
        }
        val area = abs(sum * EARTH_RADIUS_METERS * EARTH_RADIUS_METERS / 2.0)
        return if (area.isFinite()) area else 0.0
    }

    /**
     * Planar self-intersection check used to reject crossed boundaries before saving.
     * For farm-sized polygons this is accurate enough.
     */
    fun isSelfIntersecting(points: List<GeoPoint>): Boolean {
        val n = points.size
        if (n < 4) return false
        for (i in 0 until n) {
            val a1 = points[i]
            val a2 = points[(i + 1) % n]
            for (j in i + 1 until n) {
                if (j == i) continue
                if ((j + 1) % n == i || j == (i + 1) % n) continue
                val b1 = points[j]
                val b2 = points[(j + 1) % n]
                if (segmentsIntersect(a1, a2, b1, b2)) return true
            }
        }
        return false
    }

    private fun segmentsIntersect(a1: GeoPoint, a2: GeoPoint, b1: GeoPoint, b2: GeoPoint): Boolean {
        val d1 = cross(b1, b2, a1)
        val d2 = cross(b1, b2, a2)
        val d3 = cross(a1, a2, b1)
        val d4 = cross(a1, a2, b2)
        if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) &&
            ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))
        ) {
            return true
        }
        return (d1 == 0.0 && onSegment(b1, b2, a1)) ||
            (d2 == 0.0 && onSegment(b1, b2, a2)) ||
            (d3 == 0.0 && onSegment(a1, a2, b1)) ||
            (d4 == 0.0 && onSegment(a1, a2, b2))
    }

    private fun cross(a: GeoPoint, b: GeoPoint, c: GeoPoint): Double =
        (b.longitude - a.longitude) * (c.latitude - a.latitude) -
            (b.latitude - a.latitude) * (c.longitude - a.longitude)

    private fun onSegment(a: GeoPoint, b: GeoPoint, c: GeoPoint): Boolean =
        c.longitude in minOf(a.longitude, b.longitude)..maxOf(a.longitude, b.longitude) &&
            c.latitude in minOf(a.latitude, b.latitude)..maxOf(a.latitude, b.latitude)
}
