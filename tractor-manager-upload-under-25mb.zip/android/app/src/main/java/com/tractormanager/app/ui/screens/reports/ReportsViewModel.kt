package com.tractormanager.app.ui.screens.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.data.repository.MonthReport
import com.tractormanager.app.data.repository.ReportRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn

class ReportsViewModel(private val repository: ReportRepository) : ViewModel() {

    private val month = MutableStateFlow(DateUtils.todayEpochDay())

    val selectedMonth: StateFlow<Long> = month.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val report: StateFlow<MonthReport?> = month
        .flatMapLatest { repository.observeMonth(it) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = null
        )

    fun previousMonth() {
        month.value = DateUtils.addMonths(month.value, -1)
    }

    fun nextMonth() {
        if (!canGoNext()) return
        month.value = DateUtils.addMonths(month.value, 1)
    }

    fun canGoNext(): Boolean {
        val current = DateUtils.monthStartEpochDay(month.value)
        val thisMonth = DateUtils.monthStartEpochDay(DateUtils.todayEpochDay())
        return current < thisMonth
    }
}
