package com.tractormanager.app.ui.screens.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.data.repository.DashboardData
import com.tractormanager.app.data.repository.DashboardRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn

class DashboardViewModel(repository: DashboardRepository) : ViewModel() {
    val data = repository.observeDashboard().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = DashboardData()
    )
}
