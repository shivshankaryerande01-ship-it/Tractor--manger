package com.tractormanager.app.ui.screens.farmers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.core.Money
import com.tractormanager.app.data.repository.FarmerListItem
import com.tractormanager.app.data.repository.FarmerRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class FarmersViewModel(repository: FarmerRepository) : ViewModel() {
    val farmers = repository.observeWithBalances().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    val totals = repository.observeWithBalances().map { items ->
        FarmerTotals(
            pending = Money.round(items.sumOf { it.summary.outstanding }),
            count = items.size
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = FarmerTotals(0.0, 0)
    )
}

data class FarmerTotals(val pending: Double, val count: Int)
