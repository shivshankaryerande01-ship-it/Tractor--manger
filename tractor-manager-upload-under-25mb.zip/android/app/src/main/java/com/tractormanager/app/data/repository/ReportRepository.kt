package com.tractormanager.app.data.repository

import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.core.Money
import com.tractormanager.app.data.local.Farmer
import com.tractormanager.app.data.local.FarmerDao
import com.tractormanager.app.data.local.LandFieldDao
import com.tractormanager.app.data.local.Payment
import com.tractormanager.app.data.local.PaymentDao
import com.tractormanager.app.data.local.PaymentRow
import com.tractormanager.app.data.local.WorkRecord
import com.tractormanager.app.data.local.WorkRecordDao
import com.tractormanager.app.data.local.WorkRecordRow
import com.tractormanager.app.domain.PaymentCalculator
import com.tractormanager.app.domain.PaymentStatus
import com.tractormanager.app.domain.PaymentSummary
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first

data class FarmerReportRow(
    val farmerId: String,
    val name: String,
    val mobile: String,
    val monthBilled: Double,
    val monthReceived: Double,
    val totalOutstanding: Double,
    val status: PaymentStatus
)

data class MonthReport(
    val monthEpochDay: Long,
    val startDay: Long,
    val endDay: Long,
    val works: List<WorkRecordRow>,
    val payments: List<PaymentRow>,
    val farmers: List<FarmerReportRow>,
    val totalAcres: Double,
    val totalBilled: Double,
    val totalReceived: Double,
    val totalOutstanding: Double
) {
    val monthLabel: String get() = DateUtils.formatMonth(monthEpochDay)
    val hasData: Boolean get() = works.isNotEmpty() || payments.isNotEmpty()
}

data class BillData(
    val farmer: Farmer,
    val works: List<WorkRecord>,
    val payments: List<Payment>,
    val summary: PaymentSummary,
    val fieldNames: Map<String, String> = emptyMap()
)

class ReportRepository(
    private val workRecordDao: WorkRecordDao,
    private val paymentDao: PaymentDao,
    private val farmerDao: FarmerDao,
    private val landFieldDao: LandFieldDao
) {

    fun observeMonth(epochDay: Long): Flow<MonthReport> {
        val start = DateUtils.monthStartEpochDay(epochDay)
        val end = DateUtils.monthEndEpochDay(epochDay)
        return combine(
            workRecordDao.observeBetween(start, end),
            paymentDao.observeBetween(start, end),
            farmerDao.observeWithBalances()
        ) { works, payments, balances ->
            val billedByFarmer = works.groupBy { it.work.farmerId }
                .mapValues { entry -> Money.round(entry.value.sumOf { it.work.totalAmount }) }
            val receivedByFarmer = payments.groupBy { it.payment.farmerId }
                .mapValues { entry -> Money.round(entry.value.sumOf { it.payment.amount }) }
            val allFarmers = balances.associateBy { it.farmer.id }

            val reportFarmers = allFarmers.values.mapNotNull { row ->
                val monthBilled = billedByFarmer[row.farmer.id] ?: 0.0
                val monthReceived = receivedByFarmer[row.farmer.id] ?: 0.0
                val summary = PaymentCalculator.summarize(row.billed, row.received)
                if (monthBilled <= 0.0 && monthReceived <= 0.0 && summary.outstanding <= 0.0) {
                    null
                } else {
                    FarmerReportRow(
                        farmerId = row.farmer.id,
                        name = row.farmer.name,
                        mobile = row.farmer.mobile,
                        monthBilled = monthBilled,
                        monthReceived = monthReceived,
                        totalOutstanding = summary.outstanding,
                        status = summary.status
                    )
                }
            }.sortedWith(compareByDescending<FarmerReportRow> { it.totalOutstanding }.thenBy { it.name })

            MonthReport(
                monthEpochDay = epochDay,
                startDay = start,
                endDay = end,
                works = works,
                payments = payments,
                farmers = reportFarmers,
                totalAcres = works.sumOf { it.work.acres },
                totalBilled = Money.round(works.sumOf { it.work.totalAmount }),
                totalReceived = Money.round(payments.sumOf { it.payment.amount }),
                totalOutstanding = Money.round(
                    balances.sumOf { PaymentCalculator.summarize(it.billed, it.received).outstanding }
                )
            )
        }
    }

    suspend fun buildBill(farmerId: String): BillData? {
        val farmer = farmerDao.getById(farmerId) ?: return null
        val works = workRecordDao.getForFarmer(farmerId)
        val payments = paymentDao.getForFarmer(farmerId)
        val summary = PaymentCalculator.summarize(
            works.sumOf { it.totalAmount },
            payments.sumOf { it.amount }
        )
        val fieldNames = landFieldDao.getActiveByFarmer(farmerId)
            .associate { it.id to it.name }
        return BillData(farmer, works, payments, summary, fieldNames)
    }

    suspend fun loadMonthReport(epochDay: Long): MonthReport {
        val start = DateUtils.monthStartEpochDay(epochDay)
        val end = DateUtils.monthEndEpochDay(epochDay)
        val works = workRecordDao.getBetween(start, end)
        val payments = paymentDao.getBetween(start, end)
        val balances = farmerDao.observeWithBalances().first()
        val workRows = workRecordDao.observeBetween(start, end).first()
        val paymentRows = paymentDao.observeBetween(start, end).first()
        val billedByFarmer = works.groupBy { it.farmerId }.mapValues { Money.round(it.value.sumOf { w -> w.totalAmount }) }
        val receivedByFarmer = payments.groupBy { it.farmerId }.mapValues { Money.round(it.value.sumOf { p -> p.amount }) }
        val reportFarmers = balances.mapNotNull { row ->
            val monthBilled = billedByFarmer[row.farmer.id] ?: 0.0
            val monthReceived = receivedByFarmer[row.farmer.id] ?: 0.0
            val summary = PaymentCalculator.summarize(row.billed, row.received)
            if (monthBilled <= 0.0 && monthReceived <= 0.0 && summary.outstanding <= 0.0) {
                null
            } else {
                FarmerReportRow(
                    farmerId = row.farmer.id,
                    name = row.farmer.name,
                    mobile = row.farmer.mobile,
                    monthBilled = monthBilled,
                    monthReceived = monthReceived,
                    totalOutstanding = summary.outstanding,
                    status = summary.status
                )
            }
        }.sortedWith(compareByDescending<FarmerReportRow> { it.totalOutstanding }.thenBy { it.name })

        return MonthReport(
            monthEpochDay = epochDay,
            startDay = start,
            endDay = end,
            works = workRows,
            payments = paymentRows,
            farmers = reportFarmers,
            totalAcres = works.sumOf { it.acres },
            totalBilled = Money.round(works.sumOf { it.totalAmount }),
            totalReceived = Money.round(payments.sumOf { it.amount }),
            totalOutstanding = Money.round(
                balances.sumOf { PaymentCalculator.summarize(it.billed, it.received).outstanding }
            )
        )
    }

}
