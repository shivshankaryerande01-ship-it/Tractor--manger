package com.tractormanager.app.ui.screens.reports

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Agriculture
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.core.DateUtils
import com.tractormanager.app.core.Money
import com.tractormanager.app.core.NumberText
import com.tractormanager.app.data.repository.FarmerReportRow
import com.tractormanager.app.data.repository.MonthReport
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.AppCard
import com.tractormanager.app.ui.components.EmptyState
import com.tractormanager.app.ui.components.PrimaryButton
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.components.SectionHeader
import com.tractormanager.app.ui.components.StatCard
import com.tractormanager.app.ui.components.StatusPill
import com.tractormanager.app.ui.components.ValueRow
import com.tractormanager.app.ui.theme.Danger
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.InkSoft
import com.tractormanager.app.ui.theme.Mustard
import com.tractormanager.app.ui.theme.White
import com.tractormanager.app.util.CsvExporter
import com.tractormanager.app.util.PdfGenerator
import com.tractormanager.app.util.ShareUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ReportsScreen(onSettings: () -> Unit) {
    val viewModel = appViewModel { ReportsViewModel(it.reportRepository) }
    val report by viewModel.report.collectAsStateWithLifecycle()
    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val pdfGenerator = remember(context) { PdfGenerator(context) }
    var busy by remember { mutableStateOf(false) }
    var pendingCsv by remember { mutableStateOf<MonthReport?>(null) }

    val csvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        val snapshot = pendingCsv
        pendingCsv = null
        if (uri == null || snapshot == null) return@rememberLauncherForActivityResult
        scope.launch {
            CsvExporter.writeToUri(context, uri, CsvExporter.buildMonthCsv(snapshot))
                .onSuccess { snackbar.showSnackbar("CSV अहवाल जतन झाला.") }
                .onFailure { snackbar.showSnackbar(it.message ?: "CSV जतन करता आला नाही.") }
        }
    }

    fun exportPdf(current: MonthReport) {
        if (busy) return
        scope.launch {
            busy = true
            try {
                val file = withContext(Dispatchers.IO) { pdfGenerator.generateMonthReport(current) }
                ShareUtils.sharePdf(
                    context,
                    file,
                    false,
                    "ट्रॅक्टर मॅनेजर — ${current.monthLabel} चा मासिक अहवाल"
                )
            } catch (error: Exception) {
                snackbar.showSnackbar(error.message ?: "PDF अहवाल तयार करता आला नाही.")
            } finally {
                busy = false
            }
        }
    }

    ScreenScaffold(
        title = "अहवाल",
        subtitle = "मासिक काम व हिशोब",
        actions = {
            IconButton(onClick = onSettings) {
                Icon(Icons.Outlined.Settings, contentDescription = "सेटिंग्ज")
            }
        },
        snackbarHostState = snackbar
    ) { padding ->
        val current = report
        if (current == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = Green700)
            }
            return@ScreenScaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                MonthSwitcher(
                    monthLabel = current.monthLabel,
                    canGoNext = viewModel.canGoNext(),
                    workCount = current.works.size,
                    paymentCount = current.payments.size,
                    onPrevious = viewModel::previousMonth,
                    onNext = viewModel::nextMonth
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(
                        label = "महिन्याचे बिल",
                        value = Money.format(current.totalBilled),
                        icon = Icons.Outlined.TrendingUp,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        label = "महिन्यात जमा",
                        value = Money.format(current.totalReceived),
                        icon = Icons.Outlined.Payments,
                        modifier = Modifier.weight(1f),
                        tint = Green700
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(
                        label = "एकूण बाकी",
                        value = Money.format(current.totalOutstanding),
                        icon = Icons.Outlined.Description,
                        modifier = Modifier.weight(1f),
                        tint = Danger
                    )
                    StatCard(
                        label = "एकूण एकर",
                        value = NumberText.format(current.totalAcres, 2),
                        icon = Icons.Outlined.Agriculture,
                        modifier = Modifier.weight(1f),
                        tint = Mustard
                    )
                }
            }

            item {
                AppCard(containerColor = White) {
                    Column {
                        Text(
                            "अहवाल निर्यात",
                            style = MaterialTheme.typography.titleSmall,
                            color = Green900
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PrimaryButton(
                                text = if (busy) "तयार होत आहे..." else "PDF अहवाल",
                                onClick = { exportPdf(current) },
                                modifier = Modifier.weight(1f),
                                loading = busy,
                                icon = Icons.Outlined.Description
                            )
                            OutlinedButton(
                                onClick = {
                                    if (current.works.isEmpty() && current.payments.isEmpty()) {
                                        scope.launch { snackbar.showSnackbar("या महिन्यात निर्यात करण्यासाठी नोंदी नाहीत.") }
                                    } else {
                                        pendingCsv = current
                                        csvLauncher.launch("tractor_report_${DateUtils.fileStamp()}.csv")
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(56.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(
                                    Icons.Outlined.Download,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp),
                                    tint = Green700
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("CSV जतन करा", color = Green700)
                            }
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "शेतकरीनिहाय हिशोब",
                    subtitle = "${current.farmers.size} शेतकरी"
                )
            }

            if (current.farmers.isEmpty()) {
                item {
                    EmptyState(
                        icon = Icons.Outlined.Groups,
                        title = "या महिन्याची नोंद नाही",
                        message = "काम किंवा पैसे नोंदवल्यावर इथे शेतकरीनिहाय हिशोब दिसेल."
                    )
                }
            } else {
                items(current.farmers, key = { it.farmerId }) { farmer ->
                    FarmerReportCard(farmer)
                }
            }

            item { Spacer(Modifier.height(8.dp)) }
        }
    }
}

@Composable
private fun MonthSwitcher(
    monthLabel: String,
    canGoNext: Boolean,
    workCount: Int,
    paymentCount: Int,
    onPrevious: () -> Unit,
    onNext: () -> Unit
) {
    Surface(
        color = White,
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onPrevious) {
                Icon(Icons.Outlined.ChevronLeft, contentDescription = "मागील महिना", tint = Green700)
            }
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    monthLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = Green900
                )
                Text(
                    "$workCount कामे • $paymentCount जमा नोंदी",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSoft
                )
            }
            IconButton(onClick = onNext, enabled = canGoNext) {
                Icon(
                    Icons.Outlined.ChevronRight,
                    contentDescription = "पुढील महिना",
                    tint = if (canGoNext) Green700 else InkSoft.copy(alpha = 0.35f)
                )
            }
        }
    }
}

@Composable
private fun FarmerReportCard(farmer: FarmerReportRow) {
    AppCard(containerColor = White) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        farmer.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = Green900
                    )
                    Text(
                        farmer.mobile,
                        style = MaterialTheme.typography.bodySmall,
                        color = InkSoft
                    )
                }
                StatusPill(farmer.status)
            }
            Spacer(Modifier.height(8.dp))
            ValueRow("महिन्याचे बिल", Money.format(farmer.monthBilled))
            ValueRow("महिन्यात जमा", Money.format(farmer.monthReceived))
            ValueRow(
                "एकूण बाकी",
                Money.format(farmer.totalOutstanding),
                valueColor = if (farmer.totalOutstanding > 0) Danger else Green700
            )
        }
    }
}
