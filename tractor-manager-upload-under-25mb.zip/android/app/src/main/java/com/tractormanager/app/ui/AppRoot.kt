package com.tractormanager.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.TractorManagerApp
import com.tractormanager.app.ui.components.LoadingScreen
import com.tractormanager.app.ui.navigation.MainNavigation
import com.tractormanager.app.ui.screens.lock.PinLockScreen

@Composable
fun AppRoot() {
    val context = LocalContext.current
    val app = context.applicationContext as TractorManagerApp
    val settings by app.container.settingsRepository.settings
        .collectAsStateWithLifecycle(initialValue = null)
    var locked by rememberSaveable { mutableStateOf(true) }
    val pinEnabledNow by rememberUpdatedState(settings?.pinEnabled == true)
    var lastStoppedAt by remember { mutableLongStateOf(0L) }

    LaunchedEffect(settings?.pinEnabled) {
        if (settings?.pinEnabled == false) locked = false
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> lastStoppedAt = System.currentTimeMillis()
                Lifecycle.Event.ON_START -> {
                    val stoppedFor = System.currentTimeMillis() - lastStoppedAt
                    if (pinEnabledNow && lastStoppedAt > 0L && stoppedFor > 30_000L) {
                        locked = true
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val currentSettings = settings
    when {
        currentSettings == null -> LoadingScreen("ट्रॅक्टर मॅनेजर सुरू होत आहे...")
        locked && currentSettings.pinEnabled -> PinLockScreen(
            verifyPin = app.container.settingsRepository::verifyPin,
            onUnlocked = { locked = false }
        )
        else -> MainNavigation()
    }
}
