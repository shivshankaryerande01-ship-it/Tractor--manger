package com.tractormanager.app.core

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

object DateUtils {
    private val marathiMonths = arrayOf(
        "जानेवारी", "फेब्रुवारी", "मार्च", "एप्रिल", "मे", "जून",
        "जुलै", "ऑगस्ट", "सप्टेंबर", "ऑक्टोबर", "नोव्हेंबर", "डिसेंबर"
    )
    private val marathiMonthsShort = arrayOf(
        "जाने", "फेब्रु", "मार्च", "एप्रि", "मे", "जून",
        "जुलै", "ऑग", "सप्टें", "ऑक्टो", "नोव्हें", "डिसें"
    )

    fun todayEpochDay(): Long = LocalDate.now().toEpochDay()

    fun monthStartEpochDay(epochDay: Long): Long {
        val date = LocalDate.ofEpochDay(epochDay)
        return date.withDayOfMonth(1).toEpochDay()
    }

    fun monthEndEpochDay(epochDay: Long): Long {
        val date = LocalDate.ofEpochDay(epochDay)
        return date.withDayOfMonth(date.lengthOfMonth()).toEpochDay()
    }

    fun addMonths(epochDay: Long, months: Long): Long =
        LocalDate.ofEpochDay(epochDay).plusMonths(months).toEpochDay()

    fun formatDate(epochDay: Long): String {
        val date = LocalDate.ofEpochDay(epochDay)
        return "${date.dayOfMonth} ${marathiMonths[date.monthValue - 1]} ${date.year}"
    }

    fun formatDateShort(epochDay: Long): String {
        val date = LocalDate.ofEpochDay(epochDay)
        return "${date.dayOfMonth} ${marathiMonthsShort[date.monthValue - 1]} ${date.year}"
    }

    fun formatMonth(epochDay: Long): String {
        val date = LocalDate.ofEpochDay(epochDay)
        return "${marathiMonths[date.monthValue - 1]} ${date.year}"
    }

    fun formatWeekday(epochDay: Long): String {
        val day = LocalDate.ofEpochDay(epochDay).dayOfWeek.value
        return arrayOf("सोमवार", "मंगळवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार", "रविवार")[day - 1]
    }

    fun formatDateTime(timestamp: Long): String {
        val dateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), ZoneId.systemDefault())
        val date = dateTime.toLocalDate()
        return "${date.dayOfMonth} ${marathiMonthsShort[date.monthValue - 1]} ${date.year}, " +
            "%02d:%02d".format(dateTime.hour, dateTime.minute)
    }

    fun fileStamp(): String = LocalDate.now().toString()
}
