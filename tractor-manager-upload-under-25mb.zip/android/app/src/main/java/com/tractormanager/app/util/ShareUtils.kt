package com.tractormanager.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object ShareUtils {

    fun sharePdf(
        context: Context,
        file: File,
        whatsAppFirst: Boolean,
        text: String
    ) {
        val uri = runCatching {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        }.getOrNull() ?: return

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        if (whatsAppFirst) {
            val packages = listOf("com.whatsapp", "com.whatsapp.w4b")
            for (target in packages) {
                val direct = Intent(intent).setPackage(target)
                if (direct.resolveActivity(context.packageManager) != null) {
                    runCatching { context.startActivity(direct) }
                    return
                }
            }
        }
        val chooser = Intent.createChooser(intent, "PDF पाठवा")
        chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(chooser)
    }

    fun shareText(context: Context, text: String, whatsAppFirst: Boolean) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        if (whatsAppFirst) {
            for (target in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                val direct = Intent(intent).setPackage(target)
                if (direct.resolveActivity(context.packageManager) != null) {
                    runCatching { context.startActivity(direct) }
                    return
                }
            }
        }
        context.startActivity(Intent.createChooser(intent, "संदेश पाठवा"))
    }

    fun dialPhone(context: Context, mobile: String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${mobile.trim()}"))
        runCatching { context.startActivity(intent) }
    }

    fun openWhatsAppChat(context: Context, mobile: String, text: String) {
        val clean = mobile.filter { it.isDigit() }
        val number = if (clean.length == 10) "91$clean" else clean
        val url = "https://wa.me/$number?text=${Uri.encode(text)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        runCatching { context.startActivity(intent) }
    }
}
