package com.tractormanager.app.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.tractormanager.app.BuildConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

private val Context.settingsDataStore by preferencesDataStore(name = "tractor_settings")

data class AppSettings(
    val pinEnabled: Boolean = false,
    val hasPin: Boolean = false,
    val firebaseUrl: String = "",
    val syncCode: String = "",
    val firebaseToken: String = "",
    val defaultFirebaseUrl: String = BuildConfig.FIREBASE_DB_URL
) {
    val syncConfigured: Boolean
        get() = firebaseUrl.isNotBlank() && syncCode.isNotBlank()
}

object PinHasher {
    private const val ITERATIONS = 120_000
    private const val KEY_LENGTH_BITS = 256

    fun newSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return Base64.getEncoder().encodeToString(bytes)
    }

    fun hash(pin: String, saltBase64: String): String {
        val salt = Base64.getDecoder().decode(saltBase64)
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_LENGTH_BITS)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val hashed = factory.generateSecret(spec).encoded
        spec.clearPassword()
        return Base64.getEncoder().encodeToString(hashed)
    }

    fun verify(pin: String, saltBase64: String, expectedHash: String): Boolean {
        return runCatching {
            val actual = hash(pin, saltBase64)
            MessageDigest.isEqual(
                actual.toByteArray(Charsets.UTF_8),
                expectedHash.toByteArray(Charsets.UTF_8)
            )
        }.getOrDefault(false)
    }
}

class SettingsRepository(private val context: Context) {

    private object Keys {
        val pinEnabled = booleanPreferencesKey("pin_enabled")
        val pinHash = stringPreferencesKey("pin_hash")
        val pinSalt = stringPreferencesKey("pin_salt")
        val firebaseUrl = stringPreferencesKey("firebase_url")
        val syncCode = stringPreferencesKey("sync_code")
        val firebaseToken = stringPreferencesKey("firebase_token")
    }

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        val hash = prefs[Keys.pinHash].orEmpty()
        AppSettings(
            pinEnabled = prefs[Keys.pinEnabled] ?: false,
            hasPin = hash.isNotEmpty(),
            firebaseUrl = prefs[Keys.firebaseUrl].orEmpty(),
            syncCode = prefs[Keys.syncCode].orEmpty(),
            firebaseToken = prefs[Keys.firebaseToken].orEmpty()
        )
    }

    suspend fun current(): AppSettings = settings.first()

    suspend fun verifyPin(pin: String): Boolean {
        val prefs = context.settingsDataStore.data.first()
        val hash = prefs[Keys.pinHash].orEmpty()
        val salt = prefs[Keys.pinSalt].orEmpty()
        if (hash.isEmpty() || salt.isEmpty()) return false
        return PinHasher.verify(pin, salt, hash)
    }

    suspend fun enablePin(newPin: String): Result<Unit> = runCatching {
        if (!newPin.matches(Regex("^[0-9]{4,6}$"))) {
            throw IllegalArgumentException("PIN ४ ते ६ अंकांचा असावा.")
        }
        val salt = PinHasher.newSalt()
        val hash = PinHasher.hash(newPin, salt)
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.pinSalt] = salt
            prefs[Keys.pinHash] = hash
            prefs[Keys.pinEnabled] = true
        }
    }

    suspend fun changePin(currentPin: String, newPin: String): Result<Unit> {
        if (!verifyPin(currentPin)) {
            return Result.failure(IllegalArgumentException("सध्याचा PIN चुकीचा आहे."))
        }
        return enablePin(newPin)
    }

    suspend fun disablePin(currentPin: String): Result<Unit> {
        if (!verifyPin(currentPin)) {
            return Result.failure(IllegalArgumentException("सध्याचा PIN चुकीचा आहे."))
        }
        return runCatching {
            context.settingsDataStore.edit { prefs ->
                prefs.remove(Keys.pinHash)
                prefs.remove(Keys.pinSalt)
                prefs[Keys.pinEnabled] = false
            }
        }
    }

    suspend fun setPinEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.pinEnabled] = enabled
        }
    }

    suspend fun saveSyncSettings(url: String, code: String, token: String) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.firebaseUrl] = url.trim()
            prefs[Keys.syncCode] = code.trim()
            prefs[Keys.firebaseToken] = token.trim()
        }
    }
}
