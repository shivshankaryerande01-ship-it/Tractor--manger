package com.tractormanager.app.ui.screens.farmers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.data.local.Farmer
import com.tractormanager.app.data.local.LandField
import com.tractormanager.app.data.local.PaymentRow
import com.tractormanager.app.data.local.WorkRecordRow
import com.tractormanager.app.data.repository.BillData
import com.tractormanager.app.data.repository.FarmerRepository
import com.tractormanager.app.data.repository.FieldRepository
import com.tractormanager.app.data.repository.PaymentRepository
import com.tractormanager.app.data.repository.ReportRepository
import com.tractormanager.app.data.repository.WorkRepository
import com.tractormanager.app.domain.PaymentSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FarmerDetailState(
    val farmer: Farmer? = null,
    val summary: PaymentSummary? = null,
    val fields: List<LandField> = emptyList(),
    val works: List<WorkRecordRow> = emptyList(),
    val payments: List<PaymentRow> = emptyList(),
    val loading: Boolean = true,
    val deleted: Boolean = false
)

class FarmerDetailViewModel(
    private val farmerId: String,
    private val farmerRepository: FarmerRepository,
    fieldRepository: FieldRepository,
    workRepository: WorkRepository,
    paymentRepository: PaymentRepository,
    private val reportRepository: ReportRepository
) : ViewModel() {

    val state: StateFlow<FarmerDetailState> = combine(
        farmerRepository.observeFarmer(farmerId),
        farmerRepository.observeAccount(farmerId),
        fieldRepository.observeByFarmer(farmerId),
        workRepository.observeByFarmer(farmerId),
        paymentRepository.observeByFarmer(farmerId)
    ) { farmer, account, fields, works, payments ->
        FarmerDetailState(
            farmer = farmer,
            summary = account.summary,
            fields = fields,
            works = works,
            payments = payments,
            loading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = FarmerDetailState()
    )

    private val _deleted = MutableStateFlow(false)
    val deleted: StateFlow<Boolean> = _deleted.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun deleteFarmer() {
        viewModelScope.launch {
            farmerRepository.deleteFarmer(farmerId).fold(
                onSuccess = { _deleted.value = true },
                onFailure = {
                    _message.value = it.message ?: "शेतकरी हटवता आला नाही."
                }
            )
        }
    }

    fun clearMessage() {
        _message.value = null
    }

    suspend fun buildBill(): BillData? = reportRepository.buildBill(farmerId)
}
