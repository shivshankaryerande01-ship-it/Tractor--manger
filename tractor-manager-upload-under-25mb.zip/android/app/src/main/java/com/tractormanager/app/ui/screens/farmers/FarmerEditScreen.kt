package com.tractormanager.app.ui.screens.farmers

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.AppTextField
import com.tractormanager.app.ui.components.ErrorBanner
import com.tractormanager.app.ui.components.InfoBanner
import com.tractormanager.app.ui.components.LoadingScreen
import com.tractormanager.app.ui.components.PrimaryButton
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.theme.InkSoft

@Composable
fun FarmerEditScreen(
    farmerId: String?,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val viewModel = appViewModel { FarmerEditViewModel(it.farmerRepository, farmerId) }
    val state by viewModel.state.collectAsStateWithLifecycle()

    LaunchedEffect(state.saved) {
        if (state.saved) onSaved()
    }

    if (state.loading) {
        LoadingScreen("शेतकरी माहिती लोड होत आहे...")
        return
    }

    ScreenScaffold(
        title = if (farmerId == null) "नवीन शेतकरी" else "शेतकरी संपादित करा",
        subtitle = "नाव, मोबाईल आणि गाव",
        onBack = onBack
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            ErrorBanner(state.message)
            AppTextField(
                value = state.name,
                onValueChange = viewModel::onNameChange,
                label = "शेतकऱ्याचे नाव *",
                placeholder = "उदा. राम पाटील",
                leadingIcon = Icons.Outlined.Person,
                error = state.errors["name"]
            )
            AppTextField(
                value = state.mobile,
                onValueChange = viewModel::onMobileChange,
                label = "मोबाईल नंबर *",
                placeholder = "१० अंकी नंबर",
                leadingIcon = Icons.Outlined.Phone,
                keyboardType = KeyboardType.Phone,
                error = state.errors["mobile"]
            )
            AppTextField(
                value = state.village,
                onValueChange = viewModel::onVillageChange,
                label = "गाव (ऐच्छिक)",
                placeholder = "उदा. शिरसगाव",
                leadingIcon = Icons.Outlined.LocationOn,
                error = state.errors["village"]
            )
            InfoBanner(
                "मोबाईल नंबरने शेतकऱ्याची ओळख होते. एकाच नंबरवर दुसरे खाते तयार होणार नाही."
            )
            Spacer(Modifier.height(4.dp))
            PrimaryButton(
                text = if (farmerId == null) "शेतकरी जतन करा" else "बदल जतन करा",
                onClick = viewModel::save,
                loading = state.saving,
                icon = Icons.Outlined.Save
            )
            Text(
                "* तारांकित माहिती आवश्यक आहे.",
                style = MaterialTheme.typography.bodySmall,
                color = InkSoft,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
