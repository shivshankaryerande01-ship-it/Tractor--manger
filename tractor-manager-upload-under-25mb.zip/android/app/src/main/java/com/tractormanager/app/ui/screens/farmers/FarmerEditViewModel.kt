package com.tractormanager.app.ui.screens.farmers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.core.DuplicateMobileException
import com.tractormanager.app.core.ValidationFailureException
import com.tractormanager.app.data.repository.FarmerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FarmerEditState(
    val name: String = "",
    val mobile: String = "",
    val village: String = "",
    val loading: Boolean = false,
    val saving: Boolean = false,
    val errors: Map<String, String> = emptyMap(),
    val message: String? = null,
    val saved: Boolean = false
)

class FarmerEditViewModel(
    private val repository: FarmerRepository,
    private val farmerId: String?
) : ViewModel() {

    private val _state = MutableStateFlow(FarmerEditState(loading = farmerId != null))
    val state: StateFlow<FarmerEditState> = _state.asStateFlow()

    init {
        if (farmerId != null) {
            viewModelScope.launch {
                val farmer = repository.getFarmer(farmerId)
                if (farmer == null) {
                    _state.update {
                        it.copy(
                            loading = false,
                            message = "शेतकरी सापडला नाही. तो कदाचित हटवला गेला असेल."
                        )
                    }
                } else {
                    _state.update {
                        it.copy(
                            name = farmer.name,
                            mobile = farmer.mobile,
                            village = farmer.village,
                            loading = false
                        )
                    }
                }
            }
        }
    }

    fun onNameChange(value: String) = _state.update {
        it.copy(name = value, errors = it.errors - "name", message = null)
    }

    fun onMobileChange(value: String) = _state.update {
        it.copy(
            mobile = value.filter { char -> char.isDigit() }.take(10),
            errors = it.errors - "mobile",
            message = null
        )
    }

    fun onVillageChange(value: String) = _state.update {
        it.copy(village = value, errors = it.errors - "village", message = null)
    }

    fun save() {
        if (_state.value.saving) return
        _state.update { it.copy(saving = true, message = null, errors = emptyMap()) }
        viewModelScope.launch {
            val result = repository.saveFarmer(
                id = farmerId,
                name = _state.value.name,
                mobile = _state.value.mobile,
                village = _state.value.village
            )
            result.fold(
                onSuccess = {
                    _state.update { it.copy(saving = false, saved = true) }
                },
                onFailure = { error ->
                    when (error) {
                        is ValidationFailureException -> _state.update {
                            it.copy(saving = false, errors = error.result.errors)
                        }
                        is DuplicateMobileException -> _state.update {
                            it.copy(
                                saving = false,
                                errors = it.errors + ("mobile" to error.message.orEmpty()),
                                message = error.message
                            )
                        }
                        else -> _state.update {
                            it.copy(
                                saving = false,
                                message = error.message ?: "शेतकरी जतन झाला नाही. पुन्हा प्रयत्न करा."
                            )
                        }
                    }
                }
            )
        }
    }
}
