package com.tractormanager.app.ui.screens.map

import android.Manifest
import android.app.Activity
import android.content.ContextWrapper
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Fullscreen
import androidx.compose.material.icons.outlined.FullscreenExit
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Undo
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.tractormanager.app.core.NumberText
import com.tractormanager.app.core.geo.GeoPoint
import com.tractormanager.app.ui.appViewModel
import com.tractormanager.app.ui.components.AppCard
import com.tractormanager.app.ui.components.AppTextField
import com.tractormanager.app.ui.components.ConfirmDialog
import com.tractormanager.app.ui.components.DropdownOption
import com.tractormanager.app.ui.components.ErrorBanner
import com.tractormanager.app.ui.components.InfoBanner
import com.tractormanager.app.ui.components.LabeledDropdown
import com.tractormanager.app.ui.components.LoadingScreen
import com.tractormanager.app.ui.components.PrimaryButton
import com.tractormanager.app.ui.components.ScreenScaffold
import com.tractormanager.app.ui.theme.Border
import com.tractormanager.app.ui.theme.Danger
import com.tractormanager.app.ui.theme.Green100
import com.tractormanager.app.ui.theme.Green50
import com.tractormanager.app.ui.theme.Green700
import com.tractormanager.app.ui.theme.Green900
import com.tractormanager.app.ui.theme.Ink
import com.tractormanager.app.ui.theme.InkSoft
import com.tractormanager.app.ui.theme.White
import kotlinx.coroutines.launch
import org.osmdroid.views.MapView

@Composable
fun LandMapScreen(
    initialFarmerId: String?,
    fieldId: String?,
    onBack: () -> Unit,
    onSaved: () -> Unit,
    onAddFarmer: () -> Unit
) {
    val viewModel = appViewModel {
        LandMapViewModel(
            fieldId = fieldId,
            initialFarmerId = initialFarmerId,
            fieldRepository = it.fieldRepository,
            farmerRepository = it.farmerRepository,
            placeSearchRepository = it.placeSearchRepository,
            locationHelper = it.locationHelper
        )
    }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var satellite by rememberSaveable { mutableStateOf(true) }
    var fullscreen by rememberSaveable { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val mapHolder = remember { arrayOfNulls<MapView>(1) }

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.any { it }) {
            viewModel.locate()
        } else {
            scope.launch {
                snackbar.showSnackbar("GPS वापरण्यासाठी स्थान परवानगी आवश्यक आहे.")
            }
        }
    }

    fun locate() {
        if (hasLocationPermission()) {
            viewModel.locate()
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    LaunchedEffect(state.saved) {
        if (state.saved) onSaved()
    }
    LaunchedEffect(state.deleted) {
        if (state.deleted) onBack()
    }
    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    BackHandler(enabled = fullscreen) { fullscreen = false }

    val activity = context.findActivity()
    DisposableEffect(fullscreen) {
        val window = activity?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        if (fullscreen) {
            controller?.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    if (state.loading) {
        LoadingScreen("जमीन लोड होत आहे...")
        return
    }

    val center = state.points.centroid() ?: GeoPoint(19.7515, 75.7139)
    val zoom = if (state.points.isEmpty()) 6.8 else 17.0
    val farmerOptions = state.farmers.map {
        DropdownOption(
            id = it.id,
            label = it.name,
            hint = buildString {
                append(it.mobile)
                if (it.village.isNotBlank()) append(" • ${it.village}")
            }
        )
    }

    ScreenScaffold(
        title = if (fieldId == null) "जमीन मोजा" else "जमीन संपादित करा",
        subtitle = if (fieldId == null) "उपग्रह नकाशावर सीमा लावा" else state.fieldName.ifBlank { "जमीन" },
        onBack = onBack,
        snackbarHostState = snackbar,
        showTopBar = !fullscreen
    ) { padding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .then(if (fullscreen) Modifier else Modifier.padding(padding))
                .imePadding()
        ) {
            val mapHeight = if (fullscreen) maxHeight else minOf(420.dp, maxHeight * 0.6f)
            Column(Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(mapHeight)
                        .then(
                            if (fullscreen) Modifier
                            else Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp)
                        )
                        .clip(RoundedCornerShape(if (fullscreen) 0.dp else 22.dp))
                        .border(
                            if (fullscreen) 0.dp else 1.dp,
                            Border,
                            RoundedCornerShape(if (fullscreen) 0.dp else 22.dp)
                        )
                ) {
                    LandMapView(
                        points = state.points,
                        currentLocation = state.currentLocation,
                        initialCenter = center,
                        initialZoom = zoom,
                        cameraTarget = state.cameraTarget,
                        satellite = satellite,
                        selectedPointIndex = state.selectedPointIndex,
                        onMapTap = viewModel::addPoint,
                        onPointMoved = viewModel::updatePoint,
                        onPointClick = viewModel::selectPoint,
                        onMapReady = { mapHolder[0] = it },
                        modifier = Modifier.fillMaxSize()
                    )

                    Column(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .padding(10.dp)
                    ) {
                        Surface(
                            color = White,
                            shape = RoundedCornerShape(14.dp),
                            shadowElevation = 6.dp
                        ) {
                            OutlinedTextField(
                                value = state.searchQuery,
                                onValueChange = viewModel::onSearchQueryChange,
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("गाव किंवा शेत शोधा") },
                                leadingIcon = {
                                    Icon(Icons.Outlined.Search, contentDescription = null, tint = Green700)
                                },
                                trailingIcon = {
                                    if (state.searching) {
                                        CircularProgressIndicator(
                                            modifier = Modifier
                                                .padding(10.dp)
                                                .size(18.dp),
                                            strokeWidth = 2.dp,
                                            color = Green700
                                        )
                                    } else {
                                        IconButton(onClick = viewModel::search) {
                                            Icon(
                                                Icons.Outlined.Search,
                                                contentDescription = "शोधा",
                                                tint = Green700
                                            )
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = { viewModel.search() }),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Green700,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedContainerColor = White,
                                    unfocusedContainerColor = White
                                )
                            )
                        }

                        if (state.searchResults.isNotEmpty()) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 6.dp)
                                    .heightIn(max = 230.dp),
                                color = White,
                                shape = RoundedCornerShape(14.dp),
                                shadowElevation = 8.dp
                            ) {
                                Column(Modifier.verticalScroll(rememberScrollState())) {
                                    state.searchResults.forEachIndexed { index, place ->
                                        Column(
                                            Modifier
                                                .fillMaxWidth()
                                                .clickable { viewModel.selectPlace(place) }
                                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                        ) {
                                            Text(
                                                place.name,
                                                style = MaterialTheme.typography.titleMedium,
                                                color = Ink,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                place.displayName,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = InkSoft,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        if (index != state.searchResults.lastIndex) {
                                            HorizontalDivider(color = Border.copy(alpha = 0.6f))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = Color(0xCC17251A),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(Modifier.padding(horizontal = 12.dp, vertical = 7.dp)) {
                                Text(
                                    text = if (state.points.isEmpty()) {
                                        "नकाशावर टॅप करून सीमा लावा • बिंदू हलवण्यासाठी दाबून ठेवा"
                                    } else {
                                        "${state.points.size} बिंदू • ${NumberText.format(state.area.acres, 3)} एकर"
                                    },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White
                                )
                                val location = state.currentLocation
                                if (location != null) {
                                    val accuracy = state.locationAccuracyMeters
                                    val accuracyText = if (accuracy != null && accuracy.isFinite() && accuracy > 0f) {
                                        " • ±${accuracy.toInt()} मी"
                                    } else {
                                        ""
                                    }
                                    Text(
                                        "GPS$accuracyText • ${formatCoordinate(location.latitude)}, ${formatCoordinate(location.longitude)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF9BE79F)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            MapControl(
                                icon = Icons.Outlined.MyLocation,
                                description = "माझे स्थान",
                                loading = state.locating,
                                onClick = ::locate
                            )
                            MapControl(
                                icon = Icons.Outlined.Add,
                                description = "झूम इन",
                                onClick = { mapHolder[0]?.controller?.zoomIn() }
                            )
                            MapControl(
                                icon = Icons.Outlined.Remove,
                                description = "झूम आउट",
                                onClick = { mapHolder[0]?.controller?.zoomOut() }
                            )
                            MapControl(
                                icon = Icons.Outlined.Layers,
                                description = if (satellite) "साधा नकाशा दाखवा" else "उपग्रह नकाशा दाखवा",
                                onClick = { satellite = !satellite }
                            )
                            MapControl(
                                icon = Icons.Outlined.Undo,
                                description = "शेवटचा बिंदू काढा",
                                enabled = state.points.isNotEmpty(),
                                onClick = viewModel::undoPoint
                            )
                            MapControl(
                                icon = Icons.Outlined.DeleteOutline,
                                description = "सर्व बिंदू काढा",
                                enabled = state.points.isNotEmpty(),
                                onClick = { confirmClear = true }
                            )
                            MapControl(
                                icon = if (fullscreen) Icons.Outlined.FullscreenExit else Icons.Outlined.Fullscreen,
                                description = if (fullscreen) "पूर्ण स्क्रीन बंद करा" else "पूर्ण स्क्रीन",
                                onClick = { fullscreen = !fullscreen }
                            )
                        }

                        Text(
                            text = if (satellite) {
                                "© Esri, Maxar • उपग्रह नकाशा"
                            } else {
                                "© OpenStreetMap • साधा नकाशा"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.85f),
                            modifier = Modifier
                                .background(Color(0x99000000), RoundedCornerShape(50))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                if (!fullscreen) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AppCard(containerColor = Green50) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            "क्षेत्रफळ",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = InkSoft
                                        )
                                        Text(
                                            "${NumberText.format(state.area.acres, 3)} एकर",
                                            style = MaterialTheme.typography.headlineSmall,
                                            color = Green900
                                        )
                                    }
                                    Text(
                                        "${state.points.size} सीमा बिंदू",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Green700
                                    )
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AreaChip("गुंठे", NumberText.format(state.area.guntha, 2), Modifier.weight(1f))
                                    AreaChip("हेक्टर", NumberText.format(state.area.hectares, 4), Modifier.weight(1f))
                                    AreaChip("चौ.मी.", NumberText.format(state.area.squareMeters, 0), Modifier.weight(1f))
                                }
                            }
                        }

                        if (state.points.isNotEmpty()) {
                            AppCard {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            "सीमा बिंदू",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = Ink,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text(
                                            "${state.points.size} बिंदू",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = Green700
                                        )
                                    }
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        "नकाशावर बिंदू दाबून ठेवा आणि ओढा. खालील यादीतून बिंदू निवडून अचूक स्थान दुरुस्त करा किंवा काढा.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = InkSoft
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    state.points.forEachIndexed { index, point ->
                                        val selected = state.selectedPointIndex == index
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(if (selected) Green50 else Color.Transparent)
                                                .clickable { viewModel.selectPoint(index) }
                                                .padding(horizontal = 6.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(28.dp)
                                                    .background(
                                                        if (selected) Color(0xFFE67E00) else Green700,
                                                        CircleShape
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    "${index + 1}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = White
                                                )
                                            }
                                            Spacer(Modifier.width(10.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(
                                                    "बिंदू ${index + 1}",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = Ink
                                                )
                                                Text(
                                                    "${formatCoordinate(point.latitude)}, ${formatCoordinate(point.longitude)}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = InkSoft
                                                )
                                            }
                                            IconButton(onClick = { viewModel.deletePoint(index) }) {
                                                Icon(
                                                    Icons.Outlined.DeleteOutline,
                                                    contentDescription = "बिंदू ${index + 1} काढा",
                                                    tint = Danger
                                                )
                                            }
                                        }
                                        if (index != state.points.lastIndex) {
                                            HorizontalDivider(color = Border.copy(alpha = 0.6f))
                                        }
                                    }

                                    val selectedIndex = state.selectedPointIndex
                                    if (selectedIndex != null && selectedIndex in state.points.indices) {
                                        Spacer(Modifier.height(10.dp))
                                        HorizontalDivider(color = Border.copy(alpha = 0.6f))
                                        Spacer(Modifier.height(10.dp))
                                        Text(
                                            "बिंदू ${selectedIndex + 1} चे अचूक स्थान",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = Ink
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            AppTextField(
                                                value = state.manualLatText,
                                                onValueChange = viewModel::onManualLatChange,
                                                label = "अक्षांश",
                                                keyboardType = KeyboardType.Decimal,
                                                modifier = Modifier.weight(1f)
                                            )
                                            AppTextField(
                                                value = state.manualLonText,
                                                onValueChange = viewModel::onManualLonChange,
                                                label = "रेखांश",
                                                keyboardType = KeyboardType.Decimal,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                        ErrorBanner(state.errors["coordinate"])
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            TextButton(
                                                onClick = viewModel::clearPointSelection,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("रद्द करा", color = InkSoft)
                                            }
                                            TextButton(
                                                onClick = viewModel::applyManualPoint,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("स्थान अद्ययावत करा", color = Green700)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        ErrorBanner(state.errors["points"] ?: state.errors["area"])

                        if (state.farmers.isEmpty()) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                InfoBanner("जमीन जतन करण्यासाठी आधी शेतकरी जोडा.")
                                PrimaryButton(
                                    text = "शेतकरी जोडा",
                                    onClick = onAddFarmer,
                                    icon = Icons.Outlined.Groups,
                                    modifier = Modifier.height(52.dp)
                                )
                            }
                        } else {
                            AppCard {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text(
                                        "जमिनीची माहिती",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Ink
                                    )
                                    LabeledDropdown(
                                        label = "शेतकरी *",
                                        options = farmerOptions,
                                        selectedId = state.selectedFarmerId,
                                        onSelected = { viewModel.onFarmerSelected(it.id) },
                                        error = state.errors["farmer"]
                                    )
                                    AppTextField(
                                        value = state.fieldName,
                                        onValueChange = viewModel::onFieldNameChange,
                                        label = "शेताचे नाव *",
                                        placeholder = "उदा. माळाचे शेत",
                                        error = state.errors["name"]
                                    )
                                    AppTextField(
                                        value = state.village,
                                        onValueChange = viewModel::onVillageChange,
                                        label = "गाव (ऐच्छिक)",
                                        placeholder = "उदा. शिरसगाव",
                                        error = state.errors["village"]
                                    )
                                    AppTextField(
                                        value = state.notes,
                                        onValueChange = viewModel::onNotesChange,
                                        label = "नोंद (ऐच्छिक)",
                                        singleLine = false,
                                        maxLines = 3,
                                        placeholder = "हद्दीची किंवा शेताची अतिरिक्त माहिती"
                                    )
                                }
                            }
                        }

                        InfoBanner(
                            "टीप: नकाशावर शेताच्या कोपऱ्यांवर क्रमाने टॅप करा. कमीत कमी ३ बिंदू लागतात. " +
                                "बिंदू दाबून ठेवून ओढा किंवा अक्षांश/रेखांश बदला — क्षेत्रफळ आपोआप पुन्हा मोजले जाते."
                        )

                        PrimaryButton(
                            text = if (fieldId == null) "जमीन जतन करा" else "बदल जतन करा",
                            onClick = viewModel::save,
                            enabled = state.farmers.isNotEmpty(),
                            loading = state.saving,
                            icon = Icons.Outlined.Save
                        )

                        if (fieldId != null) {
                            TextButton(
                                onClick = { confirmDelete = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Outlined.Delete, contentDescription = null, tint = Danger)
                                Spacer(Modifier.width(6.dp))
                                Text("ही जमीन हटवा", color = Danger)
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmClear) {
        ConfirmDialog(
            title = "सर्व बिंदू काढायचे?",
            message = "नकाशावरील सर्व सीमा बिंदू काढले जातील. जतन केलेली जमीन बदलली जाणार नाही.",
            confirmLabel = "काढा",
            destructive = true,
            onConfirm = {
                confirmClear = false
                viewModel.clearPoints()
            },
            onDismiss = { confirmClear = false }
        )
    }
    if (confirmDelete) {
        ConfirmDialog(
            title = "जमीन हटवायची?",
            message = "ही जमीन आणि तिचे क्षेत्रफळ यादीतून काढले जाईल. जुने कामाचे हिशोब सुरक्षित राहतील.",
            confirmLabel = "हटवा",
            destructive = true,
            onConfirm = {
                confirmDelete = false
                viewModel.deleteField()
            },
            onDismiss = { confirmDelete = false }
        )
    }
}

private tailrec fun android.content.Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
private fun MapControl(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    loading: Boolean = false
) {
    Surface(
        onClick = { if (enabled && !loading) onClick() },
        shape = CircleShape,
        color = White.copy(alpha = if (enabled) 0.96f else 0.6f),
        shadowElevation = 4.dp,
        modifier = Modifier.size(42.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (loading) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Green700)
            } else {
                Icon(
                    icon,
                    contentDescription = description,
                    tint = if (enabled) Green700 else Green700.copy(alpha = 0.35f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun AreaChip(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = White,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Green100)
    ) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = InkSoft)
            Text(value, style = MaterialTheme.typography.titleMedium, color = Green900)
        }
    }
}
