package com.tractormanager.app.ui.screens.payments

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.core.Money
import com.tractormanager.app.data.local.PaymentRow
import com.tractormanager.app.data.repository.BillData
import com.tractormanager.app.data.repository.FarmerListItem
import com.tractormanager.app.data.repository.FarmerRepository
import com.tractormanager.app.data.repository.PaymentRepository
import com.tractormanager.app.data.repository.ReportRepository
import com.tractormanager.app.domain.PaymentCalculator
import com.tractormanager.app.domain.PaymentSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PaymentsUiState(
    val farmers: List<FarmerListItem> = emptyList(),
    val payments: List<PaymentRow> = emptyList(),
    val summary: PaymentSummary = PaymentCalculator.summarize(0.0, 0.0)
)

class PaymentsViewModel(
    farmerRepository: FarmerRepository,
    private val paymentRepository: PaymentRepository,
    private val reportRepository: ReportRepository
) : ViewModel() {

    val state = combine(
        farmerRepository.observeWithBalances(),
        paymentRepository.observeAll()
    ) { farmers, payments ->
        val billed = farmers.sumOf { it.summary.totalBilled }
        val received = farmers.sumOf { it.summary.totalReceived }
        PaymentsUiState(
            farmers = farmers,
            payments = payments,
            summary = PaymentCalculator.summarize(billed, received)
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = PaymentsUiState()
    )

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    fun deletePayment(id: String) {
        viewModelScope.launch {
            paymentRepository.deletePayment(id).onFailure {
                _message.value = it.message ?: "पेमेंट हटवता आले नाही."
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }

    suspend fun buildBill(farmerId: String): BillData? = reportRepository.buildBill(farmerId)
}
