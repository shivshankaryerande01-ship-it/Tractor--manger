package com.tractormanager.app.ui.screens.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tractormanager.app.core.Validators
import com.tractormanager.app.data.backup.BackupRepository
import com.tractormanager.app.data.local.WorkTypeRate
import com.tractormanager.app.data.remote.FirebaseSyncRepository
import com.tractormanager.app.data.repository.AppSettings
import com.tractormanager.app.data.repository.SettingsRepository
import com.tractormanager.app.data.repository.WorkTypeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val settings: AppSettings = AppSettings(),
    val workTypes: List<WorkTypeRate> = emptyList(),
    val syncing: Boolean = false
)

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val workTypeRepository: WorkTypeRepository,
    private val backupRepository: BackupRepository,
    private val syncRepository: FirebaseSyncRepository
) : ViewModel() {

    private val syncing = MutableStateFlow(false)
    private val _message = MutableStateFlow<String?>(null)

    val message: StateFlow<String?> = _message.asStateFlow()

    val state: StateFlow<SettingsUiState> = combine(
        settingsRepository.settings,
        workTypeRepository.observeAll(),
        syncing
    ) { settings, workTypes, isSyncing ->
        SettingsUiState(settings, workTypes, isSyncing)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SettingsUiState()
    )

    fun clearMessage() {
        _message.value = null
    }

    fun enablePin(pin: String) {
        val validation = Validators.pin(pin)
        if (!validation.isValid) {
            _message.value = validation.error("pin") ?: "PIN योग्य नाही."
            return
        }
        viewModelScope.launch {
            settingsRepository.enablePin(pin)
                .onSuccess { _message.value = "PIN यशस्वीरित्या लावला गेला." }
                .onFailure { _message.value = it.message ?: "PIN लावता आला नाही." }
        }
    }

    fun changePin(currentPin: String, newPin: String) {
        if (currentPin.isBlank()) {
            _message.value = "सध्याचा PIN द्या."
            return
        }
        val validation = Validators.pin(newPin)
        if (!validation.isValid) {
            _message.value = validation.error("pin") ?: "नवीन PIN योग्य नाही."
            return
        }
        viewModelScope.launch {
            settingsRepository.changePin(currentPin, newPin)
                .onSuccess { _message.value = "PIN बदलला गेला." }
                .onFailure { _message.value = it.message ?: "PIN बदलता आला नाही." }
        }
    }

    fun disablePin(currentPin: String) {
        if (currentPin.isBlank()) {
            _message.value = "सध्याचा PIN द्या."
            return
        }
        viewModelScope.launch {
            settingsRepository.disablePin(currentPin)
                .onSuccess { _message.value = "PIN काढला गेला." }
                .onFailure { _message.value = it.message ?: "PIN काढता आला नाही." }
        }
    }

    fun setPinLockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setPinEnabled(enabled)
            _message.value = if (enabled) "ॲप उघडताना PIN विचारला जाईल." else "ॲप उघडताना PIN बंद केला."
        }
    }

    fun saveSyncSettings(url: String, code: String, token: String) {
        val validation = Validators.syncSettings(url, code)
        if (!validation.isValid) {
            _message.value = validation.errors.values.firstOrNull() ?: "सेटिंग्ज तपासा."
            return
        }
        viewModelScope.launch {
            settingsRepository.saveSyncSettings(url, code, token)
            _message.value = "सिंक सेटिंग्ज जतन झाल्या."
        }
    }

    fun saveAndSync(url: String, code: String, token: String) {
        val validation = Validators.syncSettings(url, code)
        if (!validation.isValid) {
            _message.value = validation.errors.values.firstOrNull() ?: "सेटिंग्ज तपासा."
            return
        }
        if (syncing.value) return
        viewModelScope.launch {
            settingsRepository.saveSyncSettings(url, code, token)
            syncing.value = true
            syncRepository.sync()
                .onSuccess { outcome ->
                    _message.value = "सिंक पूर्ण: ${outcome.farmerCount} शेतकरी, " +
                        "${outcome.workCount} कामे, ${outcome.paymentCount} जमा नोंदी."
                }
                .onFailure { _message.value = it.message ?: "सिंक अयशस्वी झाला." }
            syncing.value = false
        }
    }

    fun syncNow() {
        if (syncing.value) return
        viewModelScope.launch {
            syncing.value = true
            syncRepository.sync()
                .onSuccess { outcome ->
                    _message.value = "सिंक पूर्ण: ${outcome.farmerCount} शेतकरी, " +
                        "${outcome.workCount} कामे, ${outcome.paymentCount} जमा नोंदी."
                }
                .onFailure { _message.value = it.message ?: "सिंक अयशस्वी झाला." }
            syncing.value = false
        }
    }

    fun updateRate(id: String, rate: Double?) {
        if (rate == null) {
            _message.value = "दर अंकात द्या."
            return
        }
        viewModelScope.launch {
            workTypeRepository.updateRate(id, rate)
                .onSuccess { _message.value = "दर जतन झाला." }
                .onFailure { _message.value = it.message ?: "दर जतन करता आला नाही." }
        }
    }

    fun exportBackup(uri: Uri) {
        viewModelScope.launch {
            backupRepository.exportToUri(uri)
                .onSuccess { _message.value = "बॅकअप जतन झाला." }
                .onFailure { _message.value = it.message ?: "बॅकअप जतन करता आला नाही." }
        }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch {
            backupRepository.importFromUri(uri)
                .onSuccess { summary ->
                    _message.value = "पुनर्संचयित पूर्ण: ${summary.farmers} शेतकरी, " +
                        "${summary.fields} जमीन, ${summary.workRecords} कामे, ${summary.payments} जमा नोंदी."
                }
                .onFailure { _message.value = it.message ?: "बॅकअप वाचता आला नाही." }
        }
    }
}
