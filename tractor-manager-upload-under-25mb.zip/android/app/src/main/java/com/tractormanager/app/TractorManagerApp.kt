package com.tractormanager.app

import android.app.Application
import android.content.Context
import android.preference.PreferenceManager
import com.tractormanager.app.data.backup.BackupRepository
import com.tractormanager.app.data.local.AppDatabase
import com.tractormanager.app.data.remote.FirebaseSyncRepository
import com.tractormanager.app.data.repository.DashboardRepository
import com.tractormanager.app.data.repository.FarmerRepository
import com.tractormanager.app.data.repository.FieldRepository
import com.tractormanager.app.data.repository.PaymentRepository
import com.tractormanager.app.data.repository.ReportRepository
import com.tractormanager.app.data.repository.SettingsRepository
import com.tractormanager.app.data.repository.WorkRepository
import com.tractormanager.app.data.repository.WorkTypeRepository
import com.tractormanager.app.data.place.PlaceSearchRepository
import com.tractormanager.app.util.LocationHelper
import org.osmdroid.config.Configuration
import java.io.File

class AppContainer(context: Context) {
    val database: AppDatabase = AppDatabase.create(context)

    val settingsRepository = SettingsRepository(context)
    val farmerRepository = FarmerRepository(
        database.farmerDao(),
        database.workRecordDao(),
        database.paymentDao()
    )
    val fieldRepository = FieldRepository(database.landFieldDao(), database.farmerDao())
    val workRepository = WorkRepository(
        database.workRecordDao(),
        database.farmerDao(),
        database.landFieldDao()
    )
    val paymentRepository = PaymentRepository(
        database.paymentDao(),
        database.workRecordDao(),
        database.farmerDao()
    )
    val workTypeRepository = WorkTypeRepository(database.workTypeDao())
    val dashboardRepository = DashboardRepository(
        database.workRecordDao(),
        database.paymentDao(),
        database.farmerDao()
    )
    val reportRepository = ReportRepository(
        database.workRecordDao(),
        database.paymentDao(),
        database.farmerDao(),
        database.landFieldDao()
    )
    val backupRepository = BackupRepository(context, database)
    val firebaseSyncRepository = FirebaseSyncRepository(settingsRepository, backupRepository)
    val placeSearchRepository = PlaceSearchRepository()
    val locationHelper = LocationHelper(context)
}

class TractorManagerApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        configureOsmdroid()
        container = AppContainer(this)
    }

    private fun configureOsmdroid() {
        val config = Configuration.getInstance()
        config.load(this, PreferenceManager.getDefaultSharedPreferences(this))
        config.userAgentValue = packageName
        val base = File(filesDir, "osmdroid").apply { mkdirs() }
        val cache = File(cacheDir, "osmdroid-tiles").apply { mkdirs() }
        config.osmdroidBasePath = base
        config.osmdroidTileCache = cache
    }
}
