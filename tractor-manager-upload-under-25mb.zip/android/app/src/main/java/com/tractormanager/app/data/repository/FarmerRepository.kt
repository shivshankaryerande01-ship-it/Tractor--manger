package com.tractormanager.app.data.repository

import com.tractormanager.app.core.DuplicateMobileException
import com.tractormanager.app.core.Ids
import com.tractormanager.app.core.Validators
import com.tractormanager.app.core.ValidationFailureException
import com.tractormanager.app.data.local.Farmer
import com.tractormanager.app.data.local.FarmerBalanceRow
import com.tractormanager.app.data.local.FarmerDao
import com.tractormanager.app.data.local.PaymentDao
import com.tractormanager.app.data.local.WorkRecordDao
import com.tractormanager.app.domain.PaymentCalculator
import com.tractormanager.app.domain.PaymentSummary
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

data class FarmerListItem(
    val farmer: Farmer,
    val summary: PaymentSummary
)

data class FarmerAccount(
    val farmer: Farmer?,
    val summary: PaymentSummary
)

class FarmerRepository(
    private val farmerDao: FarmerDao,
    private val workRecordDao: WorkRecordDao,
    private val paymentDao: PaymentDao
) {

    fun observeFarmers(): Flow<List<Farmer>> = farmerDao.observeActive()

    fun observeWithBalances(): Flow<List<FarmerListItem>> =
        farmerDao.observeWithBalances().map { rows ->
            rows.map { it.toItem() }
        }

    fun observeFarmer(id: String): Flow<Farmer?> = farmerDao.observeById(id)

    fun observeAccount(farmerId: String): Flow<FarmerAccount> = combine(
        farmerDao.observeById(farmerId),
        workRecordDao.observeBilledForFarmer(farmerId),
        paymentDao.observeReceivedForFarmer(farmerId)
    ) { farmer, billed, received ->
        FarmerAccount(farmer, PaymentCalculator.summarize(billed, received))
    }

    suspend fun getFarmer(id: String): Farmer? = farmerDao.getById(id)

    suspend fun saveFarmer(
        id: String?,
        name: String,
        mobile: String,
        village: String
    ): Result<String> {
        val trimmedName = name.trim()
        val trimmedMobile = mobile.trim()
        val validation = Validators.farmer(trimmedName, trimmedMobile)
        if (!validation.isValid) return Result.failure(ValidationFailureException(validation))

        val duplicate = farmerDao.findByMobile(trimmedMobile)
        if (duplicate != null && duplicate.id != id) {
            return Result.failure(DuplicateMobileException())
        }

        val now = System.currentTimeMillis()
        return runCatching {
            if (id == null) {
                val newId = Ids.newId()
                farmerDao.insert(
                    Farmer(
                        id = newId,
                        name = trimmedName,
                        mobile = trimmedMobile,
                        village = village.trim(),
                        createdAt = now,
                        updatedAt = now
                    )
                )
                newId
            } else {
                val existing = farmerDao.getById(id)
                    ?: throw IllegalStateException("शेतकरी सापडला नाही.")
                farmerDao.update(
                    existing.copy(
                        name = trimmedName,
                        mobile = trimmedMobile,
                        village = village.trim(),
                        updatedAt = now
                    )
                )
                id
            }
        }
    }

    suspend fun deleteFarmer(id: String): Result<Unit> = runCatching {
        farmerDao.softDelete(id, System.currentTimeMillis())
    }

    suspend fun countActive(): Int = farmerDao.countActive()
}

private fun FarmerBalanceRow.toItem(): FarmerListItem {
    val summary = PaymentCalculator.summarize(billed, received)
    return FarmerListItem(farmer, summary)
}
