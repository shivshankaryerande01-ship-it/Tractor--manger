package com.tractormanager.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.tractormanager.app.AppContainer
import com.tractormanager.app.TractorManagerApp

@Composable
inline fun <reified VM : ViewModel> appViewModel(
    crossinline create: (AppContainer) -> VM
): VM {
    val app = LocalContext.current.applicationContext as TractorManagerApp
    return viewModel(
        factory = viewModelFactory {
            initializer { create(app.container) }
        }
    )
}
