package com.tractormanager.app.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(
    tableName = "farmers",
    indices = [
        Index(value = ["mobile"], unique = true),
        Index(value = ["name"])
    ]
)
@Serializable
data class Farmer(
    @PrimaryKey val id: String,
    val name: String,
    val mobile: String,
    val village: String = "",
    val createdAt: Long,
    val updatedAt: Long,
    val isDeleted: Boolean = false
)

@Entity(
    tableName = "land_fields",
    foreignKeys = [
        ForeignKey(
            entity = Farmer::class,
            parentColumns = ["id"],
            childColumns = ["farmerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["farmerId"])]
)
@Serializable
data class LandField(
    @PrimaryKey val id: String,
    val farmerId: String,
    val name: String,
    val village: String = "",
    val pointsJson: String,
    val areaSqm: Double,
    val areaAcres: Double,
    val areaGuntha: Double,
    val areaHectares: Double,
    val notes: String = "",
    val createdAt: Long,
    val updatedAt: Long,
    val isDeleted: Boolean = false
)

@Entity(
    tableName = "work_records",
    foreignKeys = [
        ForeignKey(
            entity = Farmer::class,
            parentColumns = ["id"],
            childColumns = ["farmerId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = LandField::class,
            parentColumns = ["id"],
            childColumns = ["fieldId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["farmerId"]),
        Index(value = ["fieldId"]),
        Index(value = ["dateEpochDay"])
    ]
)
@Serializable
data class WorkRecord(
    @PrimaryKey val id: String,
    val farmerId: String,
    val fieldId: String?,
    val workTypeId: String,
    val workTypeName: String,
    val dateEpochDay: Long,
    val acres: Double,
    val ratePerAcre: Double,
    val totalAmount: Double,
    val notes: String = "",
    val createdAt: Long,
    val updatedAt: Long,
    val isDeleted: Boolean = false
)

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = Farmer::class,
            parentColumns = ["id"],
            childColumns = ["farmerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["farmerId"]),
        Index(value = ["dateEpochDay"])
    ]
)
@Serializable
data class Payment(
    @PrimaryKey val id: String,
    val farmerId: String,
    val amount: Double,
    val dateEpochDay: Long,
    val method: String,
    val kind: String,
    val note: String = "",
    val createdAt: Long,
    val updatedAt: Long,
    val isDeleted: Boolean = false
)

@Entity(
    tableName = "work_types",
    indices = [Index(value = ["name"], unique = true)]
)
@Serializable
data class WorkTypeRate(
    @PrimaryKey val id: String,
    val name: String,
    val defaultRate: Double,
    val sortOrder: Int,
    val isDeleted: Boolean = false
)

object WorkTypeSeed {
    val defaults: List<WorkTypeRate> = listOf(
        WorkTypeRate("wt_nangrani", "नांगरणी", 1200.0, 1),
        WorkTypeRate("wt_rotavator", "रोटाव्हेटर", 1000.0, 2),
        WorkTypeRate("wt_panji", "पंजी", 800.0, 3),
        WorkTypeRate("wt_sari", "सरी", 700.0, 4),
        WorkTypeRate("wt_pali", "पाळी", 600.0, 5),
        WorkTypeRate("wt_perani", "पेरणी", 800.0, 6),
        WorkTypeRate("wt_kulwani", "कुळवणी", 900.0, 7),
        WorkTypeRate("wt_kapani", "कापणी", 1500.0, 8),
        WorkTypeRate("wt_malani", "मळणी", 1800.0, 9),
        WorkTypeRate("wt_fawarani", "फवारणी", 400.0, 10),
        WorkTypeRate("wt_vahtuk", "वाहतूक", 0.0, 11),
        WorkTypeRate("wt_itar", "इतर काम", 0.0, 12)
    )
}

data class FarmerBalanceRow(
    @androidx.room.Embedded val farmer: Farmer,
    val billed: Double,
    val received: Double
)

data class WorkRecordRow(
    @androidx.room.Embedded val work: WorkRecord,
    val farmerName: String,
    val farmerMobile: String,
    val fieldName: String?
)

data class PaymentRow(
    @androidx.room.Embedded val payment: Payment,
    val farmerName: String,
    val farmerMobile: String
)

data class WorkTotals(
    val workCount: Int,
    val acres: Double,
    val amount: Double
)

data class MoneyTotal(val amount: Double)
