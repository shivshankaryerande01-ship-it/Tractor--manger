package com.tractormanager.app.core.geo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import com.tractormanager.app.core.AreaUnits

class GeoAreaCalculatorTest {

    private val radius = GeoAreaCalculator.EARTH_RADIUS_METERS

    @Test
    fun `square at equator has expected area`() {
        val delta = 0.001
        val points = listOf(
            GeoPoint(0.0, 0.0),
            GeoPoint(0.0, delta),
            GeoPoint(delta, delta),
            GeoPoint(delta, 0.0)
        )
        val radians = Math.toRadians(delta)
        val expected = (radius * radians) * (radius * radians)
        val actual = GeoAreaCalculator.areaSquareMeters(points)
        assertEquals(expected, actual, expected * 0.01)
    }

    @Test
    fun `rectangle is proportional to its sides`() {
        val points = listOf(
            GeoPoint(18.5, 73.8),
            GeoPoint(18.5, 73.802),
            GeoPoint(18.501, 73.802),
            GeoPoint(18.501, 73.8)
        )
        val area = GeoAreaCalculator.areaSquareMeters(points)
        assertTrue("area should be a few hundred square metres", area in 5_000.0..60_000.0)
    }

    @Test
    fun `less than three points returns zero`() {
        assertEquals(0.0, GeoAreaCalculator.areaSquareMeters(emptyList()), 0.0)
        assertEquals(
            0.0,
            GeoAreaCalculator.areaSquareMeters(
                listOf(GeoPoint(18.5, 73.8), GeoPoint(18.6, 73.9))
            ),
            0.0
        )
    }

    @Test
    fun `duplicate points return zero`() {
        val point = GeoPoint(18.5, 73.8)
        assertEquals(
            0.0,
            GeoAreaCalculator.areaSquareMeters(listOf(point, point, point)),
            0.0
        )
    }

    @Test
    fun `invalid coordinates return zero`() {
        val points = listOf(
            GeoPoint(120.0, 73.8),
            GeoPoint(18.5, 73.9),
            GeoPoint(18.6, 73.7)
        )
        assertEquals(0.0, GeoAreaCalculator.areaSquareMeters(points), 0.0)
    }

    @Test
    fun `normal quad is not self intersecting`() {
        val points = listOf(
            GeoPoint(18.5, 73.8),
            GeoPoint(18.5, 73.81),
            GeoPoint(18.51, 73.81),
            GeoPoint(18.51, 73.8)
        )
        assertFalse(GeoAreaCalculator.isSelfIntersecting(points))
    }

    @Test
    fun `bow tie polygon is self intersecting`() {
        val points = listOf(
            GeoPoint(18.5, 73.8),
            GeoPoint(18.51, 73.81),
            GeoPoint(18.51, 73.8),
            GeoPoint(18.5, 73.81)
        )
        assertTrue(GeoAreaCalculator.isSelfIntersecting(points))
    }

    @Test
    fun `triangle is not self intersecting`() {
        val points = listOf(
            GeoPoint(18.5, 73.8),
            GeoPoint(18.5, 73.81),
            GeoPoint(18.51, 73.805)
        )
        assertFalse(GeoAreaCalculator.isSelfIntersecting(points))
    }

    @Test
    fun `moving a corner recalculates the measured area`() {
        val points = listOf(
            GeoPoint(18.5, 73.8),
            GeoPoint(18.5, 73.802),
            GeoPoint(18.501, 73.802),
            GeoPoint(18.501, 73.8)
        )
        val before = AreaUnits.measure(points)
        val moved = points.toMutableList().also { it[2] = GeoPoint(18.503, 73.802) }
        val after = AreaUnits.measure(moved)

        assertTrue(after.squareMeters > before.squareMeters)
        assertEquals(
            after.squareMeters / AreaUnits.SQUARE_METERS_PER_ACRE,
            after.acres,
            1e-9
        )
    }
}
