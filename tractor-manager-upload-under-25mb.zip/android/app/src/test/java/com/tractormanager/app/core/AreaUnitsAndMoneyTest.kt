package com.tractormanager.app.core

import com.tractormanager.app.core.geo.GeoPoint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AreaUnitsAndMoneyTest {

    @Test
    fun `one acre converts to guntha and hectares`() {
        val result = AreaUnits.result(AreaUnits.SQUARE_METERS_PER_ACRE)
        assertEquals(1.0, result.acres, 1e-9)
        assertEquals(40.0, result.guntha, 1e-9)
        assertEquals(0.40468564224, result.hectares, 1e-12)
    }

    @Test
    fun `zero or negative square metres gives zero`() {
        assertEquals(0.0, AreaUnits.acresFromSquareMeters(0.0), 0.0)
        assertEquals(0.0, AreaUnits.hectaresFromSquareMeters(-10.0), 0.0)
    }

    @Test
    fun `measure uses polygon area`() {
        val points = listOf(
            GeoPoint(18.5, 73.8),
            GeoPoint(18.5, 73.802),
            GeoPoint(18.501, 73.802),
            GeoPoint(18.501, 73.8)
        )
        val result = AreaUnits.measure(points)
        assertTrue(result.isMeasurable)
        assertEquals(result.acres * 40.0, result.guntha, 1e-6)
    }

    @Test
    fun `money formats with rupee and indian grouping`() {
        assertEquals("₹0", Money.format(0.0))
        assertEquals("₹1,000", Money.format(1000.0))
        assertEquals("₹12,34,567.5", Money.format(1234567.5))
        assertEquals("-₹50", Money.format(-50.0))
    }

    @Test
    fun `money rounds half up to two decimals`() {
        assertEquals(0.01, Money.round(0.005), 0.0)
        assertEquals(10.13, Money.round(10.125), 0.0)
        assertEquals(2.5, Money.round(2.5), 0.0)
    }

    @Test
    fun `money multiply rounds to paise`() {
        assertEquals(3000.0, Money.multiply(2.5, 1200.0), 0.0)
        assertEquals(0.01, Money.multiply(0.005, 1.0), 0.0)
        assertEquals(1199.7, Money.multiply(1.333, 900.0), 0.0)
    }

    @Test
    fun `formatPlain omits the rupee symbol`() {
        assertEquals("12,34,567.5", Money.formatPlain(1234567.5))
    }

    @Test
    fun `number text trims trailing zeros`() {
        assertEquals("2.5", NumberText.format(2.50, 2))
        assertEquals("3", NumberText.format(3.0, 3))
        assertEquals("2.5 एकर", NumberText.acres(2.5))
    }
}
