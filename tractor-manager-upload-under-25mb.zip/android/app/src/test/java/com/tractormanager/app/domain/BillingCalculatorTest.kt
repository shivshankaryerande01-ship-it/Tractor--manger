package com.tractormanager.app.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class BillingCalculatorTest {

    @Test
    fun `total is acres multiplied by rate`() {
        assertEquals(3000.0, BillingCalculator.total(2.5, 1200.0), 0.0)
    }

    @Test
    fun `total rounds to paise`() {
        assertEquals(1199.7, BillingCalculator.total(1.333, 900.0), 0.0)
    }

    @Test
    fun `invalid inputs give zero total`() {
        assertEquals(0.0, BillingCalculator.total(0.0, 1200.0), 0.0)
        assertEquals(0.0, BillingCalculator.total(-1.0, 1200.0), 0.0)
        assertEquals(0.0, BillingCalculator.total(2.0, -5.0), 0.0)
    }

    @Test
    fun `no work means no due`() {
        val summary = PaymentCalculator.summarize(0.0, 0.0)
        assertEquals(PaymentStatus.NO_DUE, summary.status)
        assertEquals(0.0, summary.outstanding, 0.0)
    }

    @Test
    fun `fully received bill is paid`() {
        val summary = PaymentCalculator.summarize(1000.0, 1000.0)
        assertEquals(PaymentStatus.PAID, summary.status)
        assertEquals(0.0, summary.outstanding, 0.0)
        assertEquals(0.0, summary.advance, 0.0)
    }

    @Test
    fun `some amount received is partial`() {
        val summary = PaymentCalculator.summarize(1000.0, 400.0)
        assertEquals(PaymentStatus.PARTIAL, summary.status)
        assertEquals(600.0, summary.outstanding, 0.0)
    }

    @Test
    fun `nothing received is unpaid`() {
        val summary = PaymentCalculator.summarize(1000.0, 0.0)
        assertEquals(PaymentStatus.UNPAID, summary.status)
        assertEquals(1000.0, summary.outstanding, 0.0)
    }

    @Test
    fun `extra payment becomes advance`() {
        val summary = PaymentCalculator.summarize(1000.0, 1500.0)
        assertEquals(PaymentStatus.PAID, summary.status)
        assertEquals(0.0, summary.outstanding, 0.0)
        assertEquals(500.0, summary.advance, 0.0)
        assertEquals(-500.0, summary.balance, 0.0)
    }

    @Test
    fun `payment kind reflects remaining balance`() {
        assertEquals("अ‍ॅडव्हान्स", PaymentCalculator.paymentKindFor(0.0, 0.0, 500.0))
        assertEquals("पूर्ण", PaymentCalculator.paymentKindFor(1000.0, 0.0, 1000.0))
        assertEquals("आंशिक", PaymentCalculator.paymentKindFor(1000.0, 400.0, 300.0))
        assertEquals("अ‍ॅडव्हान्स", PaymentCalculator.paymentKindFor(1000.0, 0.0, 200.0))
    }
}
