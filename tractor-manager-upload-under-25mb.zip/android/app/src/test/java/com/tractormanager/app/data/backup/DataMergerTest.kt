package com.tractormanager.app.data.backup

import com.tractormanager.app.data.local.Farmer
import com.tractormanager.app.data.local.LandField
import com.tractormanager.app.data.local.Payment
import com.tractormanager.app.data.local.WorkRecord
import com.tractormanager.app.data.local.WorkTypeRate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DataMergerTest {

    private fun farmer(
        id: String,
        mobile: String,
        updatedAt: Long,
        name: String = "शेतकरी"
    ) = Farmer(
        id = id,
        name = name,
        mobile = mobile,
        createdAt = 1L,
        updatedAt = updatedAt
    )

    private fun field(id: String, farmerId: String, updatedAt: Long = 10L) = LandField(
        id = id,
        farmerId = farmerId,
        name = "शेत",
        pointsJson = "[]",
        areaSqm = 4046.8564224,
        areaAcres = 1.0,
        areaGuntha = 40.0,
        areaHectares = 0.40468564224,
        createdAt = 1L,
        updatedAt = updatedAt
    )

    private fun work(id: String, farmerId: String, fieldId: String?, updatedAt: Long = 10L) = WorkRecord(
        id = id,
        farmerId = farmerId,
        fieldId = fieldId,
        workTypeId = "wt_nangrani",
        workTypeName = "नांगरणी",
        dateEpochDay = 20_000L,
        acres = 1.0,
        ratePerAcre = 1200.0,
        totalAmount = 1200.0,
        createdAt = 1L,
        updatedAt = updatedAt
    )

    @Test
    fun `newest record wins for same id`() {
        val local = BackupPayload(farmers = listOf(farmer("f1", "9876543210", 100, "जुने")))
        val remote = BackupPayload(farmers = listOf(farmer("f1", "9876543210", 200, "नवीन")))
        val merged = DataMerger.merge(local, remote)
        assertEquals(1, merged.farmers.size)
        assertEquals("नवीन", merged.farmers.first().name)
    }

    @Test
    fun `local newer record is kept`() {
        val local = BackupPayload(farmers = listOf(farmer("f1", "9876543210", 300, "स्थानिक")))
        val remote = BackupPayload(farmers = listOf(farmer("f1", "9876543210", 200, "दूरचा")))
        val merged = DataMerger.merge(local, remote)
        assertEquals("स्थानिक", merged.farmers.first().name)
    }

    @Test
    fun `duplicate farmers by mobile collapse to the newest`() {
        val local = BackupPayload(
            farmers = listOf(farmer("old", "9876543210", 100)),
            fields = listOf(field("field1", "old")),
            workRecords = listOf(work("w1", "old", "field1"))
        )
        val remote = BackupPayload(
            farmers = listOf(farmer("new", "9876543210", 500))
        )
        val merged = DataMerger.merge(local, remote)

        assertEquals(1, merged.farmers.size)
        assertEquals("new", merged.farmers.first().id)
        assertEquals("new", merged.fields.first().farmerId)
        assertEquals("new", merged.workRecords.first().farmerId)
    }

    @Test
    fun `children of unknown farmers are dropped`() {
        val local = BackupPayload(fields = listOf(field("field1", "missing")))
        val merged = DataMerger.merge(local, BackupPayload())
        assertTrue(merged.fields.isEmpty())
    }

    @Test
    fun `payments and fields merge without loss`() {
        val payment = Payment(
            id = "p1",
            farmerId = "f1",
            amount = 500.0,
            dateEpochDay = 20_000L,
            method = "रोख",
            kind = "आंशिक",
            createdAt = 1L,
            updatedAt = 10L
        )
        val local = BackupPayload(
            farmers = listOf(farmer("f1", "9876543210", 100)),
            payments = listOf(payment)
        )
        val remote = BackupPayload(
            farmers = listOf(farmer("f2", "9123456780", 100)),
            workTypes = listOf(WorkTypeRate("wt_x", "काम", 1000.0, 1))
        )
        val merged = DataMerger.merge(local, remote)
        assertEquals(2, merged.farmers.size)
        assertEquals(1, merged.payments.size)
        assertEquals(1, merged.workTypes.size)
    }

    @Test
    fun `backup codec round trips`() {
        val payload = BackupPayload(
            farmers = listOf(farmer("f1", "9876543210", 100, "राम")),
            fields = listOf(field("field1", "f1")),
            workRecords = listOf(work("w1", "f1", "field1")),
            workTypes = listOf(WorkTypeRate("wt_nangrani", "नांगरणी", 1200.0, 1))
        )
        val encoded = BackupCodec.encode(payload)
        val decoded = BackupCodec.decode(encoded).getOrThrow()
        assertEquals(payload.farmers, decoded.farmers)
        assertEquals(payload.fields, decoded.fields)
        assertEquals(payload.workRecords, decoded.workRecords)
        assertEquals(payload.workTypes, decoded.workTypes)
    }

    @Test
    fun `codec rejects unknown schema version`() {
        val json = """{"schemaVersion":99,"farmer":[]}"""
        val result = BackupCodec.decode(json)
        assertTrue(result.isFailure)
    }
}
