package `in`.maharashtra.tractormanager

import `in`.maharashtra.tractormanager.domain.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TractorManagerCalculationTest {

    @Test
    fun `1 acre in sq meters converts accurately to 40 gunthas and 0_405 hectares`() {
        val result = LandAreaAndBillingCalculator.convertSqMeters(4046.8564224)
        assertEquals(1.00, result.acres, 0.01)
        assertEquals(40.00, result.gunthas, 0.05)
        assertEquals(0.405, result.hectares, 0.002)
        assertEquals(1, result.wholeAcres)
    }

    @Test
    fun `polygon GPS coordinates calculate realistic farm area in acres and gunthas`() {
        val baramatiPlot = listOf(
            GpsCoordinate(18.1512, 74.5770),
            GpsCoordinate(18.1521, 74.5770),
            GpsCoordinate(18.1521, 74.57785),
            GpsCoordinate(18.1512, 74.57785)
        )
        val area = LandAreaAndBillingCalculator.computePolygonArea(baramatiPlot)
        assertTrue(area.sqMeters > 8800.0)
        assertTrue(area.acres in 2.15..2.30)
    }

    @Test
    fun `work billing formula multiplies acres by rate per acre accurately`() {
        val total = LandAreaAndBillingCalculator.calculateWorkTotal(2.5, 1600.0)
        assertEquals(4000.0, total, 0.01)
    }

    @Test
    fun `advance and partial payments compute remaining balance and status`() {
        val unpaid = LandAreaAndBillingCalculator.calculatePaymentLedger(4000.0, 0.0)
        assertEquals(PaymentStatus.UNPAID, unpaid.status)
        assertEquals(4000.0, unpaid.balanceAmount, 0.01)

        val partial = LandAreaAndBillingCalculator.calculatePaymentLedger(4000.0, 1500.0)
        assertEquals(PaymentStatus.PARTIAL, partial.status)
        assertEquals(2500.0, partial.balanceAmount, 0.01)

        val paid = LandAreaAndBillingCalculator.calculatePaymentLedger(4000.0, 4000.0)
        assertEquals(PaymentStatus.PAID, paid.status)
        assertEquals(0.0, paid.balanceAmount, 0.01)
    }
}
