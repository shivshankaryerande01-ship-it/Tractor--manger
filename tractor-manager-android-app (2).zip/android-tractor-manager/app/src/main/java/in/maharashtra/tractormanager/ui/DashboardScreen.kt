package `in`.maharashtra.tractormanager.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.maharashtra.tractormanager.data.FarmerEntity
import `in`.maharashtra.tractormanager.data.PaymentEntity
import `in`.maharashtra.tractormanager.data.TractorRepository
import `in`.maharashtra.tractormanager.data.WorkRecordEntity
import `in`.maharashtra.tractormanager.domain.LandAreaAndBillingCalculator
import `in`.maharashtra.tractormanager.domain.Mr
import `in`.maharashtra.tractormanager.util.BillPdf
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(repo: TractorRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val farmers by repo.farmers.collectAsStateWithLifecycle(initialValue = emptyList())
    val fields by repo.fields.collectAsStateWithLifecycle(initialValue = emptyList())
    val works by repo.workRecords.collectAsStateWithLifecycle(initialValue = emptyList())
    val payments by repo.payments.collectAsStateWithLifecycle(initialValue = emptyList())

    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val monthPrefix = remember { today.substring(0, 7) }

    val todaysWorks = works.filter { it.workDate == today }
    val todaysAcres = todaysWorks.sumOf { it.acres }
    val todaysIncome = todaysWorks.sumOf { it.totalAmount }
    val monthlyIncome = works.filter { it.workDate.startsWith(monthPrefix) }.sumOf { it.totalAmount }
    val totalReceived = payments.sumOf { it.amount }
    val totalBilled = works.sumOf { it.totalAmount }
    // Pending is summed per farmer so one farmer's overpayment never hides another's dues.
    val totalPending = farmers.sumOf { farmer ->
        LandAreaAndBillingCalculator.calculatePaymentLedger(
            works.filter { it.farmerId == farmer.id }.sumOf { it.totalAmount },
            payments.filter { it.farmerId == farmer.id }.sumOf { it.amount }
        ).balanceAmount
    }

    LazyColumn(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14532D))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(Mr.APP_NAME, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Text(
                        text = "$today  |  ${Mr.OFFLINE_NOTE}",
                        fontSize = 12.sp,
                        color = Color(0xFFBBF7D0),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        title = Mr.TODAYS_WORK,
                        value = "${String.format(Locale.US, "%.2f", todaysAcres)} ${Mr.ACRE}",
                        sub = "${Mr.WORK}: ${todaysWorks.size}",
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = Mr.INCOME_TODAY,
                        value = LandAreaAndBillingCalculator.formatINR(todaysIncome),
                        sub = "${Mr.INCOME_MONTH}: ${LandAreaAndBillingCalculator.formatINR(monthlyIncome)}",
                        accent = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        title = Mr.TOT_RECEIVED,
                        value = LandAreaAndBillingCalculator.formatINR(totalReceived),
                        sub = "${Mr.TOTAL_BILL}: ${LandAreaAndBillingCalculator.formatINR(totalBilled)}",
                        accent = Color(0xFF15803D),
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = Mr.PENDING,
                        value = LandAreaAndBillingCalculator.formatINR(totalPending),
                        sub = "${Mr.PAYMENT}: ${payments.size}",
                        accent = Color(0xFFDC2626),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GreenOutlineButton(
                    text = Mr.PDF_EXPORT,
                    onClick = {
                        scope.launch {
                            val file = BillPdf.generateReportPdf(context, farmers, works, payments, repo.getSettings())
                            BillPdf.shareFile(context, file, "application/pdf", Mr.PDF_EXPORT)
                        }
                    },
                    modifier = Modifier.weight(1f)
                )
                GreenOutlineButton(
                    text = Mr.CSV_EXPORT,
                    onClick = {
                        val file = BillPdf.generateReportCsv(context, farmers, fields, works, payments)
                        BillPdf.shareFile(context, file, "text/csv", Mr.CSV_EXPORT)
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item { SectionTitle("${Mr.FARMER_LIST} (${farmers.size})") }

        items(farmers, key = { it.id }) { farmer ->
            val farmerWorks = works.filter { it.farmerId == farmer.id }
            val farmerPayments = payments.filter { it.farmerId == farmer.id }
            FarmerSummaryCard(
                farmer = farmer,
                fieldsCount = fields.count { it.farmerId == farmer.id },
                works = farmerWorks,
                payments = farmerPayments,
                onOpenBill = {
                    scope.launch {
                        val settings = repo.getSettings()
                        val file = BillPdf.generateFarmerBillPdf(context, farmer, farmerWorks, farmerPayments, fields, settings)
                        BillPdf.shareBillOnWhatsApp(
                            context,
                            file,
                            BillPdf.whatsappMessage(farmer, farmerWorks, farmerPayments, settings)
                        )
                    }
                }
            )
        }

        item { SectionTitle(Mr.RECENT_WORKS) }
        items(works.take(8), key = { "w${it.id}" }) { work ->
            val farmer = farmers.find { it.id == work.farmerId }
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("${work.workType}  |  ${work.workDate}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            "${farmer?.name ?: "-"}  ${String.format(Locale.US, "%.2f", work.acres)} ${Mr.ACRE} x " +
                                LandAreaAndBillingCalculator.formatINR(work.ratePerAcre),
                            fontSize = 12.sp,
                            color = Color(0xFF335441)
                        )
                    }
                    Text(
                        LandAreaAndBillingCalculator.formatINR(work.totalAmount),
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF15803D),
                        fontSize = 15.sp
                    )
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun FarmerSummaryCard(
    farmer: FarmerEntity,
    fieldsCount: Int,
    works: List<WorkRecordEntity>,
    payments: List<PaymentEntity>,
    onOpenBill: () -> Unit
) {
    val ledger = LandAreaAndBillingCalculator.calculatePaymentLedger(
        works.sumOf { it.totalAmount },
        payments.sumOf { it.amount }
    )
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(farmer.name, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text(
                        "${farmer.village}  ${farmer.mobile}  |  ${Mr.LAND_PLOTS}: $fieldsCount",
                        fontSize = 11.5.sp,
                        color = Color(0xFF335441),
                        fontWeight = FontWeight.SemiBold
                    )
                }
                StatusChip(ledger.status)
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    "${Mr.TOTAL_BILL}: ${LandAreaAndBillingCalculator.formatINR(ledger.totalAmount)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "${Mr.RECEIVED}: ${LandAreaAndBillingCalculator.formatINR(ledger.receivedAmount)}",
                    fontSize = 12.sp,
                    color = Color(0xFF15803D),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "${Mr.BAAKI}: ${LandAreaAndBillingCalculator.formatINR(ledger.balanceAmount)}",
                    fontSize = 12.sp,
                    color = Color(0xFFDC2626),
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(8.dp))
            GreenOutlineButton(text = "${Mr.OPEN_BILL} - ${Mr.SHARE_WA}", onClick = onOpenBill)
        }
    }
}
