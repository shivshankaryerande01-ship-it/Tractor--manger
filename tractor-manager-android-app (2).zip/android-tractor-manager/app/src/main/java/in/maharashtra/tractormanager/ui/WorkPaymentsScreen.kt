package `in`.maharashtra.tractormanager.ui

import android.app.DatePickerDialog
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.maharashtra.tractormanager.data.FarmerEntity
import `in`.maharashtra.tractormanager.data.FieldEntity
import `in`.maharashtra.tractormanager.data.TractorRepository
import `in`.maharashtra.tractormanager.domain.LandAreaAndBillingCalculator
import `in`.maharashtra.tractormanager.domain.Mr
import `in`.maharashtra.tractormanager.domain.WorkRate
import `in`.maharashtra.tractormanager.util.BillPdf
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.floor

private val PAYMENT_MODES = listOf("CASH" to Mr.PAY_CASH, "UPI" to "UPI", "BANK" to Mr.PAY_BANK)

@Composable
fun WorkPaymentsScreen(repo: TractorRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val farmers by repo.farmers.collectAsStateWithLifecycle(initialValue = emptyList())
    val fields by repo.fields.collectAsStateWithLifecycle(initialValue = emptyList())
    val works by repo.workRecords.collectAsStateWithLifecycle(initialValue = emptyList())
    val payments by repo.payments.collectAsStateWithLifecycle(initialValue = emptyList())
    val settings by repo.settings.collectAsStateWithLifecycle(initialValue = null)

    val rates = remember(settings) {
        settings?.let { repo.ratesFromJson(it.ratesJson) } ?: LandAreaAndBillingCalculator.DEFAULT_WORK_RATES
    }

    // ---- Work form state ----
    var wFarmer by remember { mutableStateOf<FarmerEntity?>(null) }
    var wField by remember { mutableStateOf<FieldEntity?>(null) }
    var wType by remember { mutableStateOf<WorkRate?>(null) }
    var wDate by remember { mutableStateOf(todayStr()) }
    var wAcres by remember { mutableStateOf("") }
    var wGunthas by remember { mutableStateOf("") }
    var wRate by remember { mutableStateOf("") }
    var wNotes by remember { mutableStateOf("") }
    var wAdvance by remember { mutableStateOf("") }
    var wAdvanceMode by remember { mutableStateOf("CASH") }
    var workMessage by remember { mutableStateOf<String?>(null) }
    var workMessageIsError by remember { mutableStateOf(false) }

    // ---- Payment form state ----
    var pFarmer by remember { mutableStateOf<FarmerEntity?>(null) }
    var pAmount by remember { mutableStateOf("") }
    var pType by remember { mutableStateOf("PARTIAL") }
    var pMode by remember { mutableStateOf("CASH") }
    var pDate by remember { mutableStateOf(todayStr()) }
    var pNotes by remember { mutableStateOf("") }
    var payMessage by remember { mutableStateOf<String?>(null) }
    var payMessageIsError by remember { mutableStateOf(false) }

    var statusFilter by remember { mutableStateOf("ALL") }

    fun useField(field: FieldEntity) {
        wField = field
        val whole = floor(field.areaAcres + 1e-6)
        wAcres = whole.toInt().toString()
        wGunthas = String.format(Locale.US, "%.1f", (field.areaAcres - whole) * 40.0)
    }

    // Default work type + rate once the rate list is known.
    LaunchedEffect(rates) {
        val current = wType
        val match = rates.find { it.id == current?.id } ?: rates.firstOrNull()
        if (match != null && (current == null || wRate.isBlank())) {
            wType = match
            wRate = match.ratePerAcre.toLong().toString()
        }
    }

    // A field picked on the map screen ("record work") pre-fills this form once data has loaded.
    LaunchedEffect(farmers, fields) {
        if (farmers.isEmpty()) return@LaunchedEffect
        val pendingField = repo.pendingFieldId?.let { id -> fields.find { it.id == id } }
        val pendingFarmer = repo.pendingFarmerId?.let { id -> farmers.find { it.id == id } }
        if (pendingField != null) {
            wFarmer = farmers.find { it.id == pendingField.farmerId }
            useField(pendingField)
            repo.pendingFieldId = null
            repo.pendingFarmerId = null
        } else if (pendingFarmer != null && repo.pendingFieldId == null) {
            wFarmer = pendingFarmer
            repo.pendingFarmerId = null
        }
        if (wFarmer == null) wFarmer = farmers.first()
        if (pFarmer == null) pFarmer = wFarmer ?: farmers.first()
    }

    val decimalAcres = LandAreaAndBillingCalculator.acresGunthasToDecimal(
        wAcres.toDoubleOrNull() ?: 0.0,
        wGunthas.toDoubleOrNull() ?: 0.0
    )
    val rateValue = wRate.toDoubleOrNull() ?: 0.0
    val liveTotal = LandAreaAndBillingCalculator.calculateWorkTotal(decimalAcres, rateValue)

    LazyColumn(
        Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ============ WORK FORM ============
        item {
            SectionTitle(Mr.RECORD_WORK)
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FarmerChooser(farmers, wFarmer) {
                        wFarmer = it
                        wField = null
                    }
                    DateField(Mr.TARIKH, wDate) { wDate = it }

                    val farmerFields = fields.filter { it.farmerId == wFarmer?.id }
                    Text(Mr.FIELD, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F291E))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = wField == null,
                            onClick = { wField = null },
                            label = { Text(Mr.MANUAL_AREA, fontSize = 12.sp) }
                        )
                        farmerFields.forEach { field ->
                            FilterChip(
                                selected = wField?.id == field.id,
                                onClick = { useField(field) },
                                label = {
                                    Text(
                                        "${field.fieldName} (${String.format(Locale.US, "%.2f", field.areaAcres)} ${Mr.ACRE})",
                                        fontSize = 12.sp
                                    )
                                }
                            )
                        }
                    }

                    Text(Mr.WORK_TYPE, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F291E))
                    rates.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            pair.forEach { rate ->
                                FilterChip(
                                    selected = wType?.id == rate.id,
                                    onClick = {
                                        wType = rate
                                        wRate = rate.ratePerAcre.toLong().toString()
                                    },
                                    label = {
                                        Column {
                                            Text(rate.marathiName, fontSize = 11.5.sp, maxLines = 1)
                                            Text(
                                                LandAreaAndBillingCalculator.formatINR(rate.ratePerAcre),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LabeledField(Mr.ACRE, wAcres, { wAcres = it.filter(Char::isDigit).take(4) }, Modifier.weight(1f))
                        LabeledField(
                            Mr.GUNTHA,
                            wGunthas,
                            { text -> wGunthas = text.filter { it.isDigit() || it == '.' }.take(5) },
                            Modifier.weight(1f)
                        )
                        LabeledField(Mr.RATE, wRate, { wRate = it.filter(Char::isDigit).take(6) }, Modifier.weight(1f))
                    }

                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF14532D))) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "${String.format(Locale.US, "%.2f", decimalAcres)} ${Mr.ACRE} x " +
                                    LandAreaAndBillingCalculator.formatINR(rateValue),
                                color = Color(0xFFBBF7D0),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "= ${LandAreaAndBillingCalculator.formatINR(liveTotal)}",
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    LabeledField(Mr.ADVANCE_AMT, wAdvance, { wAdvance = it.filter(Char::isDigit).take(7) })
                    if ((wAdvance.toDoubleOrNull() ?: 0.0) > 0.0) {
                        ModeChips(wAdvanceMode) { wAdvanceMode = it }
                    }
                    LabeledField(Mr.WORK_NOTES, wNotes, { wNotes = it }, singleLine = false)

                    FormMessage(workMessage, workMessageIsError)
                    BigGreenButton("${Mr.SAVE_WORK_BTN} (${LandAreaAndBillingCalculator.formatINR(liveTotal)})", {
                        val farmer = wFarmer
                        val type = wType
                        val gunthas = wGunthas.toDoubleOrNull() ?: 0.0
                        if (farmer == null) {
                            workMessage = Mr.ERR_SELECT_FARMER
                            workMessageIsError = true
                            return@BigGreenButton
                        }
                        if (type == null || decimalAcres <= 0.0 || rateValue <= 0.0 || gunthas >= 40.0) {
                            workMessage = Mr.ERR_WORK_INPUT
                            workMessageIsError = true
                            return@BigGreenButton
                        }
                        scope.launch {
                            val result = repo.addWorkRecord(
                                farmerId = farmer.id,
                                fieldId = wField?.id,
                                workType = type.marathiName,
                                workDate = wDate,
                                acres = decimalAcres,
                                ratePerAcre = rateValue,
                                notes = wNotes,
                                advanceAmount = wAdvance.toDoubleOrNull() ?: 0.0,
                                advanceMode = wAdvanceMode
                            )
                            if (result.isSuccess) {
                                workMessage = Mr.SAVED_OK
                                workMessageIsError = false
                                wNotes = ""
                                wAdvance = ""
                            } else {
                                workMessage = result.exceptionOrNull()?.message ?: Mr.ERR_SAVE
                                workMessageIsError = true
                            }
                        }
                    })
                }
            }
        }

        // ============ PAYMENT FORM ============
        item {
            SectionTitle(Mr.RECORD_PAYMENT)
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FarmerChooser(farmers, pFarmer) { pFarmer = it }

                    val payFarmer = pFarmer
                    if (payFarmer != null) {
                        val ledger = LandAreaAndBillingCalculator.calculatePaymentLedger(
                            works.filter { it.farmerId == payFarmer.id }.sumOf { it.totalAmount },
                            payments.filter { it.farmerId == payFarmer.id }.sumOf { it.amount }
                        )
                        Text(
                            "${Mr.TOTAL_BILL}: ${LandAreaAndBillingCalculator.formatINR(ledger.totalAmount)}   " +
                                "${Mr.RECEIVED}: ${LandAreaAndBillingCalculator.formatINR(ledger.receivedAmount)}   " +
                                "${Mr.BAAKI}: ${LandAreaAndBillingCalculator.formatINR(ledger.balanceAmount)}",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF335441)
                        )
                    }

                    LabeledField(Mr.PAY_AMOUNT, pAmount, { pAmount = it.filter(Char::isDigit).take(7) })
                    DateField(Mr.TARIKH, pDate) { pDate = it }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("ADVANCE" to Mr.ADVANCE, "PARTIAL" to Mr.PAY_PARTIAL, "FINAL" to Mr.PAY_FINAL).forEach { (id, label) ->
                            FilterChip(selected = pType == id, onClick = { pType = id }, label = { Text(label, fontSize = 12.sp) })
                        }
                    }
                    ModeChips(pMode) { pMode = it }
                    LabeledField(Mr.PAY_NOTES, pNotes, { pNotes = it }, singleLine = false)

                    FormMessage(payMessage, payMessageIsError)
                    BigGreenButton(Mr.SAVE_PAYMENT_BTN, {
                        val farmer = pFarmer
                        if (farmer == null) {
                            payMessage = Mr.ERR_SELECT_FARMER
                            payMessageIsError = true
                            return@BigGreenButton
                        }
                        scope.launch {
                            val result = repo.addPayment(
                                farmerId = farmer.id,
                                workRecordId = null,
                                amount = pAmount.toDoubleOrNull() ?: 0.0,
                                type = pType,
                                mode = pMode,
                                date = pDate,
                                notes = pNotes
                            )
                            if (result.isSuccess) {
                                payMessage = Mr.SAVED_OK
                                payMessageIsError = false
                                pAmount = ""
                                pNotes = ""
                            } else {
                                payMessage = result.exceptionOrNull()?.message ?: Mr.ERR_SAVE
                                payMessageIsError = true
                            }
                        }
                    })
                }
            }
        }

        // ============ LEDGER ============
        item {
            SectionTitle(Mr.FARMER_LIST)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("ALL" to Mr.ALL, "UNPAID" to Mr.UNPAID, "PARTIAL" to Mr.PARTIAL, "PAID" to Mr.PAID).forEach { (id, label) ->
                    FilterChip(
                        selected = statusFilter == id,
                        onClick = { statusFilter = id },
                        label = { Text(label, fontSize = 12.sp) }
                    )
                }
            }
        }

        items(farmers, key = { "ledger${it.id}" }) { farmer ->
            val farmerWorks = works.filter { it.farmerId == farmer.id }
            val farmerPayments = payments.filter { it.farmerId == farmer.id }
            val ledger = LandAreaAndBillingCalculator.calculatePaymentLedger(
                farmerWorks.sumOf { it.totalAmount },
                farmerPayments.sumOf { it.amount }
            )
            if (statusFilter == "ALL" || ledger.status.name == statusFilter) {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(farmer.name, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                            StatusChip(ledger.status)
                        }
                        Text(
                            "${Mr.TOTAL_BILL} ${LandAreaAndBillingCalculator.formatINR(ledger.totalAmount)}  |  " +
                                "${Mr.RECEIVED} ${LandAreaAndBillingCalculator.formatINR(ledger.receivedAmount)}  |  " +
                                "${Mr.BAAKI} ${LandAreaAndBillingCalculator.formatINR(ledger.balanceAmount)}",
                            fontSize = 12.sp,
                            color = Color(0xFF335441),
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text("${Mr.WORK_HISTORY} (${farmerWorks.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        farmerWorks.forEach { work ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(
                                    "${work.workDate}  ${work.workType}  ${String.format(Locale.US, "%.2f", work.acres)} ${Mr.ACRE}",
                                    fontSize = 11.5.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    LandAreaAndBillingCalculator.formatINR(work.totalAmount),
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("${Mr.PAY_HISTORY} (${farmerPayments.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        farmerPayments.forEach { payment ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(
                                    "${payment.paymentDate}  ${payment.receiptNumber}  ${payment.paymentMode}",
                                    fontSize = 11.5.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    "+${LandAreaAndBillingCalculator.formatINR(payment.amount)}",
                                    fontSize = 11.5.sp,
                                    color = Color(0xFF15803D),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        BigGreenButton("${Mr.OPEN_BILL} - ${Mr.SHARE_WA}", {
                            scope.launch {
                                val current = repo.getSettings()
                                val file = BillPdf.generateFarmerBillPdf(context, farmer, farmerWorks, farmerPayments, fields, current)
                                BillPdf.shareBillOnWhatsApp(
                                    context,
                                    file,
                                    BillPdf.whatsappMessage(farmer, farmerWorks, farmerPayments, current)
                                )
                            }
                        })
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun FarmerChooser(
    farmers: List<FarmerEntity>,
    selected: FarmerEntity?,
    onSelect: (FarmerEntity?) -> Unit
) {
    if (selected == null) {
        Text(Mr.SELECT_FARMER, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F291E))
        FarmerPickerDialogInline(farmers) { onSelect(it) }
    } else {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(selected.name, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Text("${selected.village}  ${selected.mobile}", fontSize = 12.sp, color = Color(0xFF335441))
            }
            TextButton(onClick = { onSelect(null) }) { Text(Mr.EDIT) }
        }
    }
}

@Composable
private fun ModeChips(selected: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PAYMENT_MODES.forEach { (id, label) ->
            FilterChip(selected = selected == id, onClick = { onSelect(id) }, label = { Text(label, fontSize = 12.sp) })
        }
    }
}

@Composable
private fun FormMessage(text: String?, isError: Boolean) {
    if (text != null) {
        Text(
            text,
            color = if (isError) Color(0xFFDC2626) else Color(0xFF15803D),
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun DateField(label: String, value: String, onPick: (String) -> Unit) {
    val context = LocalContext.current
    Column {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F291E))
        Spacer(Modifier.height(4.dp))
        GreenOutlineButton(value, {
            val calendar = Calendar.getInstance()
            val parts = value.split("-")
            if (parts.size == 3) {
                runCatching { calendar.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt()) }
            }
            DatePickerDialog(
                context,
                { _, year, month, day -> onPick(String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)) },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }, Modifier.fillMaxWidth())
    }
}

private fun todayStr(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
