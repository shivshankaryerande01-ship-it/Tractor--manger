package `in`.maharashtra.tractormanager.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.Polygon
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState
import `in`.maharashtra.tractormanager.BuildConfig
import `in`.maharashtra.tractormanager.data.FarmerEntity
import `in`.maharashtra.tractormanager.data.FieldEntity
import `in`.maharashtra.tractormanager.data.TractorRepository
import `in`.maharashtra.tractormanager.domain.GpsCoordinate
import `in`.maharashtra.tractormanager.domain.LandAreaAndBillingCalculator
import `in`.maharashtra.tractormanager.domain.Mr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import java.util.Locale
import org.osmdroid.views.overlay.Marker as OsmMarker
import org.osmdroid.views.overlay.Polygon as OsmPolygon

private data class VillagePreset(val label: String, val lat: Double, val lng: Double)

private sealed class SearchOutcome {
    data class Found(val point: GpsCoordinate) : SearchOutcome()
    object NotFound : SearchOutcome()
    object Failed : SearchOutcome()
}

private val GreenDark = Color(0xFF14532D)
private val GreenMain = Color(0xFF15803D)

/**
 * Full-screen satellite land measurement.
 *
 * Uses Google Maps (hybrid imagery, optional 3D tilt) when the app was built with a
 * MAPS_API_KEY, otherwise the keyless Esri World Imagery map. Boundary points come only
 * from real map taps or the device's real GPS position.
 */
@Composable
fun MapMeasureScreen(
    repo: TractorRepository,
    navController: NavController,
    fullscreen: Boolean,
    onFullscreenChange: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val farmers by repo.farmers.collectAsStateWithLifecycle(initialValue = emptyList())
    val fields by repo.fields.collectAsStateWithLifecycle(initialValue = emptyList())

    val useGoogle = remember { BuildConfig.MAPS_API_KEY.isNotBlank() }

    var points by remember { mutableStateOf<List<GpsCoordinate>>(emptyList()) }
    var cameraTarget by remember { mutableStateOf(GpsCoordinate(18.1516, 74.5775)) }
    var cameraMoveId by remember { mutableStateOf(0) }
    var gpsPoint by remember { mutableStateOf<GpsCoordinate?>(null) }
    var statusMsg by remember { mutableStateOf<String?>(if (useGoogle) Mr.TAP_HINT else Mr.NO_MAPS_KEY) }
    var query by remember { mutableStateOf("") }
    var villageLabel by remember { mutableStateOf("") }
    var tilt3d by remember { mutableStateOf(false) }
    var searching by remember { mutableStateOf(false) }

    var showSaveDialog by remember { mutableStateOf(false) }
    var showFieldsDialog by remember { mutableStateOf(false) }
    var saveFarmer by remember { mutableStateOf<FarmerEntity?>(null) }
    var fieldName by remember { mutableStateOf("") }
    var gat by remember { mutableStateOf("") }
    var editingFieldId by remember { mutableStateOf<Long?>(null) }
    var dialogError by remember { mutableStateOf<String?>(null) }

    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var addPointAfterFix by remember { mutableStateOf(false) }

    val area = remember(points) { LandAreaAndBillingCalculator.computePolygonArea(points) }
    val fused = remember { LocationServices.getFusedLocationProviderClient(context) }

    val villages = remember {
        listOf(
            VillagePreset(Mr.VILLAGE_BARAMATI, 18.1516, 74.5775),
            VillagePreset(Mr.VILLAGE_NIPHAD, 20.0784, 74.1072),
            VillagePreset(Mr.VILLAGE_RAHURI, 19.3927, 74.6488),
            VillagePreset(Mr.VILLAGE_KARAD, 17.2886, 74.1844),
            VillagePreset(Mr.VILLAGE_SHIROL, 16.7332, 74.6022),
            VillagePreset(Mr.VILLAGE_MADHA, 18.0339, 75.3114),
            VillagePreset(Mr.VILLAGE_PAITHAN, 19.4769, 75.3856)
        )
    }

    fun moveCamera(target: GpsCoordinate) {
        cameraTarget = target
        cameraMoveId += 1
    }

    fun locate(addPoint: Boolean) {
        statusMsg = Mr.GPS_WAIT
        fetchFreshLocation(
            fused,
            onResult = { fix ->
                gpsPoint = fix
                moveCamera(fix)
                if (addPoint) points = points + fix
                statusMsg = Mr.GPS_OK
            },
            onFail = { statusMsg = Mr.GPS_FAILED }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        hasLocationPermission = granted[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            granted[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (hasLocationPermission) locate(addPointAfterFix) else statusMsg = Mr.GPS_DENIED
    }

    fun requestGps(addPoint: Boolean) {
        if (hasLocationPermission) {
            locate(addPoint)
        } else {
            addPointAfterFix = addPoint
            permissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }

    fun runSearch() {
        val text = query.trim()
        if (text.isEmpty() || searching) return
        searching = true
        scope.launch {
            val outcome = withContext(Dispatchers.IO) { geocode(context, text) }
            searching = false
            when (outcome) {
                is SearchOutcome.Found -> {
                    villageLabel = text
                    moveCamera(outcome.point)
                    statusMsg = text
                }
                SearchOutcome.NotFound -> statusMsg = Mr.SEARCH_NOT_FOUND
                SearchOutcome.Failed -> statusMsg = Mr.SEARCH_FAILED
            }
        }
    }

    fun loadField(field: FieldEntity, openEditor: Boolean) {
        val owner = farmers.find { it.id == field.farmerId }
        editingFieldId = field.id
        saveFarmer = owner
        fieldName = field.fieldName
        gat = field.gatNumber
        villageLabel = field.village
        val loaded = repo.parsePolygon(field.polygonJson)
        points = loaded
        if (loaded.isNotEmpty()) {
            moveCamera(GpsCoordinate(loaded.map { it.lat }.average(), loaded.map { it.lng }.average()))
        }
        showFieldsDialog = false
        if (openEditor) {
            dialogError = null
            showSaveDialog = true
        }
    }

    // A farmer chosen on the Farmers screen ("measure new field") becomes the default owner.
    LaunchedEffect(farmers) {
        val pending = repo.pendingFarmerId
        if (pending != null && farmers.isNotEmpty()) {
            saveFarmer = farmers.find { it.id == pending }
            repo.pendingFarmerId = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        // ---------------- Map layer ----------------
        if (useGoogle) {
            GoogleMapLayer(
                points = points,
                cameraTarget = cameraTarget,
                cameraMoveId = cameraMoveId,
                tilt3d = tilt3d,
                myLocationEnabled = hasLocationPermission,
                onTap = { points = points + it }
            )
        } else {
            OsmMapLayer(
                points = points,
                gpsPoint = gpsPoint,
                cameraTarget = cameraTarget,
                cameraMoveId = cameraMoveId,
                onTap = { points = points + it }
            )
        }

        // ---------------- Top overlay: search + live area ----------------
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (!fullscreen) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text(Mr.VILLAGE_SEARCH_PH, fontSize = 13.sp) },
                    trailingIcon = {
                        IconButton(onClick = { runSearch() }) {
                            Icon(Icons.Default.Search, contentDescription = Mr.SEARCH, tint = GreenMain)
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White, RoundedCornerShape(14.dp))
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    villages.forEach { village ->
                        MapButton(
                            text = village.label,
                            onClick = {
                                villageLabel = village.label
                                moveCamera(GpsCoordinate(village.lat, village.lng))
                                statusMsg = village.label
                            },
                            height = 36
                        )
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = GreenDark.copy(alpha = 0.94f))
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        AreaCell(String.format(Locale.US, "%.2f", area.acres), Mr.ACRE)
                        AreaCell(String.format(Locale.US, "%.1f", area.gunthas), Mr.GUNTHA)
                        AreaCell(String.format(Locale.US, "%.3f", area.hectares), Mr.HECTARE)
                        AreaCell("${area.perimeterMeters.toInt()} m", Mr.PERIMETER)
                    }
                    Text(
                        text = "${points.size} ${Mr.POINTS}  |  ${LandAreaAndBillingCalculator.formatMarathiArea(area.acres)}",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            val message = if (searching) Mr.SEARCHING else statusMsg
            if (message != null) {
                Text(
                    text = message,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .background(Color(0xCC0F291E), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }

        // ---------------- Side controls ----------------
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SmallFloatingActionButton(
                onClick = { onFullscreenChange(!fullscreen) },
                containerColor = Color.White,
                contentColor = GreenDark
            ) {
                Icon(
                    imageVector = if (fullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                    contentDescription = if (fullscreen) Mr.EXIT_FULLSCREEN else Mr.FULLSCREEN
                )
            }
            SmallFloatingActionButton(
                onClick = { requestGps(addPoint = false) },
                containerColor = Color.White,
                contentColor = GreenDark
            ) {
                Icon(Icons.Default.MyLocation, contentDescription = Mr.MY_LOCATION)
            }
            if (useGoogle) {
                SmallFloatingActionButton(
                    onClick = { tilt3d = !tilt3d },
                    containerColor = if (tilt3d) GreenMain else Color.White,
                    contentColor = if (tilt3d) Color.White else GreenDark
                ) {
                    Text(if (tilt3d) "2D" else "3D", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                }
            }
        }

        // ---------------- Bottom overlay: actions ----------------
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MapButton(Mr.DROP_POINT, { requestGps(addPoint = true) }, Modifier.weight(1f))
                MapButton(Mr.UNDO, { points = points.dropLast(1) }, Modifier.weight(1f))
                MapButton(
                    Mr.CLEAR_ALL,
                    {
                        points = emptyList()
                        editingFieldId = null
                    },
                    Modifier.weight(1f),
                    textColor = Color(0xFFDC2626)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MapButton(
                    text = Mr.SAVE_FIELD,
                    onClick = {
                        if (points.size >= 3) {
                            dialogError = null
                            showSaveDialog = true
                        } else {
                            statusMsg = Mr.ERR_MIN_POINTS
                        }
                    },
                    modifier = Modifier.weight(1.3f),
                    container = GreenMain,
                    textColor = Color.White,
                    height = 52
                )
                MapButton(
                    text = "${Mr.SAVED_FIELDS} (${fields.size})",
                    onClick = { showFieldsDialog = true },
                    modifier = Modifier.weight(1f),
                    height = 52
                )
            }
        }
    }

    // ---------------- Saved fields dialog ----------------
    if (showFieldsDialog) {
        AlertDialog(
            onDismissRequest = { showFieldsDialog = false },
            title = { Text("${Mr.SAVED_FIELDS} (${fields.size})") },
            text = {
                if (fields.isEmpty()) {
                    Text(Mr.NO_SAVED_FIELDS, fontSize = 13.sp)
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 420.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(fields, key = { it.id }) { field ->
                            val owner = farmers.find { it.id == field.farmerId }
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF4F7F4))) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(field.fieldName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(owner?.name ?: "-", fontSize = 12.sp, color = Color(0xFF335441))
                                    Text(
                                        "${String.format(Locale.US, "%.2f", field.areaAcres)} ${Mr.ACRE}  |  " +
                                            "${String.format(Locale.US, "%.1f", field.areaGunthas)} ${Mr.GUNTHA}  |  " +
                                            "${String.format(Locale.US, "%.3f", field.areaHectares)} ${Mr.HECTARE}",
                                        fontSize = 12.sp,
                                        color = GreenMain,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        GreenOutlineButton(Mr.LOAD, { loadField(field, openEditor = false) }, Modifier.weight(1f))
                                        GreenOutlineButton(Mr.EDIT, { loadField(field, openEditor = true) }, Modifier.weight(1f))
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        GreenOutlineButton(
                                            Mr.START_WORK,
                                            {
                                                repo.pendingFieldId = field.id
                                                repo.pendingFarmerId = field.farmerId
                                                showFieldsDialog = false
                                                onFullscreenChange(false)
                                                navController.navigate("work")
                                            },
                                            Modifier.weight(1f)
                                        )
                                        DangerButton(
                                            Mr.DELETE,
                                            { scope.launch { repo.deleteField(field) } },
                                            Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showFieldsDialog = false }) { Text(Mr.CANCEL) }
            }
        )
    }

    // ---------------- Save / edit field dialog ----------------
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text(if (editingFieldId == null) Mr.SAVE_FIELD else Mr.EDIT_FIELD) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val owner = saveFarmer
                    if (owner == null) {
                        Text(Mr.SELECT_FARMER, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        FarmerPickerDialogInline(farmers) { saveFarmer = it }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(owner.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { saveFarmer = null }) { Text(Mr.EDIT) }
                        }
                    }
                    LabeledField(Mr.FIELD_NAME, fieldName, { fieldName = it })
                    LabeledField(Mr.GAT, gat, { gat = it })
                    Text(
                        "${String.format(Locale.US, "%.2f", area.acres)} ${Mr.ACRE}  |  " +
                            "${String.format(Locale.US, "%.1f", area.gunthas)} ${Mr.GUNTHA}  |  " +
                            "${String.format(Locale.US, "%.3f", area.hectares)} ${Mr.HECTARE}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = GreenMain
                    )
                    val error = dialogError
                    if (error != null) {
                        Text(error, color = Color(0xFFDC2626), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val owner = saveFarmer
                    if (owner == null) {
                        dialogError = Mr.ERR_SELECT_FARMER
                        return@TextButton
                    }
                    scope.launch {
                        val result = repo.saveField(
                            id = editingFieldId ?: 0L,
                            farmerId = owner.id,
                            fieldName = fieldName,
                            village = villageLabel,
                            gatNumber = gat,
                            points = points
                        )
                        if (result.isSuccess) {
                            dialogError = null
                            showSaveDialog = false
                            editingFieldId = null
                            statusMsg = Mr.SAVED_OK
                        } else {
                            dialogError = result.exceptionOrNull()?.message ?: Mr.ERR_SAVE
                        }
                    }
                }) { Text(Mr.SAVE, fontWeight = FontWeight.Bold, color = GreenMain) }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) { Text(Mr.CANCEL) }
            }
        )
    }
}

// ---------------------------------------------------------------------------------------
// Google Maps layer (hybrid satellite imagery with labels, optional 3D tilt)
// ---------------------------------------------------------------------------------------
@Composable
private fun GoogleMapLayer(
    points: List<GpsCoordinate>,
    cameraTarget: GpsCoordinate,
    cameraMoveId: Int,
    tilt3d: Boolean,
    myLocationEnabled: Boolean,
    onTap: (GpsCoordinate) -> Unit
) {
    val cameraState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(cameraTarget.lat, cameraTarget.lng), 18f)
    }

    LaunchedEffect(cameraMoveId) {
        if (cameraMoveId > 0) {
            val current = cameraState.position
            cameraState.position = CameraPosition(
                LatLng(cameraTarget.lat, cameraTarget.lng),
                maxOf(current.zoom, 17f),
                current.tilt,
                current.bearing
            )
        }
    }

    LaunchedEffect(tilt3d) {
        val current = cameraState.position
        val wantedTilt = if (tilt3d) 60f else 0f
        if (current.tilt != wantedTilt) {
            cameraState.position = CameraPosition(current.target, current.zoom, wantedTilt, current.bearing)
        }
    }

    val latLngs = points.map { LatLng(it.lat, it.lng) }

    GoogleMap(
        modifier = Modifier.fillMaxSize(),
        cameraPositionState = cameraState,
        properties = MapProperties(
            mapType = MapType.HYBRID,
            isMyLocationEnabled = myLocationEnabled,
            isBuildingEnabled = true
        ),
        uiSettings = MapUiSettings(
            zoomControlsEnabled = false,
            myLocationButtonEnabled = false,
            mapToolbarEnabled = false,
            compassEnabled = true,
            tiltGesturesEnabled = true,
            rotationGesturesEnabled = true
        ),
        onMapClick = { onTap(GpsCoordinate(it.latitude, it.longitude)) }
    ) {
        if (latLngs.size >= 3) {
            Polygon(
                points = latLngs,
                fillColor = Color(0x5522C55E),
                strokeColor = Color(0xFF22C55E),
                strokeWidth = 6f
            )
        } else if (latLngs.size == 2) {
            Polyline(points = latLngs, color = Color(0xFF22C55E), width = 6f)
        }
        latLngs.forEachIndexed { index, position ->
            key(index, position.latitude, position.longitude) {
                val markerState = remember { MarkerState(position = position) }
                Marker(state = markerState, title = "${index + 1}")
            }
        }
    }
}

// ---------------------------------------------------------------------------------------
// Keyless fallback layer (Esri World Imagery through osmdroid)
// ---------------------------------------------------------------------------------------
@Composable
private fun OsmMapLayer(
    points: List<GpsCoordinate>,
    gpsPoint: GpsCoordinate?,
    cameraTarget: GpsCoordinate,
    cameraMoveId: Int,
    onTap: (GpsCoordinate) -> Unit
) {
    val context = LocalContext.current
    val currentOnTap by rememberUpdatedState(onTap)
    val polygon = remember { OsmPolygon() }

    val mapView = remember {
        Configuration.getInstance().load(context, context.getSharedPreferences("osmdroid", Context.MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = context.packageName
        MapView(context).apply {
            val esri = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"
            setTileSource(object : OnlineTileSourceBase("EsriSatellite", 0, 19, 256, "", arrayOf(esri)) {
                override fun getTileURLString(pMapTileIndex: Long): String {
                    val z = MapTileIndex.getZoom(pMapTileIndex)
                    val x = MapTileIndex.getX(pMapTileIndex)
                    val y = MapTileIndex.getY(pMapTileIndex)
                    return "$esri$z/$y/$x"
                }
            })
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(18.0)
            controller.setCenter(GeoPoint(cameraTarget.lat, cameraTarget.lng))
            overlays.add(
                MapEventsOverlay(object : MapEventsReceiver {
                    override fun singleTapConfirmedHelper(p: GeoPoint?): Boolean {
                        if (p != null) currentOnTap(GpsCoordinate(p.latitude, p.longitude))
                        return true
                    }

                    override fun longPressHelper(p: GeoPoint?): Boolean = false
                })
            )
            polygon.fillPaint.color = android.graphics.Color.argb(90, 34, 197, 94)
            polygon.outlinePaint.color = android.graphics.Color.rgb(34, 197, 94)
            polygon.outlinePaint.strokeWidth = 6f
            overlays.add(polygon)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                mapView.onDetach()
            } catch (_: Exception) {
            }
        }
    }

    LaunchedEffect(points, gpsPoint) {
        polygon.points = points.map { GeoPoint(it.lat, it.lng) }
        mapView.overlays.removeAll { it is OsmMarker }
        points.forEachIndexed { index, point ->
            val marker = OsmMarker(mapView)
            marker.position = GeoPoint(point.lat, point.lng)
            marker.title = "${index + 1}"
            marker.setAnchor(OsmMarker.ANCHOR_CENTER, OsmMarker.ANCHOR_BOTTOM)
            mapView.overlays.add(marker)
        }
        if (gpsPoint != null) {
            val marker = OsmMarker(mapView)
            marker.position = GeoPoint(gpsPoint.lat, gpsPoint.lng)
            marker.title = "GPS"
            marker.setAnchor(OsmMarker.ANCHOR_CENTER, OsmMarker.ANCHOR_CENTER)
            mapView.overlays.add(marker)
        }
        mapView.invalidate()
    }

    LaunchedEffect(cameraMoveId) {
        if (cameraMoveId > 0) {
            mapView.controller.animateTo(GeoPoint(cameraTarget.lat, cameraTarget.lng))
        }
    }

    AndroidView(factory = { mapView }, modifier = Modifier.fillMaxSize())
}

// ---------------------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------------------
@Composable
private fun MapButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    container: Color = Color.White,
    textColor: Color = GreenDark,
    height: Int = 46
) {
    Button(
        onClick = onClick,
        modifier = modifier.height(height.dp),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
        colors = ButtonDefaults.buttonColors(containerColor = container, contentColor = textColor),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)
    ) {
        Text(text, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun FarmerPickerDialogInline(farmers: List<FarmerEntity>, onSelect: (FarmerEntity) -> Unit) {
    LazyColumn(Modifier.heightIn(max = 180.dp)) {
        items(farmers, key = { it.id }) { farmer ->
            TextButton(onClick = { onSelect(farmer) }, modifier = Modifier.fillMaxWidth()) {
                Text("${farmer.name} (${farmer.village})", fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun AreaCell(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = Color(0xFFBBF7D0), fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
    }
}

/** Looks a place name up with the platform geocoder, biased to India. Runs off the main thread. */
@Suppress("DEPRECATION")
private fun geocode(context: Context, text: String): SearchOutcome {
    return try {
        if (!Geocoder.isPresent()) return SearchOutcome.Failed
        val matches = Geocoder(context, Locale("en", "IN"))
            .getFromLocationName(text, 1, 6.5, 68.0, 37.5, 97.5)
        val first = matches?.firstOrNull()
        if (first == null) SearchOutcome.NotFound else SearchOutcome.Found(GpsCoordinate(first.latitude, first.longitude))
    } catch (e: Exception) {
        SearchOutcome.Failed
    }
}

/** Requests one fresh high-accuracy fix. Never invents a position: on any failure onFail is called. */
@SuppressLint("MissingPermission")
private fun fetchFreshLocation(
    fused: FusedLocationProviderClient,
    onResult: (GpsCoordinate) -> Unit,
    onFail: () -> Unit
) {
    try {
        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { location ->
                if (location != null) onResult(GpsCoordinate(location.latitude, location.longitude)) else onFail()
            }
            .addOnFailureListener { onFail() }
    } catch (e: SecurityException) {
        onFail()
    }
}
