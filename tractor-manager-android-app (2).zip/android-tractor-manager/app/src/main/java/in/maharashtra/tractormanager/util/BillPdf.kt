package `in`.maharashtra.tractormanager.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import `in`.maharashtra.tractormanager.data.FarmerEntity
import `in`.maharashtra.tractormanager.data.FieldEntity
import `in`.maharashtra.tractormanager.data.PaymentEntity
import `in`.maharashtra.tractormanager.data.SettingsEntity
import `in`.maharashtra.tractormanager.data.WorkRecordEntity
import `in`.maharashtra.tractormanager.domain.LandAreaAndBillingCalculator
import `in`.maharashtra.tractormanager.domain.Mr
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BillPdf {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val LEFT = 40f
    private const val RIGHT = 555f
    private const val BOTTOM_LIMIT = 800f

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun inr(amount: Double): String = LandAreaAndBillingCalculator.formatINR(amount)

    private fun num(value: Double, decimals: Int = 2): String = String.format(Locale.US, "%.${decimals}f", value)

    private fun paymentTypeLabel(type: String): String = when (type) {
        "ADVANCE" -> Mr.ADVANCE
        "FINAL" -> Mr.PAY_FINAL
        else -> Mr.PAY_PARTIAL
    }

    private fun paymentModeLabel(mode: String): String = when (mode) {
        "CASH" -> Mr.PAY_CASH
        "BANK" -> Mr.PAY_BANK
        else -> mode
    }

    /** Writes lines top to bottom and starts a new page automatically when the page is full. */
    private class PageWriter(private val doc: PdfDocument) {
        val title = Paint().apply { color = Color.rgb(20, 83, 45); textSize = 20f; isFakeBoldText = true; isAntiAlias = true }
        val head = Paint().apply { color = Color.rgb(20, 83, 45); textSize = 15f; isFakeBoldText = true; isAntiAlias = true }
        val body = Paint().apply { color = Color.BLACK; textSize = 12.5f; isAntiAlias = true }
        val bold = Paint().apply { color = Color.BLACK; textSize = 13f; isFakeBoldText = true; isAntiAlias = true }
        val red = Paint().apply { color = Color.rgb(220, 38, 38); textSize = 14f; isFakeBoldText = true; isAntiAlias = true }

        private var pageNumber = 0
        private var page: PdfDocument.Page = newPage()
        private var y = 50f

        private fun newPage(): PdfDocument.Page {
            pageNumber += 1
            return doc.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
        }

        private fun ensureSpace(needed: Float) {
            if (y + needed > BOTTOM_LIMIT) {
                doc.finishPage(page)
                page = newPage()
                y = 50f
            }
        }

        fun line(text: String, paint: Paint = body, gap: Float = 18f, indent: Float = 0f) {
            ensureSpace(gap)
            page.canvas.drawText(text, LEFT + indent, y, paint)
            y += gap
        }

        fun rule() {
            ensureSpace(20f)
            page.canvas.drawLine(LEFT, y - 6f, RIGHT, y - 6f, body)
            y += 12f
        }

        fun finish() {
            doc.finishPage(page)
        }
    }

    /** Generates a Marathi PDF bill/receipt for one farmer into the cache folder. */
    fun generateFarmerBillPdf(
        context: Context,
        farmer: FarmerEntity,
        works: List<WorkRecordEntity>,
        payments: List<PaymentEntity>,
        fields: List<FieldEntity>,
        settings: SettingsEntity
    ): File {
        val doc = PdfDocument()
        val out = PageWriter(doc)

        out.line(Mr.BILL_TITLE, out.title, gap = 28f)
        out.line(settings.ownerName, out.head, gap = 20f)
        if (settings.tractorModel.isNotBlank()) out.line("${Mr.TRACTOR}: ${settings.tractorModel}")
        if (settings.ownerMobile.isNotBlank()) out.line("${Mr.MOBILE}: ${settings.ownerMobile}")
        out.line("${Mr.TARIKH}: ${today()}", gap = 22f)
        out.rule()

        out.line("${Mr.FARMER_NAME_LBL}: ${farmer.name}", out.bold)
        out.line("${Mr.VILLAGE_LBL}: ${farmer.village}   ${Mr.MOBILE}: +91 ${farmer.mobile}", gap = 22f)
        out.rule()

        out.line(Mr.WORK_HISTORY, out.head, gap = 20f)
        var totalBilled = 0.0
        var totalAcres = 0.0
        works.forEachIndexed { index, work ->
            val field = fields.find { it.id == work.fieldId }
            val fieldPart = if (field != null) "  (${field.fieldName})" else ""
            out.line("${index + 1}) ${work.workDate}  ${work.workType}$fieldPart", gap = 15f)
            out.line(
                "${num(work.acres)} ${Mr.ACRE} x ${inr(work.ratePerAcre)} = ${inr(work.totalAmount)}",
                indent = 14f
            )
            totalBilled += work.totalAmount
            totalAcres += work.acres
        }
        if (works.isEmpty()) out.line("-")
        out.rule()

        out.line(Mr.PAY_HISTORY, out.head, gap = 20f)
        var totalReceived = 0.0
        payments.forEach { payment ->
            out.line(
                "${payment.receiptNumber}  ${payment.paymentDate}  " +
                    "${paymentTypeLabel(payment.paymentType)} / ${paymentModeLabel(payment.paymentMode)}  +${inr(payment.amount)}",
                gap = 16f
            )
            totalReceived += payment.amount
        }
        if (payments.isEmpty()) out.line("-")
        out.rule()

        val ledger = LandAreaAndBillingCalculator.calculatePaymentLedger(totalBilled, totalReceived)
        out.line("${Mr.TOTAL_ACRES}: ${LandAreaAndBillingCalculator.formatMarathiArea(totalAcres)}", gap = 20f)
        out.line("${Mr.TOTAL_BILL}: ${inr(ledger.totalAmount)}", out.bold, gap = 20f)
        out.line("${Mr.RECEIVED}: ${inr(ledger.receivedAmount)}", out.bold, gap = 20f)
        out.line("${Mr.PENDING}: ${inr(ledger.balanceAmount)}  (${ledger.status.marathiLabel})", out.red, gap = 20f)
        out.finish()

        val file = File(context.cacheDir, "Tractor_Bill_${farmer.mobile}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    /** Generates the complete account report (all farmers + all work) as a PDF. */
    fun generateReportPdf(
        context: Context,
        farmers: List<FarmerEntity>,
        works: List<WorkRecordEntity>,
        payments: List<PaymentEntity>,
        settings: SettingsEntity
    ): File {
        val doc = PdfDocument()
        val out = PageWriter(doc)

        out.line(Mr.REPORT_TITLE, out.title, gap = 28f)
        out.line(settings.ownerName, out.head, gap = 20f)
        out.line("${Mr.TARIKH}: ${today()}", gap = 22f)
        out.rule()

        val totalBilled = works.sumOf { it.totalAmount }
        val totalReceived = payments.sumOf { it.amount }
        var totalPending = 0.0

        out.line(Mr.FARMER_LIST, out.head, gap = 20f)
        farmers.forEachIndexed { index, farmer ->
            val farmerWorks = works.filter { it.farmerId == farmer.id }
            val farmerPayments = payments.filter { it.farmerId == farmer.id }
            val ledger = LandAreaAndBillingCalculator.calculatePaymentLedger(
                farmerWorks.sumOf { it.totalAmount },
                farmerPayments.sumOf { it.amount }
            )
            totalPending += ledger.balanceAmount
            out.line("${index + 1}) ${farmer.name}  (${farmer.village})  ${farmer.mobile}", out.bold, gap = 16f)
            out.line(
                "${num(farmerWorks.sumOf { it.acres })} ${Mr.ACRE}   " +
                    "${Mr.TOTAL_BILL}: ${inr(ledger.totalAmount)}   " +
                    "${Mr.RECEIVED}: ${inr(ledger.receivedAmount)}   " +
                    "${Mr.BAAKI}: ${inr(ledger.balanceAmount)}   (${ledger.status.marathiLabel})",
                indent = 14f,
                gap = 20f
            )
        }
        if (farmers.isEmpty()) out.line("-")
        out.rule()

        out.line("${Mr.TOTAL_ACRES}: ${num(works.sumOf { it.acres })} ${Mr.ACRE}", gap = 20f)
        out.line("${Mr.TOTAL_BILL}: ${inr(totalBilled)}", out.bold, gap = 20f)
        out.line("${Mr.TOT_RECEIVED}: ${inr(totalReceived)}", out.bold, gap = 20f)
        out.line("${Mr.PENDING}: ${inr(totalPending)}", out.red, gap = 24f)
        out.rule()

        out.line(Mr.WORK_HISTORY, out.head, gap = 20f)
        works.forEach { work ->
            val farmer = farmers.find { it.id == work.farmerId }
            out.line(
                "${work.workDate}  ${farmer?.name ?: "-"}  ${work.workType}  " +
                    "${num(work.acres)} ${Mr.ACRE} x ${inr(work.ratePerAcre)} = ${inr(work.totalAmount)}",
                gap = 16f
            )
        }
        if (works.isEmpty()) out.line("-")
        out.finish()

        val file = File(context.cacheDir, "Tractor_Manager_Report_${today()}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    /** Generates the complete ledger as a Marathi CSV (UTF-8 with BOM so Excel opens it correctly). */
    fun generateReportCsv(
        context: Context,
        farmers: List<FarmerEntity>,
        fields: List<FieldEntity>,
        works: List<WorkRecordEntity>,
        payments: List<PaymentEntity>
    ): File {
        fun cell(text: String): String = "\"" + text.replace("\"", "\"\"") + "\""

        val sb = StringBuilder()
        sb.append('\uFEFF')
        sb.append(
            listOf(
                Mr.FARMER_NAME_LBL, Mr.MOBILE, Mr.VILLAGE_LBL, Mr.LAND_PLOTS, Mr.TOTAL_ACRES,
                Mr.TOTAL_BILL, Mr.RECEIVED, Mr.BAAKI, Mr.STATUS
            ).joinToString(",") { cell(it) }
        ).append("\n")
        farmers.forEach { farmer ->
            val farmerWorks = works.filter { it.farmerId == farmer.id }
            val farmerPayments = payments.filter { it.farmerId == farmer.id }
            val ledger = LandAreaAndBillingCalculator.calculatePaymentLedger(
                farmerWorks.sumOf { it.totalAmount },
                farmerPayments.sumOf { it.amount }
            )
            sb.append(
                listOf(
                    cell(farmer.name), farmer.mobile, cell(farmer.village),
                    fields.count { it.farmerId == farmer.id }.toString(),
                    num(farmerWorks.sumOf { it.acres }),
                    ledger.totalAmount.toLong().toString(),
                    ledger.receivedAmount.toLong().toString(),
                    ledger.balanceAmount.toLong().toString(),
                    cell(ledger.status.marathiLabel)
                ).joinToString(",")
            ).append("\n")
        }
        sb.append("\n")
        sb.append(
            listOf(
                Mr.TARIKH, Mr.FARMER_NAME_LBL, Mr.WORK_TYPE, Mr.ACRE, Mr.GUNTHA, Mr.RATE_PER_ACRE, Mr.TOTAL, Mr.NOTES_LBL
            ).joinToString(",") { cell(it) }
        ).append("\n")
        works.forEach { work ->
            val farmer = farmers.find { it.id == work.farmerId }
            sb.append(
                listOf(
                    work.workDate, cell(farmer?.name ?: ""), cell(work.workType), num(work.acres),
                    num(work.gunthas, 1), work.ratePerAcre.toLong().toString(),
                    work.totalAmount.toLong().toString(), cell(work.notes)
                ).joinToString(",")
            ).append("\n")
        }
        val file = File(context.cacheDir, "Tractor_Manager_Report_${today()}.csv")
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    /** Opens the Android share sheet for a generated file. */
    fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle))
    }

    /** Shares the PDF bill directly on WhatsApp, or through the share sheet if WhatsApp is missing. */
    fun shareBillOnWhatsApp(context: Context, file: File, message: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        fun sendIntent(): Intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, message)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            context.startActivity(sendIntent().apply { setPackage("com.whatsapp") })
        } catch (e: Exception) {
            context.startActivity(Intent.createChooser(sendIntent(), Mr.SHARE_WA))
        }
    }

    /** Builds the Marathi WhatsApp bill message for a farmer. */
    fun whatsappMessage(
        farmer: FarmerEntity,
        works: List<WorkRecordEntity>,
        payments: List<PaymentEntity>,
        settings: SettingsEntity
    ): String {
        val farmerWorks = works.filter { it.farmerId == farmer.id }
        val billed = farmerWorks.sumOf { it.totalAmount }
        val received = payments.filter { it.farmerId == farmer.id }.sumOf { it.amount }
        val ledger = LandAreaAndBillingCalculator.calculatePaymentLedger(billed, received)
        val lines = mutableListOf<String>()
        lines += "*${Mr.BILL_TITLE}*"
        lines += settings.ownerName
        if (settings.ownerMobile.isNotBlank()) lines += "${Mr.MOBILE}: ${settings.ownerMobile}"
        lines += "------------------------------"
        lines += "${Mr.FARMER_NAME_LBL}: ${farmer.name}"
        lines += "${Mr.VILLAGE_LBL}: ${farmer.village}"
        farmerWorks.forEach { work ->
            lines += "${work.workDate} ${work.workType}: ${num(work.acres)} ${Mr.ACRE} x ${inr(work.ratePerAcre)} = ${inr(work.totalAmount)}"
        }
        lines += "------------------------------"
        lines += "${Mr.TOTAL_BILL}: ${inr(ledger.totalAmount)}"
        lines += "${Mr.RECEIVED}: ${inr(ledger.receivedAmount)}"
        lines += "*${Mr.PENDING}: ${inr(ledger.balanceAmount)}* (${ledger.status.marathiLabel})"
        return lines.joinToString("\n")
    }
}
