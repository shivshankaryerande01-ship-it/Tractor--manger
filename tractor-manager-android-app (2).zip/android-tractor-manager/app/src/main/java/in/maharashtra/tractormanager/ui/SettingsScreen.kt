package `in`.maharashtra.tractormanager.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.maharashtra.tractormanager.BuildConfig
import `in`.maharashtra.tractormanager.data.CloudSyncResult
import `in`.maharashtra.tractormanager.data.TractorRepository
import `in`.maharashtra.tractormanager.domain.Mr
import `in`.maharashtra.tractormanager.domain.WorkRate
import `in`.maharashtra.tractormanager.util.BillPdf
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    repo: TractorRepository,
    onLockNow: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by repo.settings.collectAsStateWithLifecycle(initialValue = null)

    var pin by remember { mutableStateOf("") }
    var pinEnabled by remember { mutableStateOf(false) }
    var owner by remember { mutableStateOf("") }
    var ownerMobile by remember { mutableStateOf("") }
    var tractor by remember { mutableStateOf("") }
    var rates by remember { mutableStateOf<List<WorkRate>>(emptyList()) }
    var message by remember { mutableStateOf<String?>(null) }
    var messageIsError by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }

    fun show(text: String, isError: Boolean = false) {
        message = text
        messageIsError = isError
    }

    LaunchedEffect(Unit) {
        if (!loaded) {
            val current = repo.getSettings()
            pin = current.pinCode
            pinEnabled = current.pinEnabled
            owner = current.ownerName
            ownerMobile = current.ownerMobile
            tractor = current.tractorModel
            rates = repo.ratesFromJson(current.ratesJson)
            loaded = true
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val result = repo.readBackupFromUri(uri)
                if (result.isSuccess) {
                    show("${Mr.RESTORED_OK} ${result.getOrNull() ?: 0}")
                } else {
                    show(result.exceptionOrNull()?.message ?: Mr.ERR_BACKUP, isError = true)
                }
            }
        }
    }

    LazyColumn(
        Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { SectionTitle(Mr.SETTINGS_TITLE) }

        // Map provider in use (decided at build time by MAPS_API_KEY)
        item {
            Text(
                text = if (BuildConfig.MAPS_API_KEY.isNotBlank()) Mr.MAP_GOOGLE else Mr.NO_MAPS_KEY,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF335441)
            )
        }

        // PIN
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(Mr.PIN_SECTION, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    LabeledField(Mr.PIN_FIELD, pin, { pin = it.filter(Char::isDigit).take(4) })
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Mr.ENABLE_PIN, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Switch(checked = pinEnabled, onCheckedChange = { pinEnabled = it })
                    }
                }
            }
        }

        // Business info (printed on bills)
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(Mr.BUSINESS, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    LabeledField(Mr.OWNER, owner, { owner = it })
                    LabeledField(Mr.MOBILE_LBL, ownerMobile, { ownerMobile = it.filter(Char::isDigit).take(10) })
                    LabeledField(Mr.TRACTOR, tractor, { tractor = it })
                }
            }
        }

        // Per-acre rates
        item { SectionTitle(Mr.RATES_TITLE) }
        itemsIndexed(rates, key = { index, _ -> "rate$index" }) { index, rate ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(rate.marathiName, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                    LabeledField(
                        label = Mr.RATE,
                        value = rate.ratePerAcre.toLong().toString(),
                        onChange = { text ->
                            val value = text.filter(Char::isDigit).take(6).toDoubleOrNull() ?: 0.0
                            rates = rates.toMutableList().also { it[index] = it[index].copy(ratePerAcre = value) }
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        item {
            val text = message
            if (text != null) {
                Text(
                    text,
                    color = if (messageIsError) Color(0xFFDC2626) else Color(0xFF15803D),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
            }
            BigGreenButton(Mr.SAVE_SETTINGS, {
                if (pin.length != 4) {
                    show(Mr.PIN_HINT, isError = true)
                    return@BigGreenButton
                }
                scope.launch {
                    val current = repo.getSettings()
                    repo.saveSettings(
                        current.copy(
                            pinCode = pin,
                            pinEnabled = pinEnabled,
                            ownerName = owner.trim().ifBlank { Mr.APP_NAME },
                            ownerMobile = ownerMobile,
                            tractorModel = tractor.trim(),
                            ratesJson = repo.ratesToJson(rates)
                        )
                    )
                    show(Mr.SAVED_OK)
                }
            })
        }

        // Backup / restore / cloud
        item { SectionTitle(Mr.BACKUP_TITLE) }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val lastBackup = settings?.lastBackupAt.orEmpty()
                    if (lastBackup.isNotBlank()) {
                        Text("${Mr.LAST_BACKUP}: $lastBackup", fontSize = 12.sp, color = Color(0xFF335441))
                    }
                    GreenOutlineButton(Mr.DOWNLOAD_BACKUP, {
                        scope.launch {
                            val file = repo.writeLocalBackup()
                            if (file != null) {
                                BillPdf.shareFile(context, file, "application/json", Mr.DOWNLOAD_BACKUP)
                            } else {
                                show(Mr.ERR_SAVE, isError = true)
                            }
                        }
                    }, Modifier.fillMaxWidth())
                    GreenOutlineButton(Mr.RESTORE_BACKUP, {
                        importLauncher.launch("*/*")
                    }, Modifier.fillMaxWidth())
                    GreenOutlineButton(Mr.SYNC_NOW, {
                        scope.launch {
                            when (repo.syncToFirestore()) {
                                CloudSyncResult.SYNCED -> show(Mr.CLOUD_OK)
                                CloudSyncResult.NOT_CONFIGURED -> show(Mr.CLOUD_NOT_SET, isError = true)
                                CloudSyncResult.FAILED -> show(Mr.CLOUD_FAILED, isError = true)
                            }
                        }
                    }, Modifier.fillMaxWidth())
                    DangerButton(Mr.LOCK_NOW_BTN, { onLockNow() }, Modifier.fillMaxWidth())
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
