package `in`.maharashtra.tractormanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import `in`.maharashtra.tractormanager.data.TractorRepository
import `in`.maharashtra.tractormanager.domain.Mr
import `in`.maharashtra.tractormanager.ui.DashboardScreen
import `in`.maharashtra.tractormanager.ui.FarmersScreen
import `in`.maharashtra.tractormanager.ui.MapMeasureScreen
import `in`.maharashtra.tractormanager.ui.PinLockScreen
import `in`.maharashtra.tractormanager.ui.SettingsScreen
import `in`.maharashtra.tractormanager.ui.TractorManagerTheme
import `in`.maharashtra.tractormanager.ui.WorkPaymentsScreen
import `in`.maharashtra.tractormanager.util.BackupWorker

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = (application as TractorApplication).repository
        BackupWorker.enqueuePeriodic(applicationContext)
        setContent {
            TractorManagerTheme {
                Surface(color = Color(0xFFF4F7F4)) {
                    TractorApp(repo)
                }
            }
        }
    }
}

private data class NavItem(val route: String, val label: String, val icon: ImageVector)

@Composable
fun TractorApp(repo: TractorRepository) {
    var unlocked by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(true) }
    var pinCode by remember { mutableStateOf("") }
    var ownerName by remember { mutableStateOf("") }
    var mapFullscreen by remember { mutableStateOf(false) }

    LaunchedEffect(unlocked) {
        // Re-read on every lock so a PIN changed in Settings applies immediately.
        if (!unlocked) {
            val settings = repo.getSettings()
            pinCode = settings.pinCode
            ownerName = settings.ownerName
            if (checking) {
                unlocked = !settings.pinEnabled
                checking = false
            }
        }
    }

    if (checking) return
    if (!unlocked) {
        PinLockScreen(expectedPin = pinCode, ownerName = ownerName) { unlocked = true }
        return
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val items = listOf(
        NavItem("dashboard", Mr.NAV_DASHBOARD, Icons.Default.Agriculture),
        NavItem("map", Mr.NAV_MAP, Icons.Default.Map),
        NavItem("farmers", Mr.NAV_FARMERS, Icons.Default.People),
        NavItem("work", Mr.NAV_WORK, Icons.Default.ReceiptLong),
        NavItem("settings", Mr.NAV_SETTINGS, Icons.Default.Settings)
    )
    val hideBottomBar = currentRoute == "map" && mapFullscreen

    Scaffold(
        bottomBar = {
            if (!hideBottomBar) {
                NavigationBar(containerColor = Color.White) {
                    items.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.startDestinationId) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(item.label, fontSize = 10.sp, maxLines = 1) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "dashboard",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("dashboard") {
                DashboardScreen(repo = repo)
            }
            composable("map") {
                MapMeasureScreen(
                    repo = repo,
                    navController = navController,
                    fullscreen = mapFullscreen,
                    onFullscreenChange = { mapFullscreen = it }
                )
            }
            composable("farmers") {
                FarmersScreen(repo = repo) { farmerId ->
                    repo.pendingFarmerId = farmerId
                    navController.navigate("map")
                }
            }
            composable("work") {
                WorkPaymentsScreen(repo = repo)
            }
            composable("settings") {
                SettingsScreen(repo = repo, onLockNow = { unlocked = false })
            }
        }
    }
}
