package `in`.maharashtra.tractormanager.domain

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.sqrt

data class GpsCoordinate(val lat: Double, val lng: Double)

data class LandMeasurement(
    val sqMeters: Double,
    val acres: Double,
    val gunthas: Double,
    val hectares: Double,
    val wholeAcres: Int,
    val remainingGunthas: Double,
    val perimeterMeters: Double = 0.0
)

enum class PaymentStatus(val marathiLabel: String) {
    PAID("पूर्ण जमा"),
    PARTIAL("\u0905\u0902\u0936\u0924\u0903 \u092C\u093E\u0915\u0940"),
    UNPAID("पूर्ण बाकी")
}

data class LedgerSummary(
    val totalAmount: Double,
    val receivedAmount: Double,
    val balanceAmount: Double,
    val status: PaymentStatus
)

data class WorkRate(
    val id: String,
    val marathiName: String,
    val englishName: String,
    val ratePerAcre: Double
)

object LandAreaAndBillingCalculator {
    private const val EARTH_RADIUS_METERS = 6378137.0
    const val SQ_METERS_PER_ACRE = 4046.8564224
    const val SQ_METERS_PER_GUNTHA = 101.17141056
    const val SQ_METERS_PER_HECTARE = 10000.0
    const val GUNTHAS_PER_ACRE = 40.0

    val DEFAULT_WORK_RATES = listOf(
        WorkRate("ploughing", "नांगरणी (पलटी नांगर)", "Ploughing (MB Plough)", 1600.0),
        WorkRate("rotavator", "रोटाव्हेटर (६ फूट)", "Rotavator Tilling", 1200.0),
        WorkRate("sowing", "पेरणी (सीड ड्रिल)", "Seed Drill Sowing", 1000.0),
        WorkRate("cultivator", "कल्ह" + "िव्हेटर (९ फणी)", "Cultivator (9-Tyne)", 900.0),
        WorkRate("ridger", "सरी पाडणे (रिजर)", "Ridger / Furrow", 1100.0),
        WorkRate("threshing", "थ्रेशर मळणी", "Crop Threshing", 1500.0),
        WorkRate("laser_level", "लेझर जमीन सपाटीकरण", "Laser Land Leveling", 1800.0)
    )

    fun haversineMeters(p1: GpsCoordinate, p2: GpsCoordinate): Double {
        val dLat = Math.toRadians(p2.lat - p1.lat)
        val dLng = Math.toRadians(p2.lng - p1.lng)
        val lat1 = Math.toRadians(p1.lat)
        val lat2 = Math.toRadians(p2.lat)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(lat1) * cos(lat2) * sin(dLng / 2) * sin(dLng / 2)
        return EARTH_RADIUS_METERS * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    fun computePolygonArea(points: List<GpsCoordinate>): LandMeasurement {
        if (points.size < 3) {
            val perimeter = if (points.size == 2) haversineMeters(points[0], points[1]) else 0.0
            return LandMeasurement(0.0, 0.0, 0.0, 0.0, 0, 0.0, perimeter)
        }
        var totalAngle = 0.0
        var perimeter = 0.0
        for (i in points.indices) {
            val p1 = points[i]
            val p2 = points[(i + 1) % points.size]
            perimeter += haversineMeters(p1, p2)
            val lat1 = Math.toRadians(p1.lat)
            val lng1 = Math.toRadians(p1.lng)
            val lat2 = Math.toRadians(p2.lat)
            val lng2 = Math.toRadians(p2.lng)
            totalAngle += (lng2 - lng1) * (2.0 + sin(lat1) + sin(lat2))
        }
        val sqMeters = abs(totalAngle * EARTH_RADIUS_METERS * EARTH_RADIUS_METERS / 2.0)
        return convertSqMeters(sqMeters).copy(perimeterMeters = round(perimeter * 10.0) / 10.0)
    }

    fun convertSqMeters(sqMeters: Double): LandMeasurement {
        val safeSq = max(0.0, sqMeters)
        val acres = safeSq / SQ_METERS_PER_ACRE
        val gunthas = safeSq / SQ_METERS_PER_GUNTHA
        val hectares = safeSq / SQ_METERS_PER_HECTARE
        val wholeAcres = floor(acres + 1e-6).toInt()
        val remGunthas = max(0.0, (acres - wholeAcres) * GUNTHAS_PER_ACRE)
        return LandMeasurement(
            sqMeters = round(safeSq * 100.0) / 100.0,
            acres = round(acres * 100.0) / 100.0,
            gunthas = round(gunthas * 100.0) / 100.0,
            hectares = round(hectares * 1000.0) / 1000.0,
            wholeAcres = wholeAcres,
            remainingGunthas = round(remGunthas * 10.0) / 10.0
        )
    }

    fun acresGunthasToDecimal(wholeAcres: Double, gunthas: Double): Double {
        val a = max(0.0, wholeAcres)
        val g = max(0.0, gunthas)
        return round((a + g / GUNTHAS_PER_ACRE) * 1000.0) / 1000.0
    }

    fun calculateWorkTotal(acres: Double, ratePerAcre: Double): Double {
        require(acres >= 0.0)
        require(ratePerAcre >= 0.0)
        return round(max(0.0, acres) * max(0.0, ratePerAcre))
    }

    fun calculatePaymentLedger(totalBilled: Double, totalReceived: Double): LedgerSummary {
        val billed = max(0.0, round(totalBilled))
        val received = max(0.0, round(totalReceived))
        val balance = max(0.0, billed - received)
        val status = when {
            billed > 0 && received >= billed -> PaymentStatus.PAID
            received > 0 && received < billed -> PaymentStatus.PARTIAL
            billed == 0.0 && received == 0.0 -> PaymentStatus.PAID
            else -> PaymentStatus.UNPAID
        }
        return LedgerSummary(billed, received, balance, status)
    }

    fun formatINR(amount: Double): String {
        val rounded = round(amount).toLong()
        return "₹" + NumberFormat.getIntegerInstance(Locale("en", "IN")).format(rounded)
    }

    fun formatMarathiArea(acres: Double): String {
        val a = max(0.0, acres)
        val whole = floor(a + 1e-6).toInt()
        var g = round((a - whole) * 40.0).toInt()
        var w = whole
        if (g >= 40) { w += 1; g -= 40 }
        return w.toString() + " \u090F\u0915\u0930 " + g.toString() + " \u0917\u0941\u0902\u0920\u0947 (" + String.format(Locale.US, "%.2f", a) + " \u090F\u0915\u0930)"
    }

    fun isValidIndianMobile(mobile: String): Boolean {
        val cleaned = mobile.filter { it.isDigit() }
        return Regex("^[6-9]\\d{9}$").matches(cleaned)
    }
}
