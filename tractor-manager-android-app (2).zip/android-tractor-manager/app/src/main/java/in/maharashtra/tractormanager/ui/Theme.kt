package `in`.maharashtra.tractormanager.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GreenDark = Color(0xFF14532D)
private val GreenPrimary = Color(0xFF15803D)
private val GreenLight = Color(0xFF22C55E)
private val GreenBg = Color(0xFFF4F7F4)
private val InkDark = Color(0xFF0F291E)

private val LightColors = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCFCE7),
    onPrimaryContainer = GreenDark,
    secondary = GreenLight,
    background = GreenBg,
    surface = Color.White,
    onSurface = InkDark,
    onBackground = InkDark,
    error = Color(0xFFDC2626)
)

private val DarkColors = darkColorScheme(
    primary = GreenLight,
    onPrimary = GreenDark,
    background = Color(0xFF0B1F14),
    surface = Color(0xFF12291B),
    onSurface = Color(0xFFE7F5EA),
    onBackground = Color(0xFFE7F5EA)
)

@Composable
fun TractorManagerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
