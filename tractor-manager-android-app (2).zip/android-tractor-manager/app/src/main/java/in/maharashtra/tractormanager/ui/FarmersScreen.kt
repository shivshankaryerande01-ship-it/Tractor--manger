package `in`.maharashtra.tractormanager.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import `in`.maharashtra.tractormanager.data.FarmerEntity
import `in`.maharashtra.tractormanager.data.TractorRepository
import `in`.maharashtra.tractormanager.domain.Mr
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun FarmersScreen(
    repo: TractorRepository,
    onMeasureNewField: (farmerId: Long) -> Unit
) {
    val scope = rememberCoroutineScope()
    val farmers by repo.farmers.collectAsStateWithLifecycle(initialValue = emptyList())
    val fields by repo.fields.collectAsStateWithLifecycle(initialValue = emptyList())

    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<FarmerEntity?>(null) }
    var pendingDelete by remember { mutableStateOf<FarmerEntity?>(null) }
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var village by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var formError by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }

    fun openAdd() {
        editing = null
        name = ""
        mobile = ""
        village = ""
        notes = ""
        formError = null
        showDialog = true
    }

    fun openEdit(farmer: FarmerEntity) {
        editing = farmer
        name = farmer.name
        mobile = farmer.mobile
        village = farmer.village
        notes = farmer.notes
        formError = null
        showDialog = true
    }

    val filtered = farmers.filter {
        query.isBlank() || it.name.contains(query, true) || it.mobile.contains(query) || it.village.contains(query, true)
    }

    Scaffold(
        containerColor = Color.Transparent,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { openAdd() },
                containerColor = Color(0xFF15803D),
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text(Mr.ADD_FARMER_BTN, fontWeight = FontWeight.Bold) }
            )
        }
    ) { inner ->
        LazyColumn(
            modifier = Modifier
                .padding(inner)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { LabeledField(label = Mr.SEARCH_FARMER, value = query, onChange = { query = it }) }
            item { SectionTitle("${Mr.FARMER_LIST} (${farmers.size})") }
            items(filtered, key = { it.id }) { farmer ->
                val farmerFields = fields.filter { it.farmerId == farmer.id }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(farmer.name, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                Text(
                                    "+91 ${farmer.mobile}",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF15803D)
                                )
                                if (farmer.village.isNotBlank()) {
                                    Text("${Mr.VILLAGE_LBL}: ${farmer.village}", fontSize = 12.sp, color = Color(0xFF335441))
                                }
                                if (farmer.notes.isNotBlank()) {
                                    Text(farmer.notes, fontSize = 11.5.sp, color = Color(0xFF335441))
                                }
                            }
                            Row {
                                IconButton(onClick = { openEdit(farmer) }) {
                                    Icon(Icons.Default.Edit, contentDescription = Mr.EDIT, tint = Color(0xFF15803D))
                                }
                                IconButton(onClick = { pendingDelete = farmer }) {
                                    Icon(Icons.Default.Delete, contentDescription = Mr.DELETE, tint = Color(0xFFDC2626))
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "${Mr.LAND_PLOTS}: ${farmerFields.size}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F291E)
                        )
                        farmerFields.forEach { field ->
                            Text(
                                "${field.fieldName}: " +
                                    "${String.format(Locale.US, "%.2f", field.areaAcres)} ${Mr.ACRE} | " +
                                    "${String.format(Locale.US, "%.1f", field.areaGunthas)} ${Mr.GUNTHA} | " +
                                    "${String.format(Locale.US, "%.3f", field.areaHectares)} ${Mr.HECTARE}",
                                fontSize = 11.5.sp,
                                color = Color(0xFF335441)
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        GreenOutlineButton(text = Mr.MEASURE_NEW, onClick = { onMeasureNewField(farmer.id) })
                    }
                }
            }
            item { Spacer(Modifier.height(88.dp)) }
        }
    }

    // Deleting a farmer also removes their fields, work records and payments, so confirm first.
    val toDelete = pendingDelete
    if (toDelete != null) {
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(toDelete.name) },
            text = { Text(Mr.CONFIRM_DELETE_FARMER, fontSize = 14.sp) },
            confirmButton = {
                TextButton(onClick = {
                    pendingDelete = null
                    scope.launch { repo.deleteFarmer(toDelete) }
                }) { Text(Mr.YES_DELETE, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text(Mr.CANCEL) }
            }
        )
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(if (editing == null) Mr.ADD_FARMER_BTN else Mr.EDIT_FARMER) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LabeledField(Mr.FARMER_NAME_LBL, name, { name = it })
                    LabeledField(Mr.MOBILE_LBL, mobile, { mobile = it.filter(Char::isDigit).take(10) })
                    LabeledField(Mr.VILLAGE_LBL, village, { village = it })
                    LabeledField(Mr.NOTES_LBL, notes, { notes = it }, singleLine = false)
                    val error = formError
                    if (error != null) {
                        Text(error, color = Color(0xFFDC2626), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val current = editing
                        val result = if (current == null) {
                            repo.addFarmer(name, mobile, village, notes).map { }
                        } else {
                            repo.updateFarmer(
                                current.copy(
                                    name = name.trim(),
                                    mobile = mobile.filter(Char::isDigit),
                                    village = village.trim(),
                                    notes = notes.trim()
                                )
                            )
                        }
                        if (result.isSuccess) {
                            formError = null
                            showDialog = false
                        } else {
                            formError = result.exceptionOrNull()?.message ?: Mr.ERR_SAVE
                        }
                    }
                }) { Text(Mr.SAVE, fontWeight = FontWeight.Bold, color = Color(0xFF15803D)) }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text(Mr.CANCEL) }
            }
        )
    }
}
