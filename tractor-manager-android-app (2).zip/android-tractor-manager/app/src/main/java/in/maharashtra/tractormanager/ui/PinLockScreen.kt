package `in`.maharashtra.tractormanager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.maharashtra.tractormanager.domain.Mr

private const val KEY_CLEAR = "C"
private const val KEY_BACK = "<"

/** 4-digit PIN gate. Never displays the expected PIN. */
@Composable
fun PinLockScreen(
    expectedPin: String,
    ownerName: String,
    onUnlocked: () -> Unit
) {
    var entered by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }

    fun press(digit: String) {
        wrong = false
        if (entered.length >= 4) return
        entered += digit
        if (entered.length == 4) {
            if (entered == expectedPin) {
                onUnlocked()
            } else {
                wrong = true
                entered = ""
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF14532D)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    modifier = Modifier
                        .size(56.dp)
                        .background(Color(0xFF15803D), RoundedCornerShape(16.dp))
                        .padding(12.dp),
                    tint = Color.White
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = Mr.PIN_LOCK_TITLE,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F291E)
                )
                if (ownerName.isNotBlank()) {
                    Text(text = ownerName, fontSize = 13.sp, color = Color(0xFF335441))
                }
                Text(text = Mr.PIN_HINT, fontSize = 13.sp, color = Color(0xFF15803D), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    (0..3).forEach { index ->
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .background(
                                    if (entered.length > index) Color(0xFF15803D) else Color(0xFFD1E2D4),
                                    RoundedCornerShape(10.dp)
                                )
                        )
                    }
                }
                if (wrong) {
                    Spacer(Modifier.height(8.dp))
                    Text(text = Mr.PIN_WRONG, color = Color(0xFFDC2626), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(16.dp))

                val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", KEY_CLEAR, "0", KEY_BACK)
                for (row in 0..3) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        for (col in 0..2) {
                            val key = keys[row * 3 + col]
                            val keyModifier = Modifier
                                .height(64.dp)
                                .width(88.dp)
                            when (key) {
                                KEY_CLEAR -> OutlinedButton(
                                    onClick = {
                                        entered = ""
                                        wrong = false
                                    },
                                    modifier = keyModifier
                                ) { Text(Mr.PIN_CLEAR, fontSize = 13.sp, maxLines = 1) }

                                KEY_BACK -> OutlinedButton(
                                    onClick = {
                                        entered = entered.dropLast(1)
                                        wrong = false
                                    },
                                    modifier = keyModifier
                                ) { Text("\u232B", fontSize = 20.sp) }

                                else -> Button(
                                    onClick = { press(key) },
                                    modifier = keyModifier,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFFF4F7F4),
                                        contentColor = Color(0xFF0F291E)
                                    )
                                ) { Text(key, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}
