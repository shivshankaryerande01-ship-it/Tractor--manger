package `in`.maharashtra.tractormanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "farmers",
    indices = [Index(value = ["mobile"], unique = true)] // duplicate mobile prevention
)
data class FarmerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val mobile: String,
    val village: String,
    val notes: String = "",
    val syncedToFirebase: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "fields",
    foreignKeys = [
        ForeignKey(
            entity = FarmerEntity::class,
            parentColumns = ["id"],
            childColumns = ["farmerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("farmerId")]
)
data class FieldEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmerId: Long,
    val fieldName: String,
    val village: String,
    val gatNumber: String = "",
    val polygonJson: String, // JSONArray of {lat,lng}
    val areaSqMeters: Double,
    val areaAcres: Double,
    val areaGunthas: Double,
    val areaHectares: Double,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "work_records",
    foreignKeys = [
        ForeignKey(
            entity = FarmerEntity::class,
            parentColumns = ["id"],
            childColumns = ["farmerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("farmerId"), Index("workDate")]
)
data class WorkRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmerId: Long,
    val fieldId: Long?,
    val workType: String,
    val workDate: String, // yyyy-MM-dd
    val acres: Double,
    val gunthas: Double,
    val ratePerAcre: Double,
    val totalAmount: Double,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = FarmerEntity::class,
            parentColumns = ["id"],
            childColumns = ["farmerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("farmerId")]
)
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmerId: Long,
    val workRecordId: Long?,
    val amount: Double,
    val paymentType: String, // ADVANCE | PARTIAL | FINAL
    val paymentMode: String, // CASH | UPI | BANK
    val paymentDate: String,
    val receiptNumber: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "settings")
data class SettingsEntity(
    @PrimaryKey val id: Int = 1,
    val pinCode: String = "1234",
    val pinEnabled: Boolean = false,
    val ownerName: String = "",
    val ownerMobile: String = "",
    val tractorModel: String = "",
    val ratesJson: String = "[]",
    val lastBackupAt: String = ""
)

@Dao
interface TractorDao {
    // Farmers
    @Query("SELECT * FROM farmers ORDER BY id DESC")
    fun observeFarmers(): Flow<List<FarmerEntity>>

    @Query("SELECT * FROM farmers WHERE id = :id")
    suspend fun getFarmer(id: Long): FarmerEntity?

    @Query("SELECT * FROM farmers WHERE mobile = :mobile LIMIT 1")
    suspend fun farmerByMobile(mobile: String): FarmerEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertFarmer(farmer: FarmerEntity): Long

    @Update
    suspend fun updateFarmer(farmer: FarmerEntity)

    @Delete
    suspend fun deleteFarmer(farmer: FarmerEntity)

    // Fields
    @Query("SELECT * FROM fields ORDER BY id DESC")
    fun observeFields(): Flow<List<FieldEntity>>

    @Query("SELECT * FROM fields WHERE farmerId = :farmerId ORDER BY id DESC")
    fun observeFieldsForFarmer(farmerId: Long): Flow<List<FieldEntity>>

    @Query("SELECT * FROM fields WHERE farmerId = :farmerId AND fieldName = :fieldName LIMIT 1")
    suspend fun fieldByName(farmerId: Long, fieldName: String): FieldEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveField(field: FieldEntity): Long

    @Delete
    suspend fun deleteField(field: FieldEntity)

    // Work records
    @Query("SELECT * FROM work_records ORDER BY workDate DESC, id DESC")
    fun observeWorkRecords(): Flow<List<WorkRecordEntity>>

    @Query("SELECT * FROM work_records WHERE farmerId = :farmerId ORDER BY workDate DESC, id DESC")
    fun observeWorksForFarmer(farmerId: Long): Flow<List<WorkRecordEntity>>

    @Query(
        "SELECT * FROM work_records WHERE farmerId = :farmerId AND workDate = :date " +
            "AND workType = :workType AND ((:fieldId IS NULL AND fieldId IS NULL) OR fieldId = :fieldId) LIMIT 1"
    )
    suspend fun findDuplicateWork(
        farmerId: Long,
        date: String,
        workType: String,
        fieldId: Long?
    ): WorkRecordEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertWorkRecord(record: WorkRecordEntity): Long

    @Delete
    suspend fun deleteWorkRecord(record: WorkRecordEntity)

    // Payments
    @Query("SELECT * FROM payments ORDER BY paymentDate DESC, id DESC")
    fun observePayments(): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE farmerId = :farmerId ORDER BY paymentDate DESC, id DESC")
    fun observePaymentsForFarmer(farmerId: Long): Flow<List<PaymentEntity>>

    @Query("SELECT * FROM payments WHERE receiptNumber = :receipt LIMIT 1")
    suspend fun paymentByReceipt(receipt: String): PaymentEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentEntity): Long

    @Delete
    suspend fun deletePayment(payment: PaymentEntity)

    // Settings
    @Query("SELECT * FROM settings WHERE id = 1")
    suspend fun getSettings(): SettingsEntity?

    @Query("SELECT * FROM settings WHERE id = 1")
    fun observeSettings(): Flow<SettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: SettingsEntity)
}

@Database(
    entities = [
        FarmerEntity::class,
        FieldEntity::class,
        WorkRecordEntity::class,
        PaymentEntity::class,
        SettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TractorDatabase : RoomDatabase() {
    abstract fun tractorDao(): TractorDao

    companion object {
        @Volatile
        private var INSTANCE: TractorDatabase? = null

        fun get(context: Context): TractorDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    TractorDatabase::class.java,
                    "tractor_manager_marathi.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
