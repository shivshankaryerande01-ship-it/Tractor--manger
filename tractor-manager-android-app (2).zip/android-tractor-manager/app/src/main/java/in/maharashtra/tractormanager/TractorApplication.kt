package `in`.maharashtra.tractormanager

import android.app.Application
import `in`.maharashtra.tractormanager.data.TractorDatabase
import `in`.maharashtra.tractormanager.data.TractorRepository

class TractorApplication : Application() {
    val database: TractorDatabase by lazy { TractorDatabase.get(this) }
    val repository: TractorRepository by lazy { TractorRepository(database.tractorDao(), this) }
}
