package `in`.maharashtra.tractormanager.data

import android.app.Application
import android.net.Uri
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import `in`.maharashtra.tractormanager.BuildConfig
import `in`.maharashtra.tractormanager.domain.GpsCoordinate
import `in`.maharashtra.tractormanager.domain.LandAreaAndBillingCalculator
import `in`.maharashtra.tractormanager.domain.Mr
import `in`.maharashtra.tractormanager.domain.WorkRate
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Outcome of a cloud backup attempt. A local backup file is written in every case. */
enum class CloudSyncResult { SYNCED, NOT_CONFIGURED, FAILED }

class TractorRepository(
    private val dao: TractorDao,
    private val app: Application
) {
    // Cross-screen selection (farmers -> map, map -> work form)
    var pendingFieldId: Long? = null
    var pendingFarmerId: Long? = null

    // ---------------- Reactive streams ----------------
    val farmers: Flow<List<FarmerEntity>> = dao.observeFarmers()
    val fields: Flow<List<FieldEntity>> = dao.observeFields()
    val workRecords: Flow<List<WorkRecordEntity>> = dao.observeWorkRecords()
    val payments: Flow<List<PaymentEntity>> = dao.observePayments()
    val settings: Flow<SettingsEntity?> = dao.observeSettings()

    // ---------------- Settings ----------------
    suspend fun getSettings(): SettingsEntity {
        // Business details start empty: they are printed on bills, so they must be the
        // owner's real details entered in Settings, never invented defaults.
        return dao.getSettings() ?: SettingsEntity(
            ownerName = Mr.APP_NAME,
            ownerMobile = "",
            tractorModel = "",
            ratesJson = ratesToJson(LandAreaAndBillingCalculator.DEFAULT_WORK_RATES)
        ).also { dao.saveSettings(it) }
    }

    suspend fun saveSettings(s: SettingsEntity) = dao.saveSettings(s)

    fun ratesToJson(rates: List<WorkRate>): String {
        val arr = JSONArray()
        rates.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("marathiName", it.marathiName)
                    .put("englishName", it.englishName)
                    .put("ratePerAcre", it.ratePerAcre)
            )
        }
        return arr.toString()
    }

    fun ratesFromJson(json: String): List<WorkRate> {
        return try {
            val arr = JSONArray(json)
            val parsed = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                WorkRate(
                    o.getString("id"),
                    o.getString("marathiName"),
                    o.getString("englishName"),
                    o.getDouble("ratePerAcre")
                )
            }
            parsed.ifEmpty { LandAreaAndBillingCalculator.DEFAULT_WORK_RATES }
        } catch (e: Exception) {
            LandAreaAndBillingCalculator.DEFAULT_WORK_RATES
        }
    }

    // ---------------- Farmers ----------------
    suspend fun addFarmer(name: String, mobile: String, village: String, notes: String): Result<Long> {
        val cleanName = name.trim()
        val cleanMobile = mobile.filter { it.isDigit() }
        if (cleanName.length < 2) return Result.failure(IllegalArgumentException(Mr.ERR_NAME))
        if (!LandAreaAndBillingCalculator.isValidIndianMobile(cleanMobile)) {
            return Result.failure(IllegalArgumentException(Mr.ERR_MOBILE))
        }
        if (dao.farmerByMobile(cleanMobile) != null) {
            return Result.failure(IllegalArgumentException(Mr.ERR_DUP_MOBILE))
        }
        return try {
            Result.success(
                dao.insertFarmer(
                    FarmerEntity(
                        name = cleanName,
                        mobile = cleanMobile,
                        village = village.trim(),
                        notes = notes.trim()
                    )
                )
            )
        } catch (e: Exception) {
            Result.failure(IllegalStateException(Mr.ERR_SAVE))
        }
    }

    suspend fun updateFarmer(farmer: FarmerEntity): Result<Unit> {
        if (farmer.name.trim().length < 2) return Result.failure(IllegalArgumentException(Mr.ERR_NAME))
        if (!LandAreaAndBillingCalculator.isValidIndianMobile(farmer.mobile)) {
            return Result.failure(IllegalArgumentException(Mr.ERR_MOBILE))
        }
        val other = dao.farmerByMobile(farmer.mobile)
        if (other != null && other.id != farmer.id) {
            return Result.failure(IllegalArgumentException(Mr.ERR_DUP_MOBILE))
        }
        return try {
            dao.updateFarmer(farmer)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(Mr.ERR_SAVE))
        }
    }

    suspend fun deleteFarmer(farmer: FarmerEntity) = dao.deleteFarmer(farmer)

    // ---------------- Fields ----------------
    suspend fun saveField(
        id: Long,
        farmerId: Long,
        fieldName: String,
        village: String,
        gatNumber: String,
        points: List<GpsCoordinate>
    ): Result<Long> {
        if (fieldName.isBlank()) return Result.failure(IllegalArgumentException(Mr.ERR_FIELD_NAME))
        if (points.size < 3) return Result.failure(IllegalArgumentException(Mr.ERR_MIN_POINTS))
        val area = LandAreaAndBillingCalculator.computePolygonArea(points)
        if (area.sqMeters <= 0) return Result.failure(IllegalArgumentException(Mr.ERR_ZERO_AREA))
        val polygonJson = JSONArray().apply {
            points.forEach { put(JSONObject().put("lat", it.lat).put("lng", it.lng)) }
        }.toString()
        val entity = FieldEntity(
            id = id,
            farmerId = farmerId,
            fieldName = fieldName.trim(),
            village = village.trim(),
            gatNumber = gatNumber.trim(),
            polygonJson = polygonJson,
            areaSqMeters = area.sqMeters,
            areaAcres = area.acres,
            areaGunthas = area.gunthas,
            areaHectares = area.hectares
        )
        return try {
            Result.success(dao.saveField(entity))
        } catch (e: Exception) {
            Result.failure(IllegalStateException(Mr.ERR_SAVE))
        }
    }

    suspend fun deleteField(field: FieldEntity) = dao.deleteField(field)

    fun parsePolygon(json: String): List<GpsCoordinate> {
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                GpsCoordinate(o.getDouble("lat"), o.getDouble("lng"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ---------------- Work records ----------------
    suspend fun addWorkRecord(
        farmerId: Long,
        fieldId: Long?,
        workType: String,
        workDate: String,
        acres: Double,
        ratePerAcre: Double,
        notes: String,
        advanceAmount: Double,
        advanceMode: String
    ): Result<Long> {
        if (acres <= 0 || ratePerAcre <= 0) {
            return Result.failure(IllegalArgumentException(Mr.ERR_WORK_INPUT))
        }
        if (dao.findDuplicateWork(farmerId, workDate, workType, fieldId) != null) {
            return Result.failure(IllegalArgumentException(Mr.ERR_DUP_WORK))
        }
        val total = LandAreaAndBillingCalculator.calculateWorkTotal(acres, ratePerAcre)
        val gunthas = acres * LandAreaAndBillingCalculator.GUNTHAS_PER_ACRE
        return try {
            val id = dao.insertWorkRecord(
                WorkRecordEntity(
                    farmerId = farmerId,
                    fieldId = fieldId,
                    workType = workType,
                    workDate = workDate,
                    acres = acres,
                    gunthas = gunthas,
                    ratePerAcre = ratePerAcre,
                    totalAmount = total,
                    notes = notes.trim()
                )
            )
            if (advanceAmount > 0) {
                addPayment(
                    farmerId = farmerId,
                    workRecordId = id,
                    amount = advanceAmount,
                    type = if (advanceAmount >= total) "FINAL" else "ADVANCE",
                    mode = advanceMode,
                    date = workDate,
                    notes = Mr.ADVANCE + " - " + workType
                )
            }
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(Mr.ERR_SAVE))
        }
    }

    suspend fun deleteWorkRecord(record: WorkRecordEntity) = dao.deleteWorkRecord(record)

    // ---------------- Payments ----------------
    suspend fun addPayment(
        farmerId: Long,
        workRecordId: Long?,
        amount: Double,
        type: String,
        mode: String,
        date: String,
        notes: String
    ): Result<Long> {
        if (amount <= 0) return Result.failure(IllegalArgumentException(Mr.ERR_AMOUNT))
        // Timestamp based receipt number: unique per device without relying on random digits.
        val receipt = "TM-" + SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date())
        return try {
            Result.success(
                dao.insertPayment(
                    PaymentEntity(
                        farmerId = farmerId,
                        workRecordId = workRecordId,
                        amount = amount,
                        paymentType = type,
                        paymentMode = mode,
                        paymentDate = date,
                        receiptNumber = receipt,
                        notes = notes.trim()
                    )
                )
            )
        } catch (e: Exception) {
            Result.failure(IllegalStateException(Mr.ERR_SAVE))
        }
    }

    suspend fun deletePayment(payment: PaymentEntity) = dao.deletePayment(payment)

    // ---------------- Backup / Restore / Cloud ----------------
    suspend fun exportBackupJson(): String {
        val root = JSONObject()
        root.put("app", "Tractor Manager")
        root.put("exportedAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date()))
        root.put("farmers", JSONArray(farmers.first().map { f ->
            JSONObject().put("id", f.id).put("name", f.name).put("mobile", f.mobile)
                .put("village", f.village).put("notes", f.notes)
        }))
        root.put("fields", JSONArray(fields.first().map { f ->
            JSONObject().put("id", f.id).put("farmerId", f.farmerId).put("fieldName", f.fieldName)
                .put("village", f.village).put("gatNumber", f.gatNumber)
                .put("polygon", f.polygonJson).put("areaAcres", f.areaAcres)
                .put("areaGunthas", f.areaGunthas).put("areaHectares", f.areaHectares)
                .put("areaSqMeters", f.areaSqMeters)
        }))
        root.put("workRecords", JSONArray(workRecords.first().map { w ->
            JSONObject().put("id", w.id).put("farmerId", w.farmerId).put("fieldId", w.fieldId)
                .put("workType", w.workType).put("workDate", w.workDate)
                .put("acres", w.acres).put("gunthas", w.gunthas)
                .put("ratePerAcre", w.ratePerAcre).put("totalAmount", w.totalAmount)
                .put("notes", w.notes)
        }))
        root.put("payments", JSONArray(payments.first().map { p ->
            JSONObject().put("farmerId", p.farmerId).put("workRecordId", p.workRecordId)
                .put("amount", p.amount).put("paymentType", p.paymentType)
                .put("paymentMode", p.paymentMode).put("paymentDate", p.paymentDate)
                .put("receiptNumber", p.receiptNumber).put("notes", p.notes)
        }))
        return root.toString(2)
    }

    /**
     * Restores farmers, measured fields, work records and payments from a backup file.
     * Every record is checked against what is already stored (farmer by mobile number, field
     * by owner + name, work by owner + date + type + field, payment by receipt number), so
     * restoring the same file twice never creates duplicates.
     * Returns the number of records added.
     */
    suspend fun importBackupJson(json: String): Result<Int> {
        return try {
            val root = JSONObject(json)
            val farmerArr = root.optJSONArray("farmers")
                ?: return Result.failure(IllegalArgumentException(Mr.ERR_BACKUP))
            var added = 0

            val farmerIds = HashMap<Long, Long>() // id in backup -> id in this database
            for (i in 0 until farmerArr.length()) {
                val o = farmerArr.getJSONObject(i)
                val mobile = o.optString("mobile").filter { it.isDigit() }
                val name = o.optString("name").trim()
                if (name.isEmpty() || mobile.isEmpty()) continue
                val existing = dao.farmerByMobile(mobile)
                val localId = if (existing != null) {
                    existing.id
                } else {
                    added++
                    dao.insertFarmer(
                        FarmerEntity(
                            name = name,
                            mobile = mobile,
                            village = o.optString("village"),
                            notes = o.optString("notes")
                        )
                    )
                }
                val backupId = o.optLong("id", -1L)
                if (backupId >= 0) farmerIds[backupId] = localId
            }

            val fieldIds = HashMap<Long, Long>()
            val fieldArr = root.optJSONArray("fields") ?: JSONArray()
            for (i in 0 until fieldArr.length()) {
                val o = fieldArr.getJSONObject(i)
                val farmerId = farmerIds[o.optLong("farmerId", -1L)] ?: continue
                val name = o.optString("fieldName").trim()
                if (name.isEmpty()) continue
                val existing = dao.fieldByName(farmerId, name)
                val localId = if (existing != null) {
                    existing.id
                } else {
                    added++
                    dao.saveField(
                        FieldEntity(
                            farmerId = farmerId,
                            fieldName = name,
                            village = o.optString("village"),
                            gatNumber = o.optString("gatNumber"),
                            polygonJson = o.optString("polygon", "[]"),
                            areaSqMeters = o.optDouble("areaSqMeters", 0.0),
                            areaAcres = o.optDouble("areaAcres", 0.0),
                            areaGunthas = o.optDouble("areaGunthas", 0.0),
                            areaHectares = o.optDouble("areaHectares", 0.0)
                        )
                    )
                }
                val backupId = o.optLong("id", -1L)
                if (backupId >= 0) fieldIds[backupId] = localId
            }

            val workIds = HashMap<Long, Long>()
            val workArr = root.optJSONArray("workRecords") ?: JSONArray()
            for (i in 0 until workArr.length()) {
                val o = workArr.getJSONObject(i)
                val farmerId = farmerIds[o.optLong("farmerId", -1L)] ?: continue
                val fieldId = if (o.isNull("fieldId")) null else fieldIds[o.optLong("fieldId", -1L)]
                val workType = o.optString("workType")
                val workDate = o.optString("workDate")
                if (workType.isEmpty() || workDate.isEmpty()) continue
                val existing = dao.findDuplicateWork(farmerId, workDate, workType, fieldId)
                val localId = if (existing != null) {
                    existing.id
                } else {
                    added++
                    dao.insertWorkRecord(
                        WorkRecordEntity(
                            farmerId = farmerId,
                            fieldId = fieldId,
                            workType = workType,
                            workDate = workDate,
                            acres = o.optDouble("acres", 0.0),
                            gunthas = o.optDouble("gunthas", 0.0),
                            ratePerAcre = o.optDouble("ratePerAcre", 0.0),
                            totalAmount = o.optDouble("totalAmount", 0.0),
                            notes = o.optString("notes")
                        )
                    )
                }
                val backupId = o.optLong("id", -1L)
                if (backupId >= 0) workIds[backupId] = localId
            }

            val paymentArr = root.optJSONArray("payments") ?: JSONArray()
            for (i in 0 until paymentArr.length()) {
                val o = paymentArr.getJSONObject(i)
                val farmerId = farmerIds[o.optLong("farmerId", -1L)] ?: continue
                val receipt = o.optString("receiptNumber")
                if (receipt.isEmpty() || dao.paymentByReceipt(receipt) != null) continue
                val workId = if (o.isNull("workRecordId")) null else workIds[o.optLong("workRecordId", -1L)]
                added++
                dao.insertPayment(
                    PaymentEntity(
                        farmerId = farmerId,
                        workRecordId = workId,
                        amount = o.optDouble("amount", 0.0),
                        paymentType = o.optString("paymentType", "PARTIAL"),
                        paymentMode = o.optString("paymentMode", "CASH"),
                        paymentDate = o.optString("paymentDate"),
                        receiptNumber = receipt,
                        notes = o.optString("notes")
                    )
                )
            }
            Result.success(added)
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException(Mr.ERR_BACKUP))
        }
    }

    suspend fun readBackupFromUri(uri: Uri): Result<Int> {
        return try {
            val text = app.contentResolver.openInputStream(uri)?.use { it.bufferedReader().readText() }
                ?: return Result.failure(IllegalArgumentException(Mr.ERR_BACKUP))
            importBackupJson(text)
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException(Mr.ERR_BACKUP))
        }
    }

    /** Writes a timestamped backup file on the phone and keeps only the newest ten. */
    suspend fun writeLocalBackup(): File? {
        return try {
            val dir = File(app.filesDir, "backups")
            dir.mkdirs()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(dir, "TractorManager_Backup_$stamp.json")
            file.writeText(exportBackupJson())
            dir.listFiles()
                ?.filter { it.name.endsWith(".json") }
                ?.sortedByDescending { it.name }
                ?.drop(10)
                ?.forEach { it.delete() }
            val now = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
            dao.saveSettings(getSettings().copy(lastBackupAt = now))
            file
        } catch (e: Exception) {
            null
        }
    }

    private fun cloudConfigured(): Boolean =
        BuildConfig.FIREBASE_APP_ID.isNotBlank() &&
            BuildConfig.FIREBASE_API_KEY.isNotBlank() &&
            BuildConfig.FIREBASE_PROJECT_ID.isNotBlank()

    /**
     * Writes a local backup, then uploads it to Firestore if the app was built with Firebase
     * credentials. Reports SYNCED only after the server has acknowledged the write.
     */
    suspend fun syncToFirestore(): CloudSyncResult {
        writeLocalBackup()
        if (!cloudConfigured()) return CloudSyncResult.NOT_CONFIGURED
        return try {
            if (FirebaseApp.getApps(app).isEmpty()) {
                FirebaseApp.initializeApp(
                    app,
                    FirebaseOptions.Builder()
                        .setApplicationId(BuildConfig.FIREBASE_APP_ID)
                        .setApiKey(BuildConfig.FIREBASE_API_KEY)
                        .setProjectId(BuildConfig.FIREBASE_PROJECT_ID)
                        .build()
                )
            }
            val json = exportBackupJson()
            withTimeout(20_000) {
                Firebase.firestore.collection("backups").document("latest")
                    .set(
                        mapOf(
                            "json" to json,
                            "device" to android.os.Build.MODEL,
                            "timestamp" to FieldValue.serverTimestamp()
                        )
                    )
                    .await()
            }
            CloudSyncResult.SYNCED
        } catch (e: TimeoutCancellationException) {
            CloudSyncResult.FAILED
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            CloudSyncResult.FAILED
        }
    }
}
