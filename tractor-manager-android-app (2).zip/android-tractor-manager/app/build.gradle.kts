import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

// Secrets are never committed. Each value is looked up, in order, from:
//   1. a Gradle property   (./gradlew assembleDebug -PMAPS_API_KEY=xxxx)
//   2. local.properties    (MAPS_API_KEY=xxxx)
//   3. an environment variable
// A blank value simply disables the matching feature.
val localProps = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) file.inputStream().use { load(it) }
}

fun secret(name: String): String =
    ((project.findProperty(name) as String?) ?: localProps.getProperty(name) ?: System.getenv(name) ?: "").trim()

val mapsApiKey = secret("MAPS_API_KEY")
val firebaseAppId = secret("FIREBASE_APP_ID")
val firebaseApiKey = secret("FIREBASE_API_KEY")
val firebaseProjectId = secret("FIREBASE_PROJECT_ID")

android {
    namespace = "in.maharashtra.tractormanager"
    compileSdk = 35

    defaultConfig {
        applicationId = "in.maharashtra.tractormanager"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Google Maps SDK key (blank = app uses the keyless Esri satellite map instead).
        manifestPlaceholders["MAPS_API_KEY"] = mapsApiKey
        buildConfigField("String", "MAPS_API_KEY", "\"$mapsApiKey\"")

        // Firebase cloud backup (blank = cloud backup disabled, local backup only).
        buildConfigField("String", "FIREBASE_APP_ID", "\"$firebaseAppId\"")
        buildConfigField("String", "FIREBASE_API_KEY", "\"$firebaseApiKey\"")
        buildConfigField("String", "FIREBASE_PROJECT_ID", "\"$firebaseProjectId\"")
    }

    signingConfigs {
        create("release") {
            // Demo release keystore generated with keytool (see README). Replace for production.
            storeFile = file("../tractor.keystore")
            storePassword = "tractor123"
            keyAlias = "tractor"
            keyPassword = "tractor123"
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            // Sign debug builds with the project keystore, not the per-machine debug key,
            // so every rebuild can be installed as an update over the previous one.
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")

    val composeBom = platform("androidx.compose:compose-bom:2025.01.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // Room offline persistent database
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // Google Maps (hybrid satellite, Google Earth style) - used when MAPS_API_KEY is set
    implementation("com.google.maps.android:maps-compose:6.2.1")
    implementation("com.google.android.gms:play-services-maps:19.0.0")

    // Keyless fallback satellite map (Esri World Imagery via osmdroid) + GPS
    implementation("org.osmdroid:osmdroid-android:6.1.20")
    implementation("com.google.android.gms:play-services-location:21.3.0")

    // Firebase Firestore cloud backup (only active when FIREBASE_* values are set) + WorkManager
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")
    implementation("androidx.work:work-runtime-ktx:2.10.0")

    testImplementation("junit:junit:4.13.2")
}
