# Tractor Manager - native Android app (ट्रॅक्टर मॅनेजर)

Kotlin + Jetpack Compose + Room. Marathi UI, amounts in rupees.

## Build

Requirements: JDK 17 and the Android SDK (platform 35, build-tools 35.0.0).

```bash
cd android-tractor-manager
echo "sdk.dir=/path/to/android-sdk" > local.properties

./gradlew :app:assembleDebug          # app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:testDebugUnitTest      # JUnit tests: area, billing, payments
```

On a machine with less than about 6 GB of RAM, add
`-Pkotlin.compiler.execution.strategy=in-process --no-parallel` to the Gradle command.

## Google Maps (full-screen hybrid satellite map)

The map screen uses the Google Maps SDK when the app is **built with** an API key.
The key cannot be entered inside the app: the Maps SDK reads it from the manifest.

1. In Google Cloud Console create a project, enable billing and enable **Maps SDK for Android**.
2. Create an API key. Restrict it to Android apps with package
   `in.maharashtra.tractormanager.debug` (debug) or `in.maharashtra.tractormanager` (release)
   and your signing certificate SHA-1.
3. Give the key to the build in any one of these ways:
   - `./gradlew :app:assembleDebug -PMAPS_API_KEY=AIza...`
   - a line `MAPS_API_KEY=AIza...` in `local.properties` (never commit this file)
   - an environment variable `MAPS_API_KEY`

Without a key the app still works: it falls back to keyless Esri World Imagery satellite
tiles and shows a notice on the map screen and in Settings.

Map features: full-screen toggle (hides the bottom bar), 2D/3D tilt toggle (Google only),
place search (Android geocoder), "my location", add a boundary point at the real GPS
position, tap to add points, undo, clear, live area in acres / guntha / hectares.

## Cloud backup (optional)

Local backup files are always written to app storage (newest ten kept) once a day and
whenever "cloud backup" is pressed. Uploading to Firebase Firestore only happens when the
app is built with `FIREBASE_APP_ID`, `FIREBASE_API_KEY` and `FIREBASE_PROJECT_ID`
(same three ways as the Maps key). Without them the app says clearly that cloud backup is
not set up; it never reports a sync that did not happen.

## Strings

All Marathi UI text lives in `tools/strings_mr.txt`. After editing it run:

```bash
python3 tools/gen_strings.py
```

This regenerates `domain/Mr.kt` and fails if a string contains unexpected characters or if
the Kotlin code references a key that is not defined.

## Signing

`tractor.keystore` (alias `tractor`, passwords `tractor123`) is a demo release keystore.
Replace it before publishing a release build.
