/**
 * Web Mercator (EPSG:3857) helpers used by the keyless satellite map.
 *
 * Map tiles are 256 CSS pixels wide. At zoom z the whole world is 256 * 2^z "world pixels"
 * wide, so converting a GPS point to world pixels (and back) with these functions places it
 * exactly on top of the imagery, whatever the size of the map on screen.
 */

export const TILE_SIZE = 256;

export interface WorldPixel {
  x: number;
  y: number;
}

export interface LatLng {
  lat: number;
  lng: number;
}

const MAX_LATITUDE = 85.05112878;

export function worldSize(zoom: number): number {
  return TILE_SIZE * Math.pow(2, zoom);
}

export function latLngToWorldPixel(point: LatLng, zoom: number): WorldPixel {
  const size = worldSize(zoom);
  const lat = Math.max(-MAX_LATITUDE, Math.min(MAX_LATITUDE, point.lat));
  const latRad = (lat * Math.PI) / 180;
  const x = ((point.lng + 180) / 360) * size;
  const y =
    ((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) *
    size;
  return { x, y };
}

export function worldPixelToLatLng(pixel: WorldPixel, zoom: number): LatLng {
  const size = worldSize(zoom);
  const lng = (pixel.x / size) * 360 - 180;
  const n = Math.PI - (2 * Math.PI * pixel.y) / size;
  const lat = (180 / Math.PI) * Math.atan(Math.sinh(n));
  return { lat, lng };
}

/** Converts a GPS point to a pixel position inside a map viewport centred on `center`. */
export function latLngToScreen(
  point: LatLng,
  center: LatLng,
  zoom: number,
  width: number,
  height: number
): WorldPixel {
  const p = latLngToWorldPixel(point, zoom);
  const c = latLngToWorldPixel(center, zoom);
  return { x: p.x - c.x + width / 2, y: p.y - c.y + height / 2 };
}

/** Converts a pixel position inside the map viewport back to a GPS point. */
export function screenToLatLng(
  x: number,
  y: number,
  center: LatLng,
  zoom: number,
  width: number,
  height: number
): LatLng {
  const c = latLngToWorldPixel(center, zoom);
  return worldPixelToLatLng(
    { x: c.x + x - width / 2, y: c.y + y - height / 2 },
    zoom
  );
}

export interface VisibleTile {
  key: string;
  x: number;
  y: number;
  left: number;
  top: number;
}

/** Lists the tiles needed to cover a viewport, with their pixel offsets inside it. */
export function visibleTiles(
  center: LatLng,
  zoom: number,
  width: number,
  height: number
): VisibleTile[] {
  const c = latLngToWorldPixel(center, zoom);
  const originX = c.x - width / 2;
  const originY = c.y - height / 2;
  const tileCount = Math.pow(2, zoom);
  const firstX = Math.floor(originX / TILE_SIZE);
  const lastX = Math.floor((originX + width) / TILE_SIZE);
  const firstY = Math.max(0, Math.floor(originY / TILE_SIZE));
  const lastY = Math.min(
    tileCount - 1,
    Math.floor((originY + height) / TILE_SIZE)
  );
  const tiles: VisibleTile[] = [];
  for (let tx = firstX; tx <= lastX; tx++) {
    for (let ty = firstY; ty <= lastY; ty++) {
      const wrappedX = ((tx % tileCount) + tileCount) % tileCount;
      tiles.push({
        key: `${zoom}/${wrappedX}/${ty}/${tx}`,
        x: wrappedX,
        y: ty,
        left: tx * TILE_SIZE - originX,
        top: ty * TILE_SIZE - originY,
      });
    }
  }
  return tiles;
}
