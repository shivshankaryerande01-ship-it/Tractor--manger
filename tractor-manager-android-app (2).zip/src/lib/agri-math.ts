import type { GpsPoint, WorkTypeRate } from "@/db/schema";

const EARTH_RADIUS_METERS = 6378137.0; // WGS84

export const SQ_METERS_PER_ACRE = 4046.8564224;
export const SQ_METERS_PER_GUNTHA = 101.17141056; // 1 Acre = 40 Gunthas
export const SQ_METERS_PER_HECTARE = 10000.0;
export const GUNTHAS_PER_ACRE = 40.0;

export interface AreaMeasurementResult {
  areaSqMeters: number;
  areaAcres: number;
  areaGunthas: number;
  areaHectares: number;
  wholeAcres: number;
  remainingGunthas: number;
  perimeterMeters: number;
  segmentDistancesMeters: number[];
}

export interface PaymentSummary {
  totalBilled: number;
  totalReceived: number;
  balanceAmount: number;
  advanceCredit: number;
  status: "PAID" | "PARTIAL" | "UNPAID";
  marathiStatus: string;
}

export interface UnitTestResult {
  id: string;
  nameMarathi: string;
  nameEnglish: string;
  category: "AREA" | "BILLING" | "PAYMENT" | "VALIDATION";
  expected: string;
  actual: string;
  passed: boolean;
}

export const DEFAULT_WORK_RATES: WorkTypeRate[] = [
  {
    id: "ploughing",
    marathiName: "नांगरणी (पलटी नांगर)",
    englishName: "Ploughing (MB Plough)",
    ratePerAcre: 1600,
    unitLabel: "प्रति एकर",
  },
  {
    id: "rotavator",
    marathiName: "रोटाव्हेटर (६ फूट)",
    englishName: "Rotavator Tilling",
    ratePerAcre: 1200,
    unitLabel: "प्रति एकर",
  },
  {
    id: "sowing",
    marathiName: "पेरणी (सीड ड्रिल)",
    englishName: "Seed Drill Sowing",
    ratePerAcre: 1000,
    unitLabel: "प्रति एकर",
  },
  {
    id: "cultivator",
    marathiName: "कल्हिव्हेटर (९ फणी फणपाळी)",
    englishName: "Cultivator (9-Tyne)",
    ratePerAcre: 900,
    unitLabel: "प्रति एकर",
  },
  {
    id: "ridger",
    marathiName: "सरी पाडणे (रिजर)",
    englishName: "Ridger / Furrow",
    ratePerAcre: 1100,
    unitLabel: "प्रति एकर",
  },
  {
    id: "threshing",
    marathiName: "थ्रेशर मळणी",
    englishName: "Crop Threshing",
    ratePerAcre: 1500,
    unitLabel: "प्रति एकर",
  },
  {
    id: "laser_level",
    marathiName: "लेझर जमीन सपाटीकरण",
    englishName: "Laser Land Leveling",
    ratePerAcre: 1800,
    unitLabel: "प्रति एकर",
  },
];

export const MAHARASHTRA_VILLAGE_PRESETS: Array<{
  nameMarathi: string;
  nameEnglish: string;
  talukaDistrict: string;
  lat: number;
  lng: number;
}> = [
  {
    nameMarathi: "बारामती (माळेगाव बुद्रुक)",
    nameEnglish: "Baramati Malegaon",
    talukaDistrict: "ता. बारामती, जि. पुणे",
    lat: 18.1516,
    lng: 74.5775,
  },
  {
    nameMarathi: "निफाड (द्राक्ष व ऊस पट्टा)",
    nameEnglish: "Niphad Nashik",
    talukaDistrict: "ता. निफाड, जि. नाशिक",
    lat: 20.0784,
    lng: 74.1072,
  },
  {
    nameMarathi: "राहुरी (प्रवरा खोरे)",
    nameEnglish: "Rahuri Ahilyanagar",
    talukaDistrict: "ता. राहुरी, जि. अहिल्यानगर",
    lat: 19.3927,
    lng: 74.6488,
  },
  {
    nameMarathi: "कराड (कृष्णा काठ शेत शिवार)",
    nameEnglish: "Karad Satara",
    talukaDistrict: "ता. कराड, जि. सातारा",
    lat: 17.2886,
    lng: 74.1844,
  },
  {
    nameMarathi: "शिरोळ (पंचगंगा शेत शिवार)",
    nameEnglish: "Shirol Kolhapur",
    talukaDistrict: "ता. शिरोळ, जि. कोल्हापूर",
    lat: 16.7332,
    lng: 74.6022,
  },
  {
    nameMarathi: "माढा (कुर्डूवाडी शिवार)",
    nameEnglish: "Madha Solapur",
    talukaDistrict: "ता. माढा, जि. सोलापूर",
    lat: 18.0339,
    lng: 75.3114,
  },
  {
    nameMarathi: "पैठण (गोदावरी पट्टा)",
    nameEnglish: "Paithan Chhatrapati Sambhajinagar",
    talukaDistrict: "ता. पैठण, जि. छत्रपती संभाजीनगर",
    lat: 19.4769,
    lng: 75.3856,
  },
];

function toRadians(deg: number): number {
  return (deg * Math.PI) / 180.0;
}

/**
 * Calculates distance in meters between two GPS points using Haversine formula.
 */
export function computeHaversineDistanceMeters(
  p1: GpsPoint,
  p2: GpsPoint
): number {
  const dLat = toRadians(p2.lat - p1.lat);
  const dLng = toRadians(p2.lng - p1.lng);
  const lat1 = toRadians(p1.lat);
  const lat2 = toRadians(p2.lat);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_METERS * c;
}

/**
 * Computes exact geodesic polygon area on WGS84 sphere (equivalent to Google Maps SphericalUtil.computeArea)
 * and converts to Acres, Gunthas (1 Acre = 40 Gunthas), and Hectares.
 */
export function calculatePolygonLandArea(
  points: GpsPoint[]
): AreaMeasurementResult {
  if (!points || points.length < 3) {
    const segmentDistancesMeters: number[] = [];
    if (points && points.length === 2) {
      segmentDistancesMeters.push(
        Number(computeHaversineDistanceMeters(points[0], points[1]).toFixed(1))
      );
    }
    return {
      areaSqMeters: 0,
      areaAcres: 0,
      areaGunthas: 0,
      areaHectares: 0,
      wholeAcres: 0,
      remainingGunthas: 0,
      perimeterMeters: segmentDistancesMeters[0] ?? 0,
      segmentDistancesMeters,
    };
  }

  let totalAngle = 0;
  const n = points.length;
  const segmentDistancesMeters: number[] = [];
  let perimeterMeters = 0;

  for (let i = 0; i < n; i++) {
    const p1 = points[i];
    const p2 = points[(i + 1) % n];
    const dist = computeHaversineDistanceMeters(p1, p2);
    segmentDistancesMeters.push(Number(dist.toFixed(1)));
    perimeterMeters += dist;

    const lat1 = toRadians(p1.lat);
    const lng1 = toRadians(p1.lng);
    const lat2 = toRadians(p2.lat);
    const lng2 = toRadians(p2.lng);

    totalAngle += (lng2 - lng1) * (2 + Math.sin(lat1) + Math.sin(lat2));
  }

  const areaSqMeters = Math.abs(
    (totalAngle * EARTH_RADIUS_METERS * EARTH_RADIUS_METERS) / 2.0
  );

  return convertSqMetersToLandUnits(
    areaSqMeters,
    perimeterMeters,
    segmentDistancesMeters
  );
}

export function convertSqMetersToLandUnits(
  sqMeters: number,
  perimeterMeters = 0,
  segmentDistancesMeters: number[] = []
): AreaMeasurementResult {
  const safeSqMeters = Math.max(0, sqMeters);
  const areaAcres = safeSqMeters / SQ_METERS_PER_ACRE;
  const areaGunthas = safeSqMeters / SQ_METERS_PER_GUNTHA;
  const areaHectares = safeSqMeters / SQ_METERS_PER_HECTARE;

  const wholeAcres = Math.floor(areaAcres + 1e-6);
  const remainingGunthas = Math.max(0, (areaAcres - wholeAcres) * GUNTHAS_PER_ACRE);

  return {
    areaSqMeters: Number(safeSqMeters.toFixed(2)),
    areaAcres: Number(areaAcres.toFixed(2)),
    areaGunthas: Number(areaGunthas.toFixed(2)),
    areaHectares: Number(areaHectares.toFixed(3)),
    wholeAcres,
    remainingGunthas: Number(remainingGunthas.toFixed(1)),
    perimeterMeters: Number(perimeterMeters.toFixed(1)),
    segmentDistancesMeters,
  };
}

/**
 * Converts traditional Maharashtra Acre + Guntha input into decimal Acres.
 * Example: 2 Acres 20 Gunthas -> 2.50 Acres
 */
export function acresAndGunthasToDecimalAcres(
  wholeAcres: number,
  gunthas: number
): number {
  const cleanAcres = Math.max(0, Number(wholeAcres) || 0);
  const cleanGunthas = Math.max(0, Number(gunthas) || 0);
  return Number((cleanAcres + cleanGunthas / GUNTHAS_PER_ACRE).toFixed(3));
}

/**
 * Calculates total tractor bill: Total = Acres × Rate per Acre
 */
export function calculateWorkTotal(acres: number, ratePerAcre: number): number {
  const safeAcres = Math.max(0, Number(acres) || 0);
  const safeRate = Math.max(0, Number(ratePerAcre) || 0);
  return Math.round(safeAcres * safeRate);
}

/**
 * Computes farmer ledger & payment status in Marathi and English
 */
export function computePaymentSummary(
  totalBilled: number,
  totalReceived: number
): PaymentSummary {
  const billed = Math.max(0, Math.round(totalBilled));
  const received = Math.max(0, Math.round(totalReceived));

  if (billed === 0 && received === 0) {
    return {
      totalBilled: 0,
      totalReceived: 0,
      balanceAmount: 0,
      advanceCredit: 0,
      status: "PAID",
      marathiStatus: "निरंक (कोणतीही बाकी नाही)",
    };
  }

  if (received >= billed && billed > 0) {
    return {
      totalBilled: billed,
      totalReceived: received,
      balanceAmount: 0,
      advanceCredit: Math.max(0, received - billed),
      status: "PAID",
      marathiStatus: "पूर्ण जमा",
    };
  }

  if (received > 0 && received < billed) {
    return {
      totalBilled: billed,
      totalReceived: received,
      balanceAmount: billed - received,
      advanceCredit: 0,
      status: "PARTIAL",
      marathiStatus: "अंशतः बाकी",
    };
  }

  return {
    totalBilled: billed,
    totalReceived: received,
    balanceAmount: billed,
    advanceCredit: received > billed ? received - billed : 0,
    status: "UNPAID",
    marathiStatus: "पूर्ण बाकी",
  };
}

/**
 * Formats numbers in Indian Rupee (₹) format (e.g., ₹1,24,500)
 */
export function formatINR(amount: number): string {
  const rounded = Math.round(Number(amount) || 0);
  return "₹" + rounded.toLocaleString("en-IN");
}

/**
 * Converts breakdown of decimal acres into readable Marathi string: e.g. "2 एकर 18 गुंठे (2.45 एकर)"
 */
export function formatMarathiAreaBreakdown(acres: number): string {
  const safeAcres = Math.max(0, Number(acres) || 0);
  const whole = Math.floor(safeAcres + 1e-6);
  const gunthas = Math.round((safeAcres - whole) * 40);
  if (gunthas === 40) {
    return `${whole + 1} एकर ० गुंठे`;
  }
  return `${whole} एकर ${gunthas} गुंठे`;
}

/**
 * Validates Indian 10-digit mobile number
 */
export function isValidIndianMobile(mobile: string): boolean {
  const cleaned = mobile.replace(/\D/g, "");
  return /^[6-9]\d{9}$/.test(cleaned);
}

/**
 * Executes comprehensive automated unit tests for Area Calculation, Billing, and Payments
 */
export function runAgriMathTestSuite(): UnitTestResult[] {
  const results: UnitTestResult[] = [];

  // Test 1: 1 Acre Exact Conversion
  const oneAcreUnits = convertSqMetersToLandUnits(4046.8564224);
  results.push({
    id: "TEST-01",
    nameMarathi: "१ एकर क्षेत्रफळ रूपांतरण (एकर, गुंठे, हेक्टर)",
    nameEnglish: "1 Acre Unit Conversion (Sq.m -> Acre, Guntha, Hectare)",
    category: "AREA",
    expected: "1.00 एकर | 40.00 गुंठे | 0.405 हेक्टर",
    actual: `${oneAcreUnits.areaAcres.toFixed(2)} एकर | ${oneAcreUnits.areaGunthas.toFixed(2)} गुंठे | ${oneAcreUnits.areaHectares.toFixed(3)} हेक्टर`,
    passed:
      Math.abs(oneAcreUnits.areaAcres - 1.0) < 0.01 &&
      Math.abs(oneAcreUnits.areaGunthas - 40.0) < 0.05 &&
      Math.abs(oneAcreUnits.areaHectares - 0.405) < 0.005,
  });

  // Test 2: Spherical Polygon GPS Area Calculation (Baramati plot ~2.15 Acres)
  const samplePolygon: GpsPoint[] = [
    { lat: 18.1512, lng: 74.5770 },
    { lat: 18.1521, lng: 74.5770 },
    { lat: 18.1521, lng: 74.57785 },
    { lat: 18.1512, lng: 74.57785 },
  ];
  const polyRes = calculatePolygonLandArea(samplePolygon);
  results.push({
    id: "TEST-02",
    nameMarathi: "सॅटेलाईट GPS बहुभुज (Polygon) क्षेत्रफळ गणना",
    nameEnglish: "Spherical Geodesic Polygon Area Calculation",
    category: "AREA",
    expected: "~2.22 एकर (8970+ चौ.मी.)",
    actual: `${polyRes.areaAcres} एकर (${polyRes.areaSqMeters} चौ.मी.)`,
    passed: polyRes.areaSqMeters > 8800 && polyRes.areaSqMeters < 9200 && polyRes.areaAcres > 2.15,
  });

  // Test 3: Acre + Guntha to Decimal Acres
  const decAcres = acresAndGunthasToDecimalAcres(2, 20);
  results.push({
    id: "TEST-03",
    nameMarathi: "२ एकर २० गुंठे = २.५० दशांश एकर रूपांतरण",
    nameEnglish: "2 Acres 20 Gunthas to 2.50 Decimal Acres",
    category: "AREA",
    expected: "2.5 एकर",
    actual: `${decAcres} एकर`,
    passed: Math.abs(decAcres - 2.5) < 0.001,
  });

  // Test 4: Ploughing Billing Calculation
  const billPlough = calculateWorkTotal(2.5, 1600);
  results.push({
    id: "TEST-04",
    nameMarathi: "नांगरणी बिल गणना (२.५ एकर × ₹१,६००)",
    nameEnglish: "Ploughing Bill Calculation (2.5 Acres × ₹1,600)",
    category: "BILLING",
    expected: "₹4,000",
    actual: formatINR(billPlough),
    passed: billPlough === 4000,
  });

  // Test 5: Rotavator Partial Guntha Billing (1 Acre 10 Gunthas = 1.25 Acres × ₹1,200)
  const billRota = calculateWorkTotal(acresAndGunthasToDecimalAcres(1, 10), 1200);
  results.push({
    id: "TEST-05",
    nameMarathi: "रोटाव्हेटर बिल (१ एकर १० गुंठे × ₹१,२००)",
    nameEnglish: "Rotavator Bill (1 Acre 10 Gunthas × ₹1,200)",
    category: "BILLING",
    expected: "₹1,500",
    actual: formatINR(billRota),
    passed: billRota === 1500,
  });

  // Test 6: Advance & Partial Payment Balance Status
  const summaryPartial = computePaymentSummary(4000, 1500);
  results.push({
    id: "TEST-06",
    nameMarathi: "अॅडव्हान्स व अंशतः पेमेंट बाकी तपासणी",
    nameEnglish: "Advance & Partial Payment Status Verification",
    category: "PAYMENT",
    expected: "अंशतः बाकी | बाकी ₹2,500",
    actual: `${summaryPartial.marathiStatus} | बाकी ${formatINR(summaryPartial.balanceAmount)}`,
    passed:
      summaryPartial.status === "PARTIAL" &&
      summaryPartial.balanceAmount === 2500,
  });

  // Test 7: Full Payment Status Transition
  const summaryPaid = computePaymentSummary(4000, 4000);
  results.push({
    id: "TEST-07",
    nameMarathi: "पूर्ण बिल चुकते (Paid Status) तपासणी",
    nameEnglish: "Full Payment Settlement Status Verification",
    category: "PAYMENT",
    expected: "पूर्ण जमा | बाकी ₹0",
    actual: `${summaryPaid.marathiStatus} | बाकी ${formatINR(summaryPaid.balanceAmount)}`,
    passed:
      summaryPaid.status === "PAID" && summaryPaid.balanceAmount === 0,
  });

  // Test 8: Indian Mobile Validation
  const validMob = isValidIndianMobile("9823451201");
  const invalidMob = isValidIndianMobile("12345");
  results.push({
    id: "TEST-08",
    nameMarathi: "शेतकरी १०-अंकी मोबाईल नंबर पडताळणी",
    nameEnglish: "Farmer 10-Digit Indian Mobile Validation",
    category: "VALIDATION",
    expected: "वैध: true | अवैध: false",
    actual: `वैध: ${validMob} | अवैध: ${invalidMob}`,
    passed: validMob === true && invalidMob === false,
  });

  return results;
}
