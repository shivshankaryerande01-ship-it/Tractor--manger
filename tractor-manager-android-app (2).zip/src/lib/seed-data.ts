import { db } from "@/db";
import {
  farmers,
  fields,
  workRecords,
  payments,
  appSettings,
} from "@/db/schema";
import {
  DEFAULT_WORK_RATES,
  calculatePolygonLandArea,
} from "@/lib/agri-math";
import { count } from "drizzle-orm";

let isSeeding = false;

export async function ensureSeeded() {
  if (isSeeding) return;
  try {
    const [{ value: farmerCount }] = await db
      .select({ value: count() })
      .from(farmers);

    if (farmerCount > 0) {
      return;
    }

    isSeeding = true;

    const todayStr = new Date().toISOString().slice(0, 10);
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const threeDaysAgo = new Date(Date.now() - 3 * 86400000)
      .toISOString()
      .slice(0, 10);
    const sixDaysAgo = new Date(Date.now() - 6 * 86400000)
      .toISOString()
      .slice(0, 10);

    // 1. Seed Default App Settings
    const [{ value: settingsCount }] = await db
      .select({ value: count() })
      .from(appSettings);
    if (settingsCount === 0) {
      await db.insert(appSettings).values({
        pinCode: "1234",
        pinEnabled: false,
        ownerName: "सह्याद्री ट्रॅक्टर सर्व्हिसेस (प्रोप्रा. संभाजी देशमुख)",
        ownerMobile: "9850112233",
        tractorModel: "महिंद्रा ५७५ डीआय (MH-12-TR-4590)",
        ratesJson: DEFAULT_WORK_RATES,
        lastBackupAt: new Date().toISOString(),
        firebaseSyncStatus: "SYNCED",
      });
    }

    // 2. Seed Farmers
    const insertedFarmers = await db
      .insert(farmers)
      .values([
        {
          name: "रमेश बाळासाहेब पाटील",
          mobile: "9823451201",
          village: "माळेगाव बुद्रुक, ता. बारामती",
          notes: "ऊस व गहू बागायतदार शेतकरी - विहिरीशेजारील काळी जमीन",
        },
        {
          name: "दत्तात्रय शंकर जाधव",
          mobile: "9765120984",
          village: "निफाड शिवार, ता. निफाड",
          notes: "कांदा व द्राक्ष बाग मशागत ग्राहक",
        },
        {
          name: "तानाजी पांडुरंग शिंदे",
          mobile: "9422087651",
          village: "राहुरी खुर्द, ता. राहुरी",
          notes: "सोयाबीन व हरभरा पेरणी नियमित काम",
        },
        {
          name: "महादेव विठ्ठल पवार",
          mobile: "9921348765",
          village: "कराड नदीकाठ, ता. कराड",
          notes: "हळद व ऊस सरी पाडणे आणि नांगरणी",
        },
      ])
      .returning();

    const f1 = insertedFarmers[0];
    const f2 = insertedFarmers[1];
    const f3 = insertedFarmers[2];
    const f4 = insertedFarmers[3];

    // 3. Seed Satellite Measured Fields with real GPS polygons
    const poly1 = [
      { lat: 18.1511, lng: 74.5768 },
      { lat: 18.1522, lng: 74.5769 },
      { lat: 18.1521, lng: 74.5779 },
      { lat: 18.1510, lng: 74.5778 },
    ];
    const calc1 = calculatePolygonLandArea(poly1);

    const poly2 = [
      { lat: 18.1526, lng: 74.5782 },
      { lat: 18.1534, lng: 74.5783 },
      { lat: 18.1533, lng: 74.5790 },
      { lat: 18.1525, lng: 74.5789 },
    ];
    const calc2 = calculatePolygonLandArea(poly2);

    const poly3 = [
      { lat: 20.0781, lng: 74.1068 },
      { lat: 20.0793, lng: 74.1069 },
      { lat: 20.0792, lng: 74.1082 },
      { lat: 20.0780, lng: 74.1080 },
    ];
    const calc3 = calculatePolygonLandArea(poly3);

    const poly4 = [
      { lat: 19.3924, lng: 74.6484 },
      { lat: 19.3933, lng: 74.6485 },
      { lat: 19.3932, lng: 74.6494 },
      { lat: 19.3923, lng: 74.6493 },
    ];
    const calc4 = calculatePolygonLandArea(poly4);

    const poly5 = [
      { lat: 17.2882, lng: 74.1840 },
      { lat: 17.2892, lng: 74.1841 },
      { lat: 17.2891, lng: 74.1851 },
      { lat: 17.2881, lng: 74.1849 },
    ];
    const calc5 = calculatePolygonLandArea(poly5);

    const insertedFields = await db
      .insert(fields)
      .values([
        {
          farmerId: f1.id,
          fieldName: "विहिरीशेजारील काळे शेत (गट नं. १४२)",
          village: "माळेगाव बुद्रुक, बारामती",
          gatNumber: "गट नं. १४२/अ",
          polygonPoints: poly1,
          areaSqMeters: calc1.areaSqMeters,
          areaAcres: calc1.areaAcres,
          areaGunthas: calc1.areaGunthas,
          areaHectares: calc1.areaHectares,
        },
        {
          farmerId: f1.id,
          fieldName: "कॅनॉल पट्टा ऊस प्लॉट (गट नं. १४५)",
          village: "माळेगाव बुद्रुक, बारामती",
          gatNumber: "गट नं. १४५/ब",
          polygonPoints: poly2,
          areaSqMeters: calc2.areaSqMeters,
          areaAcres: calc2.areaAcres,
          areaGunthas: calc2.areaGunthas,
          areaHectares: calc2.areaHectares,
        },
        {
          farmerId: f2.id,
          fieldName: "कांदा शिवार पूर्व प्लॉट (गट नं. ८८)",
          village: "निफाड शिवार",
          gatNumber: "गट नं. ८८",
          polygonPoints: poly3,
          areaSqMeters: calc3.areaSqMeters,
          areaAcres: calc3.areaAcres,
          areaGunthas: calc3.areaGunthas,
          areaHectares: calc3.areaHectares,
        },
        {
          farmerId: f3.id,
          fieldName: "प्रवरा नदीकाठ शेत (गट नं. २१०)",
          village: "राहुरी खुर्द",
          gatNumber: "गट नं. २१०/१",
          polygonPoints: poly4,
          areaSqMeters: calc4.areaSqMeters,
          areaAcres: calc4.areaAcres,
          areaGunthas: calc4.areaGunthas,
          areaHectares: calc4.areaHectares,
        },
        {
          farmerId: f4.id,
          fieldName: "कृष्णा काठ मळी जमीन (गट नं. ५६)",
          village: "कराड नदीकाठ",
          gatNumber: "गट नं. ५६",
          polygonPoints: poly5,
          areaSqMeters: calc5.areaSqMeters,
          areaAcres: calc5.areaAcres,
          areaGunthas: calc5.areaGunthas,
          areaHectares: calc5.areaHectares,
        },
      ])
      .returning();

    // 4. Seed Tractor Work Records
    const w1Acres = calc1.areaAcres; // ~3.10 acres
    const w1Total = Math.round(w1Acres * 1600);

    const w2Acres = calc2.areaAcres; // ~1.50 acres
    const w2Total = Math.round(w2Acres * 1200);

    const w3Acres = calc3.areaAcres; // ~4.10 acres
    const w3Total = Math.round(w3Acres * 1200);

    const w4Acres = calc4.areaAcres; // ~2.20 acres
    const w4Total = Math.round(w4Acres * 1000);

    const w5Acres = calc5.areaAcres; // ~2.80 acres
    const w5Total = Math.round(w5Acres * 1100);

    const insertedWorks = await db
      .insert(workRecords)
      .values([
        {
          farmerId: f1.id,
          fieldId: insertedFields[0].id,
          workType: "नांगरणी (पलटी नांगर)",
          workDate: todayStr,
          acres: w1Acres,
          gunthas: calc1.areaGunthas,
          ratePerAcre: 1600,
          totalAmount: w1Total,
          notes: "खोल नांगरणी पूर्ण - दोन फाळी पलटी नांगर",
        },
        {
          farmerId: f1.id,
          fieldId: insertedFields[1].id,
          workType: "रोटाव्हेटर (६ फूट)",
          workDate: todayStr,
          acres: w2Acres,
          gunthas: calc2.areaGunthas,
          ratePerAcre: 1200,
          totalAmount: w2Total,
          notes: "ढेप फोडणे व जमीन भुसभुशीत करणे",
        },
        {
          farmerId: f2.id,
          fieldId: insertedFields[2].id,
          workType: "रोटाव्हेटर (६ फूट)",
          workDate: yesterday,
          acres: w3Acres,
          gunthas: calc3.areaGunthas,
          ratePerAcre: 1200,
          totalAmount: w3Total,
          notes: "कांदा लागवडीपूर्वी रोटाव्हेटर मशागत",
        },
        {
          farmerId: f3.id,
          fieldId: insertedFields[3].id,
          workType: "पेरणी (सीड ड्रिल)",
          workDate: threeDaysAgo,
          acres: w4Acres,
          gunthas: calc4.areaGunthas,
          ratePerAcre: 1000,
          totalAmount: w4Total,
          notes: "हरभरा पेरणी खतासह पूर्ण",
        },
        {
          farmerId: f4.id,
          fieldId: insertedFields[4].id,
          workType: "सरी पाडणे (रिजर)",
          workDate: sixDaysAgo,
          acres: w5Acres,
          gunthas: calc5.areaGunthas,
          ratePerAcre: 1100,
          totalAmount: w5Total,
          notes: "ऊस लागवडीसाठी ४.५ फूट सरी पाडली",
        },
      ])
      .returning();

    // 5. Seed Payments (Advance, Partial, and Full Paid scenarios)
    await db.insert(payments).values([
      {
        farmerId: f1.id,
        workRecordId: insertedWorks[0].id,
        amount: 2000,
        paymentType: "ADVANCE",
        paymentMode: "UPI",
        paymentDate: todayStr,
        receiptNumber: "TM-2026-101",
        notes: "डिझेल खर्चासाठी PhonePe ने अॅडव्हान्स जमा",
      },
      {
        farmerId: f1.id,
        workRecordId: insertedWorks[1].id,
        amount: 1500,
        paymentType: "PARTIAL",
        paymentMode: "CASH",
        paymentDate: todayStr,
        receiptNumber: "TM-2026-102",
        notes: "शेतावर रोख रक्कम दिली",
      },
      {
        farmerId: f2.id,
        workRecordId: insertedWorks[2].id,
        amount: w3Total,
        paymentType: "FINAL",
        paymentMode: "CASH",
        paymentDate: yesterday,
        receiptNumber: "TM-2026-103",
        notes: "संपूर्ण बिल चुकते केले",
      },
      {
        farmerId: f3.id,
        workRecordId: insertedWorks[3].id,
        amount: 1000,
        paymentType: "PARTIAL",
        paymentMode: "UPI",
        paymentDate: threeDaysAgo,
        receiptNumber: "TM-2026-104",
        notes: "Google Pay द्वारे हप्ता जमा",
      },
    ]);
  } catch (err) {
    console.error("Error seeding database:", err);
  } finally {
    isSeeding = false;
  }
}
