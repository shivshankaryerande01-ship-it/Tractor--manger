import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title:
    "ट्रॅक्टर मॅनेजर (Tractor Manager) | शेत मोजणी, ट्रॅक्टर काम व बिल हिशोब",
  description:
    "मराठी शेतकरी व ट्रॅक्टर मालकांसाठी सॅटेलाईट जमीन मोजणी (एकर, गुंठे, हेक्टर), ट्रॅक्टर काम नोंद, पेमेंट खातेवही, PDF बिल आणि WhatsApp पावती ॲप. Native Android APK (app-debug.apk) डाउनलोड करा.",
};

const GOOGLE_FONTS_URL =
  "https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@500;600;700;800&family=JetBrains+Mono:wght@500;600;700&display=swap";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="mr">
      <head>
        {/* Fonts are loaded at runtime so production builds never depend on
            external font fetching. CSS variables are defined in globals.css. */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link rel="stylesheet" href={GOOGLE_FONTS_URL} />
      </head>
      <body className="bg-[#F4F7F4] text-[#0F291E] antialiased selection:bg-[#15803D] selection:text-white">
        {children}
      </body>
    </html>
  );
}
