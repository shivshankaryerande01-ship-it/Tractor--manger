import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  farmers,
  fields,
  workRecords,
  payments,
  appSettings,
  type GpsPoint,
  type WorkTypeRate,
} from "@/db/schema";
import { ensureSeeded } from "@/lib/seed-data";
import {
  calculatePolygonLandArea,
  calculateWorkTotal,
  DEFAULT_WORK_RATES,
  isValidIndianMobile,
} from "@/lib/agri-math";
import { desc, eq, and } from "drizzle-orm";

export async function GET() {
  try {
    await ensureSeeded();

    const [allFarmers, allFields, allWorkRecords, allPayments, settingsRows] =
      await Promise.all([
        db.select().from(farmers).orderBy(desc(farmers.id)),
        db.select().from(fields).orderBy(desc(fields.id)),
        db.select().from(workRecords).orderBy(desc(workRecords.id)),
        db.select().from(payments).orderBy(desc(payments.id)),
        db.select().from(appSettings).limit(1),
      ]);

    const settings = settingsRows[0] ?? {
      id: 1,
      pinCode: "1234",
      pinEnabled: false,
      ownerName: "सह्याद्री ट्रॅक्टर सर्व्हिसेस (संभाजी देशमुख)",
      ownerMobile: "9850112233",
      tractorModel: "महिंद्रा ५७५ डीआय (MH-12-TR-4590)",
      ratesJson: DEFAULT_WORK_RATES,
      lastBackupAt: new Date().toISOString(),
      firebaseSyncStatus: "SYNCED",
      googleMapsApiKey: "",
    };

    // A key configured as a server secret takes priority over one saved in Settings.
    // Maps JavaScript keys are browser keys by design (restrict them by HTTP referrer).
    const envMapsKey = (
      process.env.GOOGLE_MAPS_API_KEY ||
      process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY ||
      ""
    ).trim();

    return NextResponse.json({
      ok: true,
      mapsApiKey: envMapsKey || settings.googleMapsApiKey || "",
      mapsKeyFromEnv: Boolean(envMapsKey),
      farmers: allFarmers,
      fields: allFields,
      workRecords: allWorkRecords,
      payments: allPayments,
      settings,
    });
  } catch (error) {
    console.error("GET /api/tractor error:", error);
    return NextResponse.json(
      {
        ok: false,
        error: "डेटाबेस लोड करताना त्रुटी आली (Database fetch failed).",
      },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    const body = await req.json();
    const { action } = body;

    if (action === "ADD_FARMER") {
      const name = String(body.name ?? "").trim();
      const mobile = String(body.mobile ?? "").replace(/\D/g, "");
      const village = String(body.village ?? "").trim();
      const notes = String(body.notes ?? "").trim();

      if (!name || name.length < 2) {
        return NextResponse.json(
          { ok: false, error: "कृपया शेतकऱ्याचे पूर्ण नाव टाका." },
          { status: 400 }
        );
      }
      if (!isValidIndianMobile(mobile)) {
        return NextResponse.json(
          { ok: false, error: "कृपया वैध १०-अंकी मोबाईल नंबर टाका." },
          { status: 400 }
        );
      }
      if (!village) {
        return NextResponse.json(
          { ok: false, error: "कृपया गावाचे नाव टाका." },
          { status: 400 }
        );
      }

      // Duplicate mobile prevention
      const existing = await db
        .select()
        .from(farmers)
        .where(eq(farmers.mobile, mobile));
      if (existing.length > 0) {
        return NextResponse.json(
          {
            ok: false,
            error: `हा मोबाईल नंबर (${mobile}) आधीच '${existing[0].name}' यांच्या नावावर नोंदणीकृत आहे.`,
          },
          { status: 409 }
        );
      }

      const [created] = await db
        .insert(farmers)
        .values({ name, mobile, village, notes })
        .returning();

      return NextResponse.json({ ok: true, farmer: created });
    }

    if (action === "UPDATE_FARMER") {
      const id = Number(body.id);
      const name = String(body.name ?? "").trim();
      const mobile = String(body.mobile ?? "").replace(/\D/g, "");
      const village = String(body.village ?? "").trim();
      const notes = String(body.notes ?? "").trim();

      if (!id || !name || !isValidIndianMobile(mobile) || !village) {
        return NextResponse.json(
          { ok: false, error: "कृपया सर्व माहिती योग्य प्रकारे भरा." },
          { status: 400 }
        );
      }

      const [updated] = await db
        .update(farmers)
        .set({ name, mobile, village, notes })
        .where(eq(farmers.id, id))
        .returning();

      return NextResponse.json({ ok: true, farmer: updated });
    }

    if (action === "DELETE_FARMER") {
      const id = Number(body.id);
      await db.delete(farmers).where(eq(farmers.id, id));
      return NextResponse.json({ ok: true });
    }

    if (action === "SAVE_FIELD") {
      const farmerId = Number(body.farmerId);
      const fieldName = String(body.fieldName ?? "").trim();
      const village = String(body.village ?? "").trim();
      const gatNumber = String(body.gatNumber ?? "").trim();
      const polygonPoints = (body.polygonPoints ?? []) as GpsPoint[];

      if (!farmerId || !fieldName) {
        return NextResponse.json(
          { ok: false, error: "कृपया शेतकरी निवडा आणि शेताचे नाव द्या." },
          { status: 400 }
        );
      }
      if (!Array.isArray(polygonPoints) || polygonPoints.length < 3) {
        return NextResponse.json(
          {
            ok: false,
            error: "क्षेत्रफळ मोजण्यासाठी नकाशावर किमान ३ ते ४ कोपरे (Points) निवडा.",
          },
          { status: 400 }
        );
      }

      const areaCalc = calculatePolygonLandArea(polygonPoints);
      if (areaCalc.areaSqMeters <= 0) {
        return NextResponse.json(
          { ok: false, error: "निवडलेल्या कोपऱ्यांचे क्षेत्रफळ ० आहे. कृपया बिंदू तपासा." },
          { status: 400 }
        );
      }

      if (body.id) {
        // Update existing measured field
        const fieldId = Number(body.id);
        const [updatedField] = await db
          .update(fields)
          .set({
            farmerId,
            fieldName,
            village: village || "स्थानिक शिवार",
            gatNumber,
            polygonPoints,
            areaSqMeters: areaCalc.areaSqMeters,
            areaAcres: areaCalc.areaAcres,
            areaGunthas: areaCalc.areaGunthas,
            areaHectares: areaCalc.areaHectares,
          })
          .where(eq(fields.id, fieldId))
          .returning();

        return NextResponse.json({ ok: true, field: updatedField });
      } else {
        const [createdField] = await db
          .insert(fields)
          .values({
            farmerId,
            fieldName,
            village: village || "स्थानिक शिवार",
            gatNumber,
            polygonPoints,
            areaSqMeters: areaCalc.areaSqMeters,
            areaAcres: areaCalc.areaAcres,
            areaGunthas: areaCalc.areaGunthas,
            areaHectares: areaCalc.areaHectares,
          })
          .returning();

        return NextResponse.json({ ok: true, field: createdField });
      }
    }

    if (action === "DELETE_FIELD") {
      const id = Number(body.id);
      await db.delete(fields).where(eq(fields.id, id));
      return NextResponse.json({ ok: true });
    }

    if (action === "ADD_WORK_RECORD") {
      const farmerId = Number(body.farmerId);
      const fieldId = body.fieldId ? Number(body.fieldId) : null;
      const workType = String(body.workType ?? "").trim();
      const workDate = String(body.workDate ?? "").trim();
      const acres = Number(body.acres ?? 0);
      const gunthas = Number(body.gunthas ?? acres * 40);
      const ratePerAcre = Number(body.ratePerAcre ?? 0);
      const notes = String(body.notes ?? "").trim();
      const advanceAmount = Number(body.advanceAmount ?? 0);
      const advanceMode = String(body.advanceMode ?? "CASH");

      if (!farmerId || !workType || !workDate || acres <= 0 || ratePerAcre <= 0) {
        return NextResponse.json(
          {
            ok: false,
            error: "कृपया शेतकरी, कामाचा प्रकार, क्षेत्रफळ (एकर) आणि दर योग्य टाका.",
          },
          { status: 400 }
        );
      }

      const totalAmount = calculateWorkTotal(acres, ratePerAcre);

      // Duplicate check on same farmer + workDate + workType + acres
      const existingWork = await db
        .select()
        .from(workRecords)
        .where(
          and(
            eq(workRecords.farmerId, farmerId),
            eq(workRecords.workDate, workDate),
            eq(workRecords.workType, workType)
          )
        );
      if (
        existingWork.some(
          (w) =>
            Math.abs(w.acres - acres) < 0.01 &&
            w.fieldId === fieldId &&
            !body.allowDuplicate
        )
      ) {
        return NextResponse.json(
          {
            ok: false,
            error:
              "याच शेतकऱ्याची, याच तारखेची आणि याच कामाची नोंद आधीच जतन केलेली आहे (Duplicate Record Prevented).",
          },
          { status: 409 }
        );
      }

      const [createdWork] = await db
        .insert(workRecords)
        .values({
          farmerId,
          fieldId,
          workType,
          workDate,
          acres: Number(acres.toFixed(2)),
          gunthas: Number(gunthas.toFixed(1)),
          ratePerAcre,
          totalAmount,
          notes,
        })
        .returning();

      if (advanceAmount > 0) {
        const receiptNumber = `TM-${new Date().getFullYear()}-${Math.floor(
          100 + Math.random() * 900
        )}`;
        await db.insert(payments).values({
          farmerId,
          workRecordId: createdWork.id,
          amount: Math.round(advanceAmount),
          paymentType: advanceAmount >= totalAmount ? "FINAL" : "ADVANCE",
          paymentMode: advanceMode,
          paymentDate: workDate,
          receiptNumber,
          notes: `${workType} कामापोटी अॅडव्हान्स जमा`,
        });
      }

      return NextResponse.json({ ok: true, workRecord: createdWork });
    }

    if (action === "DELETE_WORK_RECORD") {
      const id = Number(body.id);
      await db.delete(workRecords).where(eq(workRecords.id, id));
      return NextResponse.json({ ok: true });
    }

    if (action === "ADD_PAYMENT") {
      const farmerId = Number(body.farmerId);
      const workRecordId = body.workRecordId ? Number(body.workRecordId) : null;
      const amount = Math.round(Number(body.amount ?? 0));
      const paymentType = String(body.paymentType ?? "PARTIAL");
      const paymentMode = String(body.paymentMode ?? "CASH");
      const paymentDate =
        String(body.paymentDate ?? "") || new Date().toISOString().slice(0, 10);
      const notes = String(body.notes ?? "").trim();

      if (!farmerId || amount <= 0) {
        return NextResponse.json(
          { ok: false, error: "कृपया शेतकरी निवडा आणि वैध रक्कम (₹) टाका." },
          { status: 400 }
        );
      }

      const receiptNumber = `TM-${new Date().getFullYear()}-${Math.floor(
        1000 + Math.random() * 9000
      )}`;

      const [createdPayment] = await db
        .insert(payments)
        .values({
          farmerId,
          workRecordId,
          amount,
          paymentType,
          paymentMode,
          paymentDate,
          receiptNumber,
          notes,
        })
        .returning();

      return NextResponse.json({ ok: true, payment: createdPayment });
    }

    if (action === "DELETE_PAYMENT") {
      const id = Number(body.id);
      await db.delete(payments).where(eq(payments.id, id));
      return NextResponse.json({ ok: true });
    }

    if (action === "UPDATE_SETTINGS") {
      const existing = await db.select().from(appSettings).limit(1);
      const pinCode = String(body.pinCode ?? "1234").trim();
      const pinEnabled = Boolean(body.pinEnabled);
      const ownerName = String(body.ownerName ?? "").trim();
      const ownerMobile = String(body.ownerMobile ?? "").trim();
      const tractorModel = String(body.tractorModel ?? "").trim();
      const ratesJson = (body.ratesJson ?? DEFAULT_WORK_RATES) as WorkTypeRate[];
      const googleMapsApiKey =
        typeof body.googleMapsApiKey === "string"
          ? body.googleMapsApiKey.trim().slice(0, 200)
          : undefined;

      if (existing.length > 0) {
        const [updated] = await db
          .update(appSettings)
          .set({
            pinCode: pinCode.length === 4 ? pinCode : existing[0].pinCode,
            pinEnabled,
            ownerName: ownerName || existing[0].ownerName,
            ownerMobile: ownerMobile || existing[0].ownerMobile,
            tractorModel: tractorModel || existing[0].tractorModel,
            ratesJson,
            googleMapsApiKey:
              googleMapsApiKey ?? existing[0].googleMapsApiKey,
          })
          .where(eq(appSettings.id, existing[0].id))
          .returning();
        return NextResponse.json({ ok: true, settings: updated });
      }
    }

    if (action === "SYNC_FIREBASE_BACKUP") {
      return NextResponse.json(
        { ok: false, error: "या वेब ॲपमध्ये क्लाउड बॅकअप सेट केलेला नाही. बॅकअप फाईल डाउनलोड करून ठेवा." },
        { status: 501 }
      );
    }

    if (action === "RESTORE_BACKUP") {
      const backup = body.backupData;
      if (!backup || !Array.isArray(backup.farmers)) {
        return NextResponse.json(
          { ok: false, error: "अवैध बॅकअप फाईल." },
          { status: 400 }
        );
      }
      const list = (value: unknown): Record<string, unknown>[] =>
        Array.isArray(value)
          ? value.filter((v) => v && typeof v === "object")
          : [];
      const num = (value: unknown): number => {
        const n = Number(value);
        return Number.isFinite(n) ? n : 0;
      };
      const text = (value: unknown): string =>
        typeof value === "string" || typeof value === "number"
          ? String(value).trim()
          : "";

      // Everything is restored in one transaction. Each record is matched against what is
      // already stored, so restoring the same file twice adds nothing the second time.
      const restoredCount = await db.transaction(async (tx) => {
        let added = 0;

        const farmerIds = new Map<number, number>();
        const byMobile = new Map(
          (await tx.select().from(farmers)).map((f) => [f.mobile, f.id])
        );
        for (const f of list(backup.farmers)) {
          const mobile = text(f.mobile).replace(/\D/g, "");
          const name = text(f.name);
          if (!name || !mobile) continue;
          let localId = byMobile.get(mobile);
          if (localId === undefined) {
            const [created] = await tx
              .insert(farmers)
              .values({ name, mobile, village: text(f.village), notes: text(f.notes) })
              .returning();
            localId = created.id;
            byMobile.set(mobile, localId);
            added++;
          }
          if (f.id !== undefined) farmerIds.set(num(f.id), localId);
        }

        const fieldIds = new Map<number, number>();
        const fieldKey = (farmerId: number, name: string) => `${farmerId}|${name}`;
        const byField = new Map(
          (await tx.select().from(fields)).map((f) => [
            fieldKey(f.farmerId, f.fieldName),
            f.id,
          ])
        );
        for (const f of list(backup.fields)) {
          const farmerId = farmerIds.get(num(f.farmerId));
          const name = text(f.fieldName);
          const polygon: GpsPoint[] = list(f.polygonPoints)
            .map((p) => ({ lat: Number(p.lat), lng: Number(p.lng) }))
            .filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lng));
          if (farmerId === undefined || !name || polygon.length < 3) continue;
          let localId = byField.get(fieldKey(farmerId, name));
          if (localId === undefined) {
            const area = calculatePolygonLandArea(polygon);
            const [created] = await tx
              .insert(fields)
              .values({
                farmerId,
                fieldName: name,
                village: text(f.village),
                gatNumber: text(f.gatNumber),
                polygonPoints: polygon,
                areaSqMeters: area.areaSqMeters,
                areaAcres: area.areaAcres,
                areaGunthas: area.areaGunthas,
                areaHectares: area.areaHectares,
              })
              .returning();
            localId = created.id;
            byField.set(fieldKey(farmerId, name), localId);
            added++;
          }
          if (f.id !== undefined) fieldIds.set(num(f.id), localId);
        }

        const workIds = new Map<number, number>();
        const workKey = (
          farmerId: number,
          date: string,
          type: string,
          fieldId: number | null,
          acres: number
        ) => `${farmerId}|${date}|${type}|${fieldId ?? ""}|${acres.toFixed(2)}`;
        const byWork = new Map(
          (await tx.select().from(workRecords)).map((w) => [
            workKey(w.farmerId, w.workDate, w.workType, w.fieldId, w.acres),
            w.id,
          ])
        );
        for (const w of list(backup.workRecords)) {
          const farmerId = farmerIds.get(num(w.farmerId));
          const workType = text(w.workType);
          const workDate = text(w.workDate);
          const acres = num(w.acres);
          const ratePerAcre = num(w.ratePerAcre);
          if (farmerId === undefined || !workType || !workDate || acres <= 0) continue;
          const fieldId =
            w.fieldId === null || w.fieldId === undefined
              ? null
              : fieldIds.get(num(w.fieldId)) ?? null;
          const key = workKey(farmerId, workDate, workType, fieldId, acres);
          let localId = byWork.get(key);
          if (localId === undefined) {
            const [created] = await tx
              .insert(workRecords)
              .values({
                farmerId,
                fieldId,
                workType,
                workDate,
                acres,
                gunthas: num(w.gunthas) || acres * 40,
                ratePerAcre,
                totalAmount: calculateWorkTotal(acres, ratePerAcre),
                notes: text(w.notes),
              })
              .returning();
            localId = created.id;
            byWork.set(key, localId);
            added++;
          }
          if (w.id !== undefined) workIds.set(num(w.id), localId);
        }

        const paymentKey = (
          farmerId: number,
          receipt: string,
          date: string,
          amount: number
        ) => `${farmerId}|${receipt}|${date}|${Math.round(amount)}`;
        const seenPayments = new Set(
          (await tx.select().from(payments)).map((p) =>
            paymentKey(p.farmerId, p.receiptNumber, p.paymentDate, p.amount)
          )
        );
        for (const p of list(backup.payments)) {
          const farmerId = farmerIds.get(num(p.farmerId));
          const amount = Math.round(num(p.amount));
          const receiptNumber = text(p.receiptNumber);
          const paymentDate = text(p.paymentDate);
          if (farmerId === undefined || amount <= 0 || !receiptNumber || !paymentDate) continue;
          const key = paymentKey(farmerId, receiptNumber, paymentDate, amount);
          if (seenPayments.has(key)) continue;
          await tx.insert(payments).values({
            farmerId,
            workRecordId:
              p.workRecordId === null || p.workRecordId === undefined
                ? null
                : workIds.get(num(p.workRecordId)) ?? null,
            amount,
            paymentType: text(p.paymentType) || "PARTIAL",
            paymentMode: text(p.paymentMode) || "CASH",
            paymentDate,
            receiptNumber,
            notes: text(p.notes),
          });
          seenPayments.add(key);
          added++;
        }

        return added;
      });

      return NextResponse.json({
        ok: true,
        restoredCount,
        message: `बॅकअप रिस्टोर झाला. नवीन नोंदी जोडल्या: ${restoredCount}`,
      });
    }

    return NextResponse.json(
      { ok: false, error: `Unknown action: ${action}` },
      { status: 400 }
    );
  } catch (error) {
    console.error("POST /api/tractor error:", error);
    return NextResponse.json(
      {
        ok: false,
        error: "सर्व्हरवर माहिती जतन करताना त्रुटी आली.",
      },
      { status: 500 }
    );
  }
}
