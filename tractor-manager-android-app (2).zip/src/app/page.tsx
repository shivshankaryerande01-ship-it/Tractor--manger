"use client";

import React, { useState, useEffect, useMemo, useCallback } from "react";
import type { GpsPoint, WorkTypeRate } from "@/db/schema";
import {
  DEFAULT_WORK_RATES,
  acresAndGunthasToDecimalAcres,
  calculateWorkTotal,
  computePaymentSummary,
  formatINR,
  formatMarathiAreaBreakdown,
  isValidIndianMobile,
} from "@/lib/agri-math";
import SatelliteMapMeasurer, {
  type FarmerItem,
  type FieldItem,
} from "@/components/SatelliteMapMeasurer";
import BillReceiptModal, {
  type WorkRecordItem,
  type PaymentItem,
} from "@/components/BillReceiptModal";
import AndroidKotlinStudioModal from "@/components/AndroidKotlinStudioModal";
import {
  PinLockScreenOverlay,
  SecurityAndSettingsModal,
} from "@/components/PinLockAndSettingsModal";
import {
  LayoutDashboard,
  Map,
  Users,
  Tractor,
  Lock,
  Settings,
  Code2,
  FileSpreadsheet,
  Printer,
  Share2,
  PlusCircle,
  CheckCircle2,
  AlertCircle,
  Phone,
  MapPin,
  Edit3,
  Trash2,
  Wallet,
  Calendar,
  CloudCheck,
  IndianRupee,
  FileText,
  ArrowUpRight,
} from "lucide-react";

type NavTab = "DASHBOARD" | "SATELLITE_MAP" | "FARMERS" | "WORK_AND_PAYMENTS";

interface AppSettingsState {
  id: number;
  pinCode: string;
  pinEnabled: boolean;
  ownerName: string;
  ownerMobile: string;
  tractorModel: string;
  ratesJson: WorkTypeRate[];
  lastBackupAt: string;
  firebaseSyncStatus: string;
  googleMapsApiKey?: string;
}

const OFFLINE_CACHE_KEY = "tractor_manager_marathi_offline_v1";

export default function TractorManagerApp() {
  const [activeTab, setActiveTab] = useState<NavTab>("DASHBOARD");
  const [loading, setLoading] = useState<boolean>(true);
  const [isOfflineMode, setIsOfflineMode] = useState<boolean>(false);
  // Google Maps key actually in use (server secret, or the one saved in Settings).
  const [mapsApiKey, setMapsApiKey] = useState<string>("");
  const [mapsKeyFromEnv, setMapsKeyFromEnv] = useState<boolean>(false);

  // Core Persistent State
  const [farmers, setFarmers] = useState<FarmerItem[]>([]);
  const [fields, setFields] = useState<FieldItem[]>([]);
  const [workRecords, setWorkRecords] = useState<WorkRecordItem[]>([]);
  const [payments, setPayments] = useState<PaymentItem[]>([]);
  const [settings, setSettings] = useState<AppSettingsState>({
    id: 1,
    pinCode: "1234",
    pinEnabled: false,
    ownerName: "सह्याद्री ट्रॅक्टर सर्व्हिसेस (संभाजी देशमुख)",
    ownerMobile: "9850112233",
    tractorModel: "महिंद्रा ५७५ डीआय (MH-12-TR-4590)",
    ratesJson: DEFAULT_WORK_RATES,
    lastBackupAt: "",
    firebaseSyncStatus: "SYNCED",
  });

  // Modals & Overlays
  const [isPinLocked, setIsPinLocked] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [showKotlinStudioModal, setShowKotlinStudioModal] =
    useState<boolean>(false);
  const [billModalFarmerId, setBillModalFarmerId] = useState<number | null>(
    null
  );

  // Toast / Alert feedback
  const [toast, setToast] = useState<{
    type: "SUCCESS" | "ERROR";
    message: string;
  } | null>(null);

  const showToast = useCallback(
    (message: string, type: "SUCCESS" | "ERROR" = "SUCCESS") => {
      setToast({ message, type });
      setTimeout(() => {
        setToast((prev) => (prev?.message === message ? null : prev));
      }, 4500);
    },
    []
  );

  // Selected Farmer for cross-screen workflows
  const [selectedFarmerId, setSelectedFarmerId] = useState<number | null>(null);

  // Farmer Form State (Add / Edit Farmer)
  const [editingFarmerId, setEditingFarmerId] = useState<number | null>(null);
  const [farmerNameInput, setFarmerNameInput] = useState<string>("");
  const [farmerMobileInput, setFarmerMobileInput] = useState<string>("");
  const [farmerVillageInput, setFarmerVillageInput] = useState<string>("");
  const [farmerNotesInput, setFarmerNotesInput] = useState<string>("");
  const [farmerSearchQuery, setFarmerSearchQuery] = useState<string>("");

  // Tractor Work Form State
  const [workFarmerId, setWorkFarmerId] = useState<number>(1);
  const [workFieldId, setWorkFieldId] = useState<number | "MANUAL">("MANUAL");
  const [workTypeSelected, setWorkTypeSelected] = useState<string>(
    DEFAULT_WORK_RATES[0].marathiName
  );
  const [workDateInput, setWorkDateInput] = useState<string>(() =>
    new Date().toISOString().slice(0, 10)
  );
  const [workWholeAcresInput, setWorkWholeAcresInput] = useState<number>(2);
  const [workGunthasInput, setWorkGunthasInput] = useState<number>(0);
  const [workRatePerAcreInput, setWorkRatePerAcreInput] =
    useState<number>(1600);
  const [workNotesInput, setWorkNotesInput] = useState<string>("");
  const [workAdvanceInput, setWorkAdvanceInput] = useState<number>(0);
  const [workAdvanceMode, setWorkAdvanceMode] = useState<string>("CASH");

  // Payment Form State
  const [paymentFarmerId, setPaymentFarmerId] = useState<number>(1);
  const [paymentAmountInput, setPaymentAmountInput] = useState<string>("");
  const [paymentTypeInput, setPaymentTypeInput] = useState<string>("PARTIAL");
  const [paymentModeInput, setPaymentModeInput] = useState<string>("CASH");
  const [paymentDateInput, setPaymentDateInput] = useState<string>(() =>
    new Date().toISOString().slice(0, 10)
  );
  const [paymentNotesInput, setPaymentNotesInput] = useState<string>("");
  const [ledgerStatusFilter, setLedgerStatusFilter] = useState<
    "ALL" | "UNPAID" | "PARTIAL" | "PAID"
  >("ALL");

  // Fetch all data from PostgreSQL API with automatic offline localStorage fallback
  const fetchAllData = useCallback(async (initial = false) => {
    try {
      const res = await fetch("/api/tractor", { cache: "no-store" });
      const data = await res.json();
      if (data.ok) {
        setFarmers(data.farmers || []);
        setFields(data.fields || []);
        setWorkRecords(data.workRecords || []);
        setPayments(data.payments || []);
        if (data.settings) {
          setSettings(data.settings);
          if (initial && data.settings.pinEnabled) {
            setIsPinLocked(true);
          }
        }
        setIsOfflineMode(false);
        setMapsApiKey(typeof data.mapsApiKey === "string" ? data.mapsApiKey : "");
        setMapsKeyFromEnv(Boolean(data.mapsKeyFromEnv));

        if (data.farmers?.length > 0) {
          const firstId = data.farmers[0].id;
          setSelectedFarmerId((prev) => prev ?? firstId);
          setWorkFarmerId((prev) =>
            data.farmers.some((f: FarmerItem) => f.id === prev) ? prev : firstId
          );
          setPaymentFarmerId((prev) =>
            data.farmers.some((f: FarmerItem) => f.id === prev) ? prev : firstId
          );
        }

        // Mirror to localStorage for permanent offline resilience
        if (typeof window !== "undefined") {
          localStorage.setItem(
            OFFLINE_CACHE_KEY,
            JSON.stringify({
              farmers: data.farmers,
              fields: data.fields,
              workRecords: data.workRecords,
              payments: data.payments,
              settings: data.settings,
              cachedAt: new Date().toISOString(),
            })
          );
        }
      }
    } catch {
      // Load from offline cache if network is unavailable
      setIsOfflineMode(true);
      if (typeof window !== "undefined") {
        const cached = localStorage.getItem(OFFLINE_CACHE_KEY);
        if (cached) {
          try {
            const parsed = JSON.parse(cached);
            setFarmers(parsed.farmers || []);
            setFields(parsed.fields || []);
            setWorkRecords(parsed.workRecords || []);
            setPayments(parsed.payments || []);
            if (parsed.settings) setSettings(parsed.settings);
          } catch {
            // ignore
          }
        }
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAllData(true);
  }, [fetchAllData]);

  // Computed Decimal Acres & Live Total for Tractor Work Form
  const computedWorkDecimalAcres = useMemo(
    () =>
      acresAndGunthasToDecimalAcres(workWholeAcresInput, workGunthasInput),
    [workWholeAcresInput, workGunthasInput]
  );

  const computedWorkTotalAmount = useMemo(
    () => calculateWorkTotal(computedWorkDecimalAcres, workRatePerAcreInput),
    [computedWorkDecimalAcres, workRatePerAcreInput]
  );

  // When user changes Work Farmer, auto-select their first saved field if available
  const fieldsForSelectedWorkFarmer = useMemo(
    () => fields.filter((f) => f.farmerId === workFarmerId),
    [fields, workFarmerId]
  );

  const handleSelectSavedFieldForWork = (fieldIdOrManual: number | "MANUAL") => {
    setWorkFieldId(fieldIdOrManual);
    if (fieldIdOrManual !== "MANUAL") {
      const found = fields.find((f) => f.id === fieldIdOrManual);
      if (found) {
        const whole = Math.floor(found.areaAcres + 1e-6);
        const remGunthas = Number(
          Math.max(0, (found.areaAcres - whole) * 40).toFixed(1)
        );
        setWorkWholeAcresInput(whole);
        setWorkGunthasInput(remGunthas);
      }
    }
  };

  // When user picks a work type, automatically populate its per-acre rate
  const activeWorkRates = useMemo(
    () =>
      settings.ratesJson && settings.ratesJson.length > 0
        ? settings.ratesJson
        : DEFAULT_WORK_RATES,
    [settings.ratesJson]
  );

  const handleSelectWorkType = (marathiName: string) => {
    setWorkTypeSelected(marathiName);
    const matched = activeWorkRates.find((r) => r.marathiName === marathiName);
    if (matched) {
      setWorkRatePerAcreInput(matched.ratePerAcre);
    }
  };

  // Per-farmer ledger calculations
  const farmerLedgers = useMemo(() => {
    return farmers.map((f) => {
      const fFields = fields.filter((fl) => fl.farmerId === f.id);
      const fWorks = workRecords.filter((w) => w.farmerId === f.id);
      const fPayments = payments.filter((p) => p.farmerId === f.id);
      const totalAcres = fWorks.reduce((s, w) => s + w.acres, 0);
      const totalBilled = fWorks.reduce((s, w) => s + w.totalAmount, 0);
      const totalReceived = fPayments.reduce((s, p) => s + p.amount, 0);
      const paymentSummary = computePaymentSummary(totalBilled, totalReceived);

      return {
        farmer: f,
        fields: fFields,
        works: fWorks,
        payments: fPayments,
        totalAcres: Number(totalAcres.toFixed(2)),
        summary: paymentSummary,
      };
    });
  }, [farmers, fields, workRecords, payments]);

  // Dashboard & Report Metrics (Today's work, Daily & Monthly income, Total received & pending)
  const dashboardMetrics = useMemo(() => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const currentMonthPrefix = todayStr.slice(0, 7); // YYYY-MM

    const todaysWorks = workRecords.filter((w) => w.workDate === todayStr);
    const todaysAcres = todaysWorks.reduce((s, w) => s + w.acres, 0);
    const todaysIncomeBilled = todaysWorks.reduce(
      (s, w) => s + w.totalAmount,
      0
    );

    const monthlyWorks = workRecords.filter((w) =>
      w.workDate.startsWith(currentMonthPrefix)
    );
    const monthlyAcres = monthlyWorks.reduce((s, w) => s + w.acres, 0);
    const monthlyIncomeBilled = monthlyWorks.reduce(
      (s, w) => s + w.totalAmount,
      0
    );

    const allTimeAcres = workRecords.reduce((s, w) => s + w.acres, 0);
    const totalBilledAll = workRecords.reduce((s, w) => s + w.totalAmount, 0);
    const totalReceivedAll = payments.reduce((s, p) => s + p.amount, 0);
    const totalPendingAll = farmerLedgers.reduce(
      (s, l) => s + l.summary.balanceAmount,
      0
    );

    return {
      todayStr,
      todaysWorkCount: todaysWorks.length,
      todaysAcres: Number(todaysAcres.toFixed(2)),
      todaysIncomeBilled,
      monthlyWorkCount: monthlyWorks.length,
      monthlyAcres: Number(monthlyAcres.toFixed(2)),
      monthlyIncomeBilled,
      allTimeAcres: Number(allTimeAcres.toFixed(2)),
      totalBilledAll,
      totalReceivedAll,
      totalPendingAll,
    };
  }, [workRecords, payments, farmerLedgers]);

  // CRUD Handlers
  const handleFarmerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedMobile = farmerMobileInput.replace(/\D/g, "");
    if (!farmerNameInput.trim()) {
      showToast("कृपया शेतकऱ्याचे पूर्ण नाव टाका.", "ERROR");
      return;
    }
    if (!isValidIndianMobile(cleanedMobile)) {
      showToast(
        "कृपया वैध १०-अंकी भारतीय मोबाईल नंबर टाका (उदा. 9823451201).",
        "ERROR"
      );
      return;
    }
    if (!farmerVillageInput.trim()) {
      showToast("कृपया गावाचे नाव टाका.", "ERROR");
      return;
    }

    const res = await fetch("/api/tractor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: editingFarmerId ? "UPDATE_FARMER" : "ADD_FARMER",
        id: editingFarmerId,
        name: farmerNameInput.trim(),
        mobile: cleanedMobile,
        village: farmerVillageInput.trim(),
        notes: farmerNotesInput.trim(),
      }),
    });
    const data = await res.json();
    if (!data.ok) {
      showToast(data.error || "शेतकरी सेव्ह करताना त्रुटी आली.", "ERROR");
      return;
    }

    showToast(
      editingFarmerId
        ? `शेतकरी '${farmerNameInput}' यांची माहिती अपडेट झाली!`
        : `नवीन शेतकरी '${farmerNameInput}' यशस्वीरीत्या जोडले!`
    );
    setEditingFarmerId(null);
    setFarmerNameInput("");
    setFarmerMobileInput("");
    setFarmerVillageInput("");
    setFarmerNotesInput("");
    await fetchAllData();
  };

  const handleEditFarmerClick = (f: FarmerItem) => {
    setEditingFarmerId(f.id);
    setFarmerNameInput(f.name);
    setFarmerMobileInput(f.mobile);
    setFarmerVillageInput(f.village);
    setFarmerNotesInput(f.notes || "");
    setActiveTab("FARMERS");
  };

  const handleDeleteFarmer = async (id: number, name: string) => {
    const res = await fetch("/api/tractor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "DELETE_FARMER", id }),
    });
    const data = await res.json();
    if (data.ok) {
      showToast(`शेतकरी '${name}' रेकॉर्ड हटवले.`);
      await fetchAllData();
    }
  };

  const handleSaveMeasuredField = async (payload: {
    id?: number;
    farmerId: number;
    fieldName: string;
    village: string;
    gatNumber: string;
    polygonPoints: GpsPoint[];
  }): Promise<boolean> => {
    const res = await fetch("/api/tractor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "SAVE_FIELD",
        ...payload,
      }),
    });
    const data = await res.json();
    if (!data.ok) {
      showToast(data.error || "शेत मोजणी सेव्ह करताना त्रुटी आली.", "ERROR");
      return false;
    }
    showToast(`शेत मोजणी '${payload.fieldName}' डेटाबेसमध्ये सेव्ह झाली!`);
    await fetchAllData();
    return true;
  };

  const handleDeleteMeasuredField = async (fieldId: number) => {
    const res = await fetch("/api/tractor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "DELETE_FIELD", id: fieldId }),
    });
    const data = await res.json();
    if (data.ok) {
      showToast("मोजलेले शेत रेकॉर्ड हटवले.");
      await fetchAllData();
    }
  };

  // Jump from Satellite Map Saved Field directly into Tractor Work Form
  const handleStartWorkWithField = (field: FieldItem) => {
    setWorkFarmerId(field.farmerId);
    setWorkFieldId(field.id);
    const whole = Math.floor(field.areaAcres + 1e-6);
    const remGunthas = Number(
      Math.max(0, (field.areaAcres - whole) * 40).toFixed(1)
    );
    setWorkWholeAcresInput(whole);
    setWorkGunthasInput(remGunthas);
    setActiveTab("WORK_AND_PAYMENTS");
    showToast(
      `'${field.fieldName}' (${field.areaAcres.toFixed(
        2
      )} एकर) कामाच्या फॉर्ममध्ये निवडले आहे!`
    );
  };

  // Submit Tractor Work Record
  const handleAddWorkRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (computedWorkDecimalAcres <= 0) {
      showToast("कृपया वैध क्षेत्रफळ (एकर किंवा गुंठे) टाका.", "ERROR");
      return;
    }
    if (workRatePerAcreInput <= 0) {
      showToast("कृपया प्रति एकर दर (₹) टाका.", "ERROR");
      return;
    }

    const res = await fetch("/api/tractor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "ADD_WORK_RECORD",
        farmerId: workFarmerId,
        fieldId: workFieldId === "MANUAL" ? null : workFieldId,
        workType: workTypeSelected,
        workDate: workDateInput,
        acres: computedWorkDecimalAcres,
        gunthas: computedWorkDecimalAcres * 40,
        ratePerAcre: workRatePerAcreInput,
        notes: workNotesInput.trim(),
        advanceAmount: workAdvanceInput,
        advanceMode: workAdvanceMode,
      }),
    });
    const data = await res.json();
    if (!data.ok) {
      showToast(data.error || "काम नोंदवताना त्रुटी आली.", "ERROR");
      return;
    }

    showToast(
      `ट्रॅक्टर काम (${workTypeSelected} - ${formatINR(
        computedWorkTotalAmount
      )}) यशस्वीरीत्या जतन झाले!`
    );
    setWorkNotesInput("");
    setWorkAdvanceInput(0);
    await fetchAllData();
  };

  // Submit Payment Record
  const handleAddPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = Math.round(Number(paymentAmountInput) || 0);
    if (amt <= 0) {
      showToast("कृपया वैध जमा रक्कम (₹) टाका.", "ERROR");
      return;
    }

    const res = await fetch("/api/tractor", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "ADD_PAYMENT",
        farmerId: paymentFarmerId,
        amount: amt,
        paymentType: paymentTypeInput,
        paymentMode: paymentModeInput,
        paymentDate: paymentDateInput,
        notes: paymentNotesInput.trim(),
      }),
    });
    const data = await res.json();
    if (!data.ok) {
      showToast(data.error || "पेमेंट सेव्ह करताना त्रुटी आली.", "ERROR");
      return;
    }

    showToast(
      `${formatINR(amt)} पेमेंट पावती (${
        data.payment?.receiptNumber
      }) यशस्वीरीत्या जमा झाली!`
    );
    setPaymentAmountInput("");
    setPaymentNotesInput("");
    await fetchAllData();
  };

  // Export CSV Report (with UTF-8 BOM so Marathi Devanagari opens cleanly in Excel)
  const handleExportCsvReport = () => {
    const headers = [
      "शेतकरी क्र.",
      "शेतकऱ्याचे नाव",
      "मोबाईल नंबर",
      "गाव",
      "एकूण मोजलेली शेते",
      "एकूण काम (एकर)",
      "एकूण बिल रक्कम (₹)",
      "जमा रक्कम (₹)",
      "येणे बाकी (₹)",
      "पेमेंट स्थिती",
    ];
    const rows = farmerLedgers.map((l) => [
      l.farmer.id,
      `"${l.farmer.name}"`,
      l.farmer.mobile,
      `"${l.farmer.village}"`,
      l.fields.length,
      l.totalAcres.toFixed(2),
      l.summary.totalBilled,
      l.summary.totalReceived,
      l.summary.balanceAmount,
      `"${l.summary.marathiStatus}"`,
    ]);

    const workHeaders = [
      "",
      "कामाची तारीख",
      "शेतकरी नाव",
      "कामाचा प्रकार",
      "क्षेत्रफळ (एकर)",
      "गुंठे",
      "दर प्रति एकर (₹)",
      "एकूण बिल (₹)",
      "तपशील",
    ];
    const workRows = workRecords.map((w) => {
      const f = farmers.find((fl) => fl.id === w.farmerId);
      return [
        "",
        w.workDate,
        `"${f?.name ?? ""}"`,
        `"${w.workType}"`,
        w.acres.toFixed(2),
        w.gunthas.toFixed(1),
        w.ratePerAcre,
        w.totalAmount,
        `"${w.notes ?? ""}"`,
      ];
    });

    const csvString = [
      headers.join(","),
      ...rows.map((r) => r.join(",")),
      "",
      workHeaders.join(","),
      ...workRows.map((r) => r.join(",")),
    ].join("\n");

    const bom = "\uFEFF";
    const blob = new Blob([bom + csvString], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Tractor_Manager_Marathi_Report_${dashboardMetrics.todayStr}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast("मराठी CSV (Excel) अहवाल यशस्वीरीत्या डाउनलोड झाला!");
  };

  // Export Offline JSON Backup
  const handleExportJsonBackup = () => {
    const payload = {
      app: "Tractor Manager Marathi (ट्रॅक्टर मॅनेजर)",
      exportedAt: new Date().toISOString(),
      farmers,
      fields,
      workRecords,
      payments,
      settings,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `TractorManager_Backup_${dashboardMetrics.todayStr}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const billModalFarmer = useMemo(
    () => farmers.find((f) => f.id === billModalFarmerId) || null,
    [farmers, billModalFarmerId]
  );

  const filteredFarmerLedgers = useMemo(() => {
    return farmerLedgers.filter((item) => {
      if (
        ledgerStatusFilter !== "ALL" &&
        item.summary.status !== ledgerStatusFilter
      ) {
        return false;
      }
      if (!farmerSearchQuery.trim()) return true;
      const q = farmerSearchQuery.toLowerCase();
      return (
        item.farmer.name.toLowerCase().includes(q) ||
        item.farmer.mobile.includes(q) ||
        item.farmer.village.toLowerCase().includes(q)
      );
    });
  }, [farmerLedgers, ledgerStatusFilter, farmerSearchQuery]);

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F7F4] text-[#0F291E] pb-24 lg:pb-10">
      {/* PIN LOCK OVERLAY */}
      {isPinLocked && (
        <PinLockScreenOverlay
          expectedPin={settings.pinCode}
          ownerName={settings.ownerName}
          onUnlockSuccess={() => {
            setIsPinLocked(false);
            showToast("पिन पडताळणी यशस्वी! ट्रॅक्टर मॅनेजर अनलॉक झाले.");
          }}
        />
      )}

      {/* TOP AGRICULTURAL HEADER BAR */}
      <header className="no-print sticky top-0 z-30 bg-[#14532D] text-white border-b-2 border-[#0F291E] shadow-md">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-3">
          {/* App Brand & Tractor Owner Info */}
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#22C55E] text-[#0F291E] flex items-center justify-center shadow-inner border-2 border-white shrink-0">
              <Tractor className="w-7 h-7 stroke-[2.4]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
                  ट्रॅक्टर मॅनेजर
                </h1>
                <span className="hidden sm:inline-flex items-center gap-1 bg-[#15803D] border border-emerald-400 text-emerald-100 text-xs font-extrabold px-2.5 py-0.5 rounded-full">
                  <CloudCheck className="w-3.5 h-3.5" />
                  <span>
                    {isOfflineMode
                      ? "ऑफलाईन: जतन केलेली माहिती दाखवत आहे"
                      : "डेटाबेस जोडलेला आहे"}
                  </span>
                </span>
              </div>
              <p className="text-xs sm:text-sm text-emerald-100 font-semibold truncate max-w-[260px] sm:max-w-md">
                {settings.ownerName} • {settings.tractorModel}
              </p>
            </div>
          </div>

          {/* Right Quick Actions: APK Download, Kotlin Architecture/Tests, Settings/Backup, PIN Lock */}
          <div className="flex items-center gap-2">
            <a
              href="/app-debug.apk"
              download="app-debug.apk"
              className="min-h-[44px] px-3 sm:px-4 py-2 rounded-xl bg-[#22C55E] hover:bg-emerald-400 text-[#0F291E] font-extrabold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer shadow-md transition"
              title="app-debug.apk — Gradle-built native Android APK (Kotlin + Jetpack Compose + Room). Install on any Android 8.0+ phone."
            >
              <span className="text-base">📱</span>
              <span>app-debug.apk (22 MB)</span>
            </a>

            <button
              type="button"
              onClick={() => setShowKotlinStudioModal(true)}
              className="min-h-[44px] px-3 sm:px-4 py-2 rounded-xl bg-white/15 hover:bg-white/25 border border-white/25 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer transition"
              title="Native Android Kotlin + Jetpack Compose + JUnit Tests पहा"
            >
              <Code2 className="w-4 h-4 text-[#86EFAC]" />
              <span>Kotlin + टेस्ट्स</span>
            </button>

            <button
              type="button"
              onClick={() => setShowSettingsModal(true)}
              className="min-h-[44px] px-3 sm:px-4 py-2 rounded-xl bg-white/15 hover:bg-white/25 border border-white/25 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer transition"
              title="कामाचे दर, बॅकअप आणि पिन सेटिंग्ज"
            >
              <Settings className="w-4 h-4 text-amber-300" />
              <span className="hidden sm:inline">दर व बॅकअप</span>
            </button>

            <button
              type="button"
              onClick={() => setIsPinLocked(true)}
              className="min-h-[44px] px-3 sm:px-3.5 py-2 rounded-xl bg-[#DC2626] hover:bg-red-700 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer shadow-xs transition"
              title="ॲप पिन लॉक करा"
            >
              <Lock className="w-4 h-4" />
              <span className="hidden md:inline">पिन लॉक</span>
            </button>
          </div>
        </div>

        {/* Desktop & Tablet Large Pill Navigation Bar */}
        <div className="bg-[#0F291E] border-t border-white/10">
          <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2 grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => setActiveTab("DASHBOARD")}
              className={`min-h-[50px] px-3 py-2 rounded-xl font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition ${
                activeTab === "DASHBOARD"
                  ? "bg-[#22C55E] text-[#0F291E] shadow-sm"
                  : "bg-white/10 text-white hover:bg-white/20"
              }`}
            >
              <LayoutDashboard className="w-4 h-4 shrink-0" />
              <span>१. डॅशबोर्ड व अहवाल</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("SATELLITE_MAP")}
              className={`min-h-[50px] px-3 py-2 rounded-xl font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition ${
                activeTab === "SATELLITE_MAP"
                  ? "bg-[#22C55E] text-[#0F291E] shadow-sm"
                  : "bg-white/10 text-white hover:bg-white/20"
              }`}
            >
              <Map className="w-4 h-4 shrink-0" />
              <span>२. सॅटेलाईट जमीन मोजणी</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("FARMERS")}
              className={`min-h-[50px] px-3 py-2 rounded-xl font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition ${
                activeTab === "FARMERS"
                  ? "bg-[#22C55E] text-[#0F291E] shadow-sm"
                  : "bg-white/10 text-white hover:bg-white/20"
              }`}
            >
              <Users className="w-4 h-4 shrink-0" />
              <span>३. शेतकरी व शेत रेकॉर्ड</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("WORK_AND_PAYMENTS")}
              className={`min-h-[50px] px-3 py-2 rounded-xl font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition ${
                activeTab === "WORK_AND_PAYMENTS"
                  ? "bg-[#22C55E] text-[#0F291E] shadow-sm"
                  : "bg-white/10 text-white hover:bg-white/20"
              }`}
            >
              <Tractor className="w-4 h-4 shrink-0" />
              <span>४. ट्रॅक्टर काम व पेमेंट</span>
            </button>
          </div>
        </div>
      </header>

      {/* FLOATING FEEDBACK TOAST */}
      {toast && (
        <div className="no-print fixed bottom-20 lg:bottom-6 right-4 z-40 max-w-md">
          <div
            className={`px-4 py-3.5 rounded-2xl shadow-xl border-2 font-extrabold text-sm flex items-center gap-2.5 ${
              toast.type === "SUCCESS"
                ? "bg-[#14532D] text-white border-[#22C55E]"
                : "bg-[#DC2626] text-white border-red-200"
            }`}
          >
            {toast.type === "SUCCESS" ? (
              <CheckCircle2 className="w-5 h-5 text-[#22C55E] shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-white shrink-0" />
            )}
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* MAIN CONTENT CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 py-5">
        {loading ? (
          <div className="bg-white rounded-3xl border-2 border-[#D1E2D4] p-12 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-[#15803D] text-white flex items-center justify-center mx-auto animate-pulse">
              <Tractor className="w-7 h-7" />
            </div>
            <div className="text-lg font-extrabold text-[#0F291E]">
              ट्रॅक्टर मॅनेजर डेटाबेस लोड होत आहे...
            </div>
          </div>
        ) : (
          <>
            {/* =========================================================
                TAB 1: DASHBOARD AND REPORTS (डॅशबोर्ड आणि अहवाल)
               ========================================================= */}
            {activeTab === "DASHBOARD" && (
              <div className="space-y-6">
                {/* Primary Hero Banner with Large Quick Action Buttons */}
                <div className="no-print bg-gradient-to-r from-[#14532D] via-[#15803D] to-[#166534] text-white rounded-3xl p-5 sm:p-6 shadow-md border-2 border-[#0F291E]">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div>
                      <span className="inline-block bg-white/20 text-white text-xs font-extrabold px-3 py-1 rounded-full mb-2">
                        आजची तारीख: {dashboardMetrics.todayStr} • मराठी शेत व्यवस्थापन
                      </span>
                      <h2 className="text-2xl sm:text-3xl font-extrabold">
                        नमस्कार! आजचे ट्रॅक्टर काम व शेत मोजणी सुरू करा
                      </h2>
                      <p className="text-sm text-emerald-100 font-semibold mt-1">
                        सॅटेलाईट नकाशावर जमीन मोजा, प्रति-एकर दराने बिल काढा आणि WhatsApp वर पावती पाठवा.
                      </p>
                    </div>

                    {/* Large Outdoor-Friendly Primary Action Buttons */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => setActiveTab("SATELLITE_MAP")}
                        className="min-h-[58px] px-4 py-3 rounded-2xl bg-white hover:bg-emerald-50 text-[#14532D] font-extrabold text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer transition"
                      >
                        <Map className="w-5 h-5 text-[#15803D]" />
                        <span>जमीन मोजा (Map)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setActiveTab("WORK_AND_PAYMENTS")}
                        className="min-h-[58px] px-4 py-3 rounded-2xl bg-[#22C55E] hover:bg-emerald-400 text-[#0F291E] font-extrabold text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer transition"
                      >
                        <Tractor className="w-5 h-5" />
                        <span>नवीन काम नोंदवा</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setActiveTab("FARMERS")}
                        className="min-h-[58px] px-4 py-3 rounded-2xl bg-[#0F291E] hover:bg-black/60 text-white border border-emerald-400 font-extrabold text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer transition"
                      >
                        <PlusCircle className="w-5 h-5 text-[#22C55E]" />
                        <span>नवीन शेतकरी जोडा</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* 4 KPI Summary Cards (Today's Work/Acres, Daily & Monthly Income, Total Received, Pending Balance) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {/* Card 1: Today's Work & Total Acres */}
                  <div className="bg-white rounded-2xl p-5 border-2 border-[#D1E2D4] shadow-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold uppercase tracking-wider text-[#335441]">
                        आजचे काम व क्षेत्रफळ
                      </span>
                      <span className="w-9 h-9 rounded-xl bg-emerald-100 text-[#15803D] flex items-center justify-center">
                        <Tractor className="w-5 h-5" />
                      </span>
                    </div>
                    <div className="text-3xl font-extrabold text-[#15803D] font-tabular mt-2">
                      {dashboardMetrics.todaysAcres} <span className="text-lg">एकर</span>
                    </div>
                    <div className="mt-1 text-xs font-bold text-[#335441] flex items-center justify-between">
                      <span>आजच्या कामाच्या नोंदी: {dashboardMetrics.todaysWorkCount}</span>
                      <span className="text-[#0F291E]">
                        एकूण: {dashboardMetrics.allTimeAcres} एकर
                      </span>
                    </div>
                  </div>

                  {/* Card 2: Daily & Monthly Income */}
                  <div className="bg-white rounded-2xl p-5 border-2 border-[#D1E2D4] shadow-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold uppercase tracking-wider text-[#335441]">
                        आजचे व मासिक उत्पन्न
                      </span>
                      <span className="w-9 h-9 rounded-xl bg-sky-100 text-[#0284C7] flex items-center justify-center">
                        <Calendar className="w-5 h-5" />
                      </span>
                    </div>
                    <div className="text-3xl font-extrabold text-[#0F291E] font-tabular mt-2">
                      {formatINR(dashboardMetrics.todaysIncomeBilled)}
                    </div>
                    <div className="mt-1 text-xs font-bold text-[#0284C7] flex items-center justify-between">
                      <span>आजचे बिल उत्पन्न</span>
                      <span>
                        चालू महिना: {formatINR(dashboardMetrics.monthlyIncomeBilled)}
                      </span>
                    </div>
                  </div>

                  {/* Card 3: Total Received Payments */}
                  <div className="bg-white rounded-2xl p-5 border-2 border-[#16A34A] shadow-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold uppercase tracking-wider text-[#15803D]">
                        एकूण जमा रक्कम (Received)
                      </span>
                      <span className="w-9 h-9 rounded-xl bg-emerald-100 text-[#15803D] flex items-center justify-center">
                        <CheckCircle2 className="w-5 h-5" />
                      </span>
                    </div>
                    <div className="text-3xl font-extrabold text-[#15803D] font-tabular mt-2">
                      {formatINR(dashboardMetrics.totalReceivedAll)}
                    </div>
                    <div className="mt-1 text-xs font-bold text-[#335441] flex items-center justify-between">
                      <span>एकूण बिल: {formatINR(dashboardMetrics.totalBilledAll)}</span>
                      <span>पावत्या: {payments.length}</span>
                    </div>
                  </div>

                  {/* Card 4: Total Pending Payments */}
                  <div className="bg-white rounded-2xl p-5 border-2 border-amber-400 shadow-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-extrabold uppercase tracking-wider text-[#B45309]">
                        एकूण येणे बाकी (Pending)
                      </span>
                      <span className="w-9 h-9 rounded-xl bg-amber-100 text-[#B45309] flex items-center justify-center">
                        <Wallet className="w-5 h-5" />
                      </span>
                    </div>
                    <div className="text-3xl font-extrabold text-[#DC2626] font-tabular mt-2">
                      {formatINR(dashboardMetrics.totalPendingAll)}
                    </div>
                    <div className="mt-1 text-xs font-bold text-[#B45309] flex items-center justify-between">
                      <span>
                        बाकीदार शेतकरी:{" "}
                        {
                          farmerLedgers.filter(
                            (l) => l.summary.balanceAmount > 0
                          ).length
                        }
                      </span>
                      <button
                        type="button"
                        onClick={() => setActiveTab("WORK_AND_PAYMENTS")}
                        className="underline text-[#0F291E] cursor-pointer"
                      >
                        वसुली पहा →
                      </button>
                    </div>
                  </div>
                </div>

                {/* Reports Export Bar (PDF & CSV) */}
                <div className="no-print bg-white rounded-2xl border-2 border-[#D1E2D4] p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
                  <div>
                    <h3 className="text-base sm:text-lg font-extrabold text-[#0F291E]">
                      📊 संपूर्ण हिशोब अहवाल एक्सपोर्ट करा (Export Reports to PDF & CSV)
                    </h3>
                    <p className="text-xs sm:text-sm font-semibold text-[#335441]">
                      सर्व शेतकरी खातेवही, मोजलेली जमीन, कामाच्या नोंदी आणि जमा-बाकी हिशोब PDF किंवा Excel CSV मध्ये डाउनलोड करा.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 shrink-0">
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="min-h-[52px] px-4 py-2.5 rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-extrabold text-sm flex items-center gap-2 shadow-sm cursor-pointer transition"
                    >
                      <Printer className="w-4 h-4" />
                      <span>PDF अहवाल डाउनलोड / प्रिंट</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleExportCsvReport}
                      className="min-h-[52px] px-4 py-2.5 rounded-xl bg-white hover:bg-emerald-50 text-[#15803D] border-2 border-[#15803D] font-extrabold text-sm flex items-center gap-2 cursor-pointer transition"
                    >
                      <FileSpreadsheet className="w-4 h-4" />
                      <span>CSV (Excel) एक्सपोर्ट करा</span>
                    </button>
                  </div>
                </div>

                {/* Farmer-wise Balance & Quick Bill Table */}
                <div className="bg-white rounded-2xl border-2 border-[#D1E2D4] p-5 shadow-xs space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#D1E2D4] pb-3">
                    <div>
                      <h3 className="text-lg font-extrabold text-[#0F291E]">
                        📋 शेतकरी निहाय काम, जमा व बाकी हिशोब (Farmer Account Summary)
                      </h3>
                      <p className="text-xs font-semibold text-[#335441]">
                        कोणत्याही शेतकऱ्याचे PDF बिल काढा किंवा WhatsApp वर थेट पावती पाठवा
                      </p>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs sm:text-sm">
                      <thead>
                        <tr className="bg-[#F4F7F4] text-[#0F291E] border-b-2 border-[#D1E2D4]">
                          <th className="p-3 font-extrabold">शेतकऱ्याचे नाव व गाव</th>
                          <th className="p-3 font-extrabold text-center">मोजलेली शेते</th>
                          <th className="p-3 font-extrabold text-right">एकूण काम (एकर)</th>
                          <th className="p-3 font-extrabold text-right">एकूण बिल (₹)</th>
                          <th className="p-3 font-extrabold text-right">जमा (₹)</th>
                          <th className="p-3 font-extrabold text-right">येणे बाकी (₹)</th>
                          <th className="p-3 font-extrabold text-center">स्थिती</th>
                          <th className="no-print p-3 font-extrabold text-right">
                            बिल / WhatsApp
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#D1E2D4]">
                        {farmerLedgers.map((item) => (
                          <tr
                            key={item.farmer.id}
                            className="hover:bg-[#F4F7F4]/60 transition"
                          >
                            <td className="p-3">
                              <div className="font-extrabold text-[#0F291E] text-sm sm:text-base">
                                {item.farmer.name}
                              </div>
                              <div className="text-xs font-bold text-[#335441]">
                                📍 {item.farmer.village} • 📞 {item.farmer.mobile}
                              </div>
                            </td>
                            <td className="p-3 text-center font-extrabold font-tabular">
                              {item.fields.length} प्लॉट
                            </td>
                            <td className="p-3 text-right font-extrabold font-tabular">
                              {item.totalAcres.toFixed(2)} एकर
                            </td>
                            <td className="p-3 text-right font-extrabold font-tabular">
                              {formatINR(item.summary.totalBilled)}
                            </td>
                            <td className="p-3 text-right font-extrabold text-[#15803D] font-tabular">
                              {formatINR(item.summary.totalReceived)}
                            </td>
                            <td className="p-3 text-right font-extrabold text-[#DC2626] font-tabular">
                              {formatINR(item.summary.balanceAmount)}
                            </td>
                            <td className="p-3 text-center">
                              <span
                                className={`inline-block px-3 py-1 rounded-full text-xs font-extrabold ${
                                  item.summary.status === "PAID"
                                    ? "bg-emerald-100 text-[#15803D]"
                                    : item.summary.status === "PARTIAL"
                                    ? "bg-amber-100 text-[#B45309]"
                                    : "bg-red-100 text-[#DC2626]"
                                }`}
                              >
                                {item.summary.marathiStatus}
                              </span>
                            </td>
                            <td className="no-print p-3 text-right">
                              <button
                                type="button"
                                onClick={() =>
                                  setBillModalFarmerId(item.farmer.id)
                                }
                                className="min-h-[42px] px-3.5 py-2 rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-extrabold text-xs inline-flex items-center gap-1.5 cursor-pointer shadow-xs"
                              >
                                <FileText className="w-4 h-4" />
                                <span>PDF बिल / WhatsApp</span>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Recent Tractor Work History List */}
                <div className="bg-white rounded-2xl border-2 border-[#D1E2D4] p-5 shadow-xs space-y-4">
                  <div className="flex items-center justify-between border-b border-[#D1E2D4] pb-3">
                    <div>
                      <h3 className="text-lg font-extrabold text-[#0F291E]">
                        🚜 अलीकडील ट्रॅक्टर काम नोंदी (Recent Work History)
                      </h3>
                      <p className="text-xs font-semibold text-[#335441]">
                        एकर × दर सूत्रानुसार स्वयंचलित गणना केलेली कामे
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveTab("WORK_AND_PAYMENTS")}
                      className="no-print text-xs sm:text-sm font-extrabold text-[#15803D] flex items-center gap-1 cursor-pointer"
                    >
                      <span>सर्व कामे पहा</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {workRecords.slice(0, 6).map((w) => {
                      const f = farmers.find((fl) => fl.id === w.farmerId);
                      const fld = fields.find((fl) => fl.id === w.fieldId);
                      return (
                        <div
                          key={w.id}
                          className="rounded-xl p-4 bg-[#F4F7F4] border-2 border-[#D1E2D4] flex items-center justify-between gap-3"
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="bg-[#15803D] text-white text-xs font-extrabold px-2.5 py-0.5 rounded-md">
                                {w.workType}
                              </span>
                              <span className="text-xs font-bold text-[#335441] font-tabular">
                                📅 {w.workDate}
                              </span>
                            </div>
                            <div className="font-extrabold text-[#0F291E] text-base mt-1">
                              {f?.name ?? "शेतकरी"}
                            </div>
                            <div className="text-xs font-semibold text-[#335441]">
                              {fld ? fld.fieldName : "शेत प्लॉट"} •{" "}
                              {w.acres.toFixed(2)} एकर ({w.gunthas.toFixed(0)}{" "}
                              गुंठे) × {formatINR(w.ratePerAcre)}/एकर
                            </div>
                          </div>

                          <div className="text-right shrink-0">
                            <div className="text-lg font-extrabold text-[#15803D] font-tabular">
                              {formatINR(w.totalAmount)}
                            </div>
                            <button
                              type="button"
                              onClick={() => setBillModalFarmerId(w.farmerId)}
                              className="no-print mt-1 text-xs font-bold text-[#0284C7] underline cursor-pointer"
                            >
                              पावती पहा
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* =========================================================
                TAB 2: SATELLITE LAND MEASUREMENT (सॅटेलाईट जमीन मोजणी)
               ========================================================= */}
            {activeTab === "SATELLITE_MAP" && (
              <SatelliteMapMeasurer
                farmers={farmers}
                fields={fields}
                selectedFarmerId={selectedFarmerId}
                googleMapsApiKey={mapsApiKey}
                onOpenSettings={() => setShowSettingsModal(true)}
                onSelectFarmerId={(id) => setSelectedFarmerId(id)}
                onSaveField={handleSaveMeasuredField}
                onDeleteField={handleDeleteMeasuredField}
                onStartWorkWithField={handleStartWorkWithField}
              />
            )}

            {/* =========================================================
                TAB 3: FARMER MANAGEMENT (शेतकरी व शेत जमीन व्यवस्थापन)
               ========================================================= */}
            {activeTab === "FARMERS" && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Left 5 Cols: Add or Edit Farmer Form */}
                <div className="lg:col-span-5">
                  <form
                    onSubmit={handleFarmerSubmit}
                    className="bg-white rounded-2xl border-2 border-[#D1E2D4] p-5 shadow-sm space-y-4 sticky top-36"
                  >
                    <div className="flex items-center justify-between border-b border-[#D1E2D4] pb-3">
                      <div>
                        <h2 className="text-lg font-extrabold text-[#0F291E]">
                          {editingFarmerId
                            ? "✏️ शेतकरी माहिती संपादित करा"
                            : "👤 नवीन शेतकरी खाते जोडा"}
                        </h2>
                        <p className="text-xs font-semibold text-[#335441]">
                          शेतकऱ्याचे नाव, १०-अंकी मोबाईल नंबर आणि गाव जतन करा
                        </p>
                      </div>
                      {editingFarmerId && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingFarmerId(null);
                            setFarmerNameInput("");
                            setFarmerMobileInput("");
                            setFarmerVillageInput("");
                            setFarmerNotesInput("");
                          }}
                          className="text-xs font-extrabold text-[#DC2626] underline cursor-pointer"
                        >
                          रद्द करा
                        </button>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-[#0F291E] mb-1">
                        शेतकऱ्याचे पूर्ण नाव (Farmer Name) *
                      </label>
                      <input
                        type="text"
                        required
                        value={farmerNameInput}
                        onChange={(e) => setFarmerNameInput(e.target.value)}
                        placeholder="उदा. संभाजी दत्तात्रय देशमुख"
                        className="w-full min-h-[52px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2.5 font-bold text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-[#0F291E] mb-1">
                        मोबाईल नंबर (१०-अंकी WhatsApp नंबर) *
                      </label>
                      <input
                        type="tel"
                        required
                        maxLength={10}
                        value={farmerMobileInput}
                        onChange={(e) =>
                          setFarmerMobileInput(
                            e.target.value.replace(/\D/g, "")
                          )
                        }
                        placeholder="उदा. 9823451201"
                        className="w-full min-h-[52px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2.5 font-bold font-tabular text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-[#0F291E] mb-1">
                        गाव / शिवार (Village) *
                      </label>
                      <input
                        type="text"
                        required
                        value={farmerVillageInput}
                        onChange={(e) => setFarmerVillageInput(e.target.value)}
                        placeholder="उदा. माळेगाव बुद्रुक, ता. बारामती"
                        className="w-full min-h-[52px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2.5 font-bold text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-bold text-[#0F291E] mb-1">
                        इतर माहिती / पीक नोंद (Notes)
                      </label>
                      <input
                        type="text"
                        value={farmerNotesInput}
                        onChange={(e) => setFarmerNotesInput(e.target.value)}
                        placeholder="उदा. ऊस व कांदा बागायतदार शेतकरी"
                        className="w-full min-h-[48px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-semibold text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full min-h-[56px] rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-extrabold text-base shadow-md flex items-center justify-center gap-2 cursor-pointer transition"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                      <span>
                        {editingFarmerId
                          ? "शेतकरी माहिती अपडेट करा"
                          : "शेतकरी खाते सेव्ह करा"}
                      </span>
                    </button>
                  </form>
                </div>

                {/* Right 7 Cols: Farmers Directory with Multiple Land Records per Farmer */}
                <div className="lg:col-span-7 space-y-4">
                  {/* Search Bar */}
                  <div className="bg-white rounded-2xl border-2 border-[#D1E2D4] p-4 flex flex-wrap items-center justify-between gap-3">
                    <input
                      type="text"
                      value={farmerSearchQuery}
                      onChange={(e) => setFarmerSearchQuery(e.target.value)}
                      placeholder="शेतकऱ्याचे नाव, गाव किंवा मोबाईल नंबर शोधा..."
                      className="flex-1 min-h-[48px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-bold text-sm text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                    />
                    <span className="text-xs sm:text-sm font-extrabold text-[#15803D] bg-emerald-50 px-3 py-2 rounded-xl border border-[#16A34A]">
                      एकूण शेतकरी: {farmers.length}
                    </span>
                  </div>

                  {/* Farmer Cards with Multiple Land Records */}
                  {filteredFarmerLedgers.map((item) => (
                    <div
                      key={item.farmer.id}
                      className="bg-white rounded-2xl border-2 border-[#D1E2D4] p-5 shadow-xs space-y-4"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-[#D1E2D4] pb-3">
                        <div>
                          <h3 className="text-lg sm:text-xl font-extrabold text-[#0F291E]">
                            {item.farmer.name}
                          </h3>
                          <div className="flex flex-wrap items-center gap-3 mt-1 text-xs sm:text-sm font-bold text-[#335441]">
                            <span className="flex items-center gap-1">
                              <Phone className="w-4 h-4 text-[#15803D]" />
                              +91 {item.farmer.mobile}
                            </span>
                            <span className="flex items-center gap-1">
                              <MapPin className="w-4 h-4 text-[#15803D]" />
                              {item.farmer.village}
                            </span>
                          </div>
                          {item.farmer.notes && (
                            <p className="text-xs font-semibold text-[#335441] mt-1">
                              📝 {item.farmer.notes}
                            </p>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleEditFarmerClick(item.farmer)}
                            className="min-h-[40px] px-3 py-1.5 rounded-xl bg-[#F4F7F4] hover:bg-emerald-50 text-[#0F291E] border border-[#D1E2D4] text-xs font-extrabold flex items-center gap-1 cursor-pointer"
                          >
                            <Edit3 className="w-3.5 h-3.5 text-[#15803D]" />
                            <span>संपादित करा</span>
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              setBillModalFarmerId(item.farmer.id)
                            }
                            className="min-h-[40px] px-3 py-1.5 rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white text-xs font-extrabold flex items-center gap-1 cursor-pointer"
                          >
                            <Share2 className="w-3.5 h-3.5" />
                            <span>बिल / WhatsApp</span>
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              handleDeleteFarmer(
                                item.farmer.id,
                                item.farmer.name
                              )
                            }
                            className="min-h-[40px] px-2.5 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-[#DC2626] border border-red-200 text-xs font-bold cursor-pointer"
                            title="शेतकरी हटवा"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Multiple Land Records for this Farmer */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs sm:text-sm font-extrabold text-[#0F291E]">
                            🌾 शेतकऱ्याच्या जमिनीचे रेकॉर्ड्स (Measured Land Plots:{" "}
                            {item.fields.length})
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedFarmerId(item.farmer.id);
                              setActiveTab("SATELLITE_MAP");
                            }}
                            className="text-xs font-extrabold text-[#15803D] hover:underline flex items-center gap-1 cursor-pointer"
                          >
                            <PlusCircle className="w-3.5 h-3.5" />
                            <span>नकाशावर नवीन शेत मोजा</span>
                          </button>
                        </div>

                        {item.fields.length > 0 ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                            {item.fields.map((fl) => (
                              <div
                                key={fl.id}
                                className="rounded-xl p-3 bg-[#F4F7F4] border border-[#D1E2D4] flex items-center justify-between gap-2"
                              >
                                <div>
                                  <div className="font-extrabold text-xs sm:text-sm text-[#0F291E]">
                                    {fl.fieldName}
                                  </div>
                                  <div className="text-xs font-bold text-[#15803D] font-tabular">
                                    {fl.areaAcres.toFixed(2)} एकर |{" "}
                                    {fl.areaGunthas.toFixed(1)} गुंठे |{" "}
                                    {fl.areaHectares.toFixed(3)} हे.
                                  </div>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => handleStartWorkWithField(fl)}
                                  className="px-2.5 py-1.5 rounded-lg bg-[#15803D] text-white text-xs font-extrabold shrink-0 cursor-pointer"
                                >
                                  काम नोंदवा
                                </button>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-xs font-semibold text-[#335441] bg-[#F4F7F4] rounded-xl p-3">
                            या शेतकऱ्यासाठी अद्याप शेत मोजणी केलेली नाही. &ldquo;नकाशावर नवीन शेत मोजा&rdquo; वर क्लिक करा.
                          </div>
                        )}
                      </div>

                      {/* Financial Summary Footer for this Farmer */}
                      <div className="pt-2 border-t border-[#D1E2D4] grid grid-cols-3 gap-2 text-xs sm:text-sm">
                        <div className="bg-[#F4F7F4] p-2.5 rounded-xl">
                          <span className="text-[#335441] font-bold block text-xs">
                            एकूण बिल:
                          </span>
                          <span className="font-extrabold text-[#0F291E] font-tabular">
                            {formatINR(item.summary.totalBilled)}
                          </span>
                        </div>
                        <div className="bg-emerald-50 p-2.5 rounded-xl">
                          <span className="text-[#15803D] font-bold block text-xs">
                            एकूण जमा:
                          </span>
                          <span className="font-extrabold text-[#15803D] font-tabular">
                            {formatINR(item.summary.totalReceived)}
                          </span>
                        </div>
                        <div className="bg-amber-50 p-2.5 rounded-xl">
                          <span className="text-[#B45309] font-bold block text-xs">
                            येणे बाकी:
                          </span>
                          <span className="font-extrabold text-[#DC2626] font-tabular">
                            {formatINR(item.summary.balanceAmount)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* =========================================================
                TAB 4: TRACTOR WORK RECORDS & PAYMENTS (ट्रॅक्टर काम व पेमेंट)
               ========================================================= */}
            {activeTab === "WORK_AND_PAYMENTS" && (
              <div className="space-y-8">
                {/* Top Split: Record Tractor Work Form (Left 6 Cols) + Record Payment Form (Right 6 Cols) */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Form 1: Record Tractor Work (ट्रॅक्टर काम नोंद) */}
                  <form
                    onSubmit={handleAddWorkRecord}
                    className="lg:col-span-7 bg-white rounded-2xl border-2 border-[#15803D] p-5 sm:p-6 shadow-sm space-y-4"
                  >
                    <div className="border-b border-[#D1E2D4] pb-3 flex items-center justify-between">
                      <div>
                        <h2 className="text-lg sm:text-xl font-extrabold text-[#0F291E]">
                          🚜 १. नवीन ट्रॅक्टर काम नोंदवा (Record Tractor Work)
                        </h2>
                        <p className="text-xs font-semibold text-[#335441]">
                          शेतकरी, मोजलेले शेत आणि कामाचा प्रकार निवडा — एकूण बिल आपोआप मोजले जाईल
                        </p>
                      </div>
                      <span className="bg-emerald-100 text-[#15803D] text-xs font-extrabold px-3 py-1 rounded-full">
                        Total = एकर × दर
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                      {/* Select Farmer */}
                      <div>
                        <label className="block text-sm font-bold text-[#0F291E] mb-1">
                          शेतकरी निवडा (Select Farmer) *
                        </label>
                        <select
                          value={workFarmerId}
                          onChange={(e) => {
                            const nextId = Number(e.target.value);
                            setWorkFarmerId(nextId);
                            setPaymentFarmerId(nextId);
                            const farmerFields = fields.filter(
                              (fl) => fl.farmerId === nextId
                            );
                            if (farmerFields.length > 0) {
                              handleSelectSavedFieldForWork(farmerFields[0].id);
                            } else {
                              setWorkFieldId("MANUAL");
                            }
                          }}
                          className="w-full min-h-[52px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-bold text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                        >
                          {farmers.map((f) => (
                            <option key={f.id} value={f.id}>
                              {f.name} ({f.village})
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Select Date */}
                      <div>
                        <label className="block text-sm font-bold text-[#0F291E] mb-1">
                          कामाची तारीख (Work Date) *
                        </label>
                        <input
                          type="date"
                          required
                          value={workDateInput}
                          onChange={(e) => setWorkDateInput(e.target.value)}
                          className="w-full min-h-[52px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-bold font-tabular text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Select Saved Measured Field */}
                    <div>
                      <label className="block text-sm font-bold text-[#0F291E] mb-1">
                        सेव्ह केलेले शेत निवडा (Select Saved Measured Field)
                      </label>
                      <select
                        value={workFieldId}
                        onChange={(e) =>
                          handleSelectSavedFieldForWork(
                            e.target.value === "MANUAL"
                              ? "MANUAL"
                              : Number(e.target.value)
                          )
                        }
                        className="w-full min-h-[52px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-bold text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                      >
                        <option value="MANUAL">
                          ✍️ हाताने एकर / गुंठे टाका (Manual Area Entry)
                        </option>
                        {fieldsForSelectedWorkFarmer.map((fl) => (
                          <option key={fl.id} value={fl.id}>
                            📍 {fl.fieldName} — {fl.areaAcres.toFixed(2)} एकर (
                            {fl.areaGunthas.toFixed(1)} गुंठे)
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Select Work Type Pills */}
                    <div>
                      <label className="block text-sm font-bold text-[#0F291E] mb-1.5">
                        कामाचा प्रकार निवडा (वेगवेगळ्या कामांसाठी वेगवेगळे प्रति-एकर दर) *
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {activeWorkRates.map((rateObj) => {
                          const active =
                            workTypeSelected === rateObj.marathiName;
                          return (
                            <button
                              key={rateObj.id}
                              type="button"
                              onClick={() =>
                                handleSelectWorkType(rateObj.marathiName)
                              }
                              className={`p-2.5 rounded-xl border-2 text-left transition cursor-pointer ${
                                active
                                  ? "bg-[#15803D] text-white border-[#15803D] shadow-xs"
                                  : "bg-[#F4F7F4] text-[#0F291E] border-[#D1E2D4] hover:border-[#15803D]"
                              }`}
                            >
                              <div className="font-extrabold text-xs sm:text-sm truncate">
                                {rateObj.marathiName}
                              </div>
                              <div
                                className={`text-xs font-bold font-tabular mt-0.5 ${
                                  active ? "text-emerald-100" : "text-[#15803D]"
                                }`}
                              >
                                {formatINR(rateObj.ratePerAcre)} / एकर
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Area (Acres + Gunthas) & Rate per Acre Inputs */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-[#0F291E] mb-1">
                          पूर्ण एकर (Acres)
                        </label>
                        <input
                          type="number"
                          min={0}
                          step="1"
                          value={workWholeAcresInput}
                          onChange={(e) =>
                            setWorkWholeAcresInput(
                              Math.max(0, Number(e.target.value))
                            )
                          }
                          className="w-full min-h-[50px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3 py-2 font-extrabold font-tabular text-base text-[#0F291E]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-[#0F291E] mb-1">
                          गुंठे (० ते ३९ गुंठे)
                        </label>
                        <input
                          type="number"
                          min={0}
                          max={39.9}
                          step="0.5"
                          value={workGunthasInput}
                          onChange={(e) =>
                            setWorkGunthasInput(
                              Math.max(0, Number(e.target.value))
                            )
                          }
                          className="w-full min-h-[50px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3 py-2 font-extrabold font-tabular text-base text-[#0F291E]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-[#0F291E] mb-1">
                          दर प्रति एकर (₹/Acre)
                        </label>
                        <input
                          type="number"
                          min={1}
                          step="50"
                          value={workRatePerAcreInput}
                          onChange={(e) =>
                            setWorkRatePerAcreInput(
                              Math.max(0, Number(e.target.value))
                            )
                          }
                          className="w-full min-h-[50px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3 py-2 font-extrabold font-tabular text-base text-[#15803D]"
                        />
                      </div>
                    </div>

                    {/* Automatic Total Calculation Banner */}
                    <div className="bg-gradient-to-r from-[#14532D] to-[#15803D] text-white rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <div className="text-xs font-bold text-emerald-200">
                          स्वयंचलित बिल गणना (Total = Acres × Rate per Acre):
                        </div>
                        <div className="text-sm font-extrabold mt-0.5 font-tabular">
                          {computedWorkDecimalAcres.toFixed(2)} एकर ×{" "}
                          {formatINR(workRatePerAcreInput)} प्रति एकर
                        </div>
                      </div>
                      <div className="text-2xl sm:text-3xl font-extrabold font-tabular">
                        = {formatINR(computedWorkTotalAmount)}
                      </div>
                    </div>

                    {/* Optional Immediate Advance & Notes */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-[#0F291E] mb-1">
                          कामाच्या वेळी मिळालेला अॅडव्हान्स (₹ - ऐच्छिक)
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="number"
                            min={0}
                            value={workAdvanceInput || ""}
                            onChange={(e) =>
                              setWorkAdvanceInput(
                                Math.max(0, Number(e.target.value))
                              )
                            }
                            placeholder="उदा. 1000"
                            className="w-full min-h-[48px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3 py-2 font-bold font-tabular text-[#0F291E]"
                          />
                          <select
                            value={workAdvanceMode}
                            onChange={(e) => setWorkAdvanceMode(e.target.value)}
                            className="rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-2.5 font-bold text-xs text-[#0F291E]"
                          >
                            <option value="CASH">रोख</option>
                            <option value="UPI">UPI</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-[#0F291E] mb-1">
                          कामाचा तपशील / टीप (Notes)
                        </label>
                        <input
                          type="text"
                          value={workNotesInput}
                          onChange={(e) => setWorkNotesInput(e.target.value)}
                          placeholder="उदा. दोन फाळी पलटी नांगर"
                          className="w-full min-h-[48px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3 py-2 font-semibold text-sm text-[#0F291E]"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full min-h-[58px] rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-extrabold text-base shadow-md flex items-center justify-center gap-2 cursor-pointer transition"
                    >
                      <CheckCircle2 className="w-5 h-5" />
                      <span>
                        ट्रॅक्टर काम सेव्ह करा ({formatINR(computedWorkTotalAmount)})
                      </span>
                    </button>
                  </form>

                  {/* Form 2: Record Advance / Partial / Final Payment (पेमेंट जमा नोंद) */}
                  <form
                    onSubmit={handleAddPayment}
                    className="lg:col-span-5 bg-white rounded-2xl border-2 border-[#D1E2D4] p-5 sm:p-6 shadow-sm space-y-4 flex flex-col justify-between"
                  >
                    <div className="space-y-4">
                      <div className="border-b border-[#D1E2D4] pb-3">
                        <h2 className="text-lg sm:text-xl font-extrabold text-[#0F291E]">
                          💰 २. पेमेंट वसुली नोंदवा (Record Payment)
                        </h2>
                        <p className="text-xs font-semibold text-[#335441]">
                          अॅडव्हान्स, अंशतः हप्ता किंवा पूर्ण बिल जमा करा आणि पावती बनवा
                        </p>
                      </div>

                      <div>
                        <label className="block text-sm font-bold text-[#0F291E] mb-1">
                          शेतकरी निवडा (Select Farmer) *
                        </label>
                        <select
                          value={paymentFarmerId}
                          onChange={(e) =>
                            setPaymentFarmerId(Number(e.target.value))
                          }
                          className="w-full min-h-[52px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-bold text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                        >
                          {farmerLedgers.map((l) => (
                            <option key={l.farmer.id} value={l.farmer.id}>
                              {l.farmer.name} — बाकी:{" "}
                              {formatINR(l.summary.balanceAmount)} (
                              {l.summary.marathiStatus})
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Selected Farmer Live Balance Box */}
                      {(() => {
                        const selectedLedger = farmerLedgers.find(
                          (l) => l.farmer.id === paymentFarmerId
                        );
                        if (!selectedLedger) return null;
                        return (
                          <div className="bg-[#F4F7F4] rounded-xl p-3.5 border-2 border-[#D1E2D4] grid grid-cols-3 gap-2 text-center">
                            <div>
                              <span className="text-[11px] font-bold text-[#335441] block">
                                एकूण बिल
                              </span>
                              <span className="text-sm sm:text-base font-extrabold text-[#0F291E] font-tabular">
                                {formatINR(selectedLedger.summary.totalBilled)}
                              </span>
                            </div>
                            <div>
                              <span className="text-[11px] font-bold text-[#15803D] block">
                                आजवर जमा
                              </span>
                              <span className="text-sm sm:text-base font-extrabold text-[#15803D] font-tabular">
                                {formatINR(
                                  selectedLedger.summary.totalReceived
                                )}
                              </span>
                            </div>
                            <div>
                              <span className="text-[11px] font-bold text-[#DC2626] block">
                                येणे बाकी
                              </span>
                              <span className="text-sm sm:text-base font-extrabold text-[#DC2626] font-tabular">
                                {formatINR(
                                  selectedLedger.summary.balanceAmount
                                )}
                              </span>
                            </div>
                          </div>
                        );
                      })()}

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-sm font-bold text-[#0F291E] mb-1">
                            जमा रक्कम (₹ Amount) *
                          </label>
                          <input
                            type="number"
                            required
                            min={1}
                            value={paymentAmountInput}
                            onChange={(e) =>
                              setPaymentAmountInput(e.target.value)
                            }
                            placeholder="उदा. 2500"
                            className="w-full min-h-[52px] rounded-xl border-2 border-[#15803D] bg-[#F4F7F4] px-3.5 py-2 font-extrabold font-tabular text-lg text-[#15803D] focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-bold text-[#0F291E] mb-1">
                            जमा तारीख (Date) *
                          </label>
                          <input
                            type="date"
                            required
                            value={paymentDateInput}
                            onChange={(e) =>
                              setPaymentDateInput(e.target.value)
                            }
                            className="w-full min-h-[52px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-bold font-tabular text-[#0F291E]"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-bold text-[#0F291E] mb-1">
                            पेमेंट प्रकार (Type)
                          </label>
                          <select
                            value={paymentTypeInput}
                            onChange={(e) =>
                              setPaymentTypeInput(e.target.value)
                            }
                            className="w-full min-h-[48px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3 py-2 font-bold text-sm text-[#0F291E]"
                          >
                            <option value="ADVANCE">
                              अॅडव्हान्स पेमेंट (Advance)
                            </option>
                            <option value="PARTIAL">
                              अंशतः हप्ता (Partial Payment)
                            </option>
                            <option value="FINAL">
                              पूर्ण बिल चुकते (Final Settlement)
                            </option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-[#0F291E] mb-1">
                            पेमेंट माध्यम (Mode)
                          </label>
                          <select
                            value={paymentModeInput}
                            onChange={(e) =>
                              setPaymentModeInput(e.target.value)
                            }
                            className="w-full min-h-[48px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3 py-2 font-bold text-sm text-[#0F291E]"
                          >
                            <option value="CASH">रोख रक्कम (Cash)</option>
                            <option value="UPI">
                              PhonePe / Google Pay (UPI)
                            </option>
                            <option value="BANK">बँक ट्रान्सफर (Bank)</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-[#0F291E] mb-1">
                          पेमेंट टीप (Notes)
                        </label>
                        <input
                          type="text"
                          value={paymentNotesInput}
                          onChange={(e) => setPaymentNotesInput(e.target.value)}
                          placeholder="उदा. शेतावर रोख हप्ता मिळाला"
                          className="w-full min-h-[48px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-semibold text-sm text-[#0F291E]"
                        />
                      </div>
                    </div>

                    <div className="pt-3 space-y-2.5">
                      <button
                        type="submit"
                        className="w-full min-h-[58px] rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white font-extrabold text-base shadow-md flex items-center justify-center gap-2 cursor-pointer transition"
                      >
                        <IndianRupee className="w-5 h-5" />
                        <span>पेमेंट जमा करा व पावती बनवा</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setBillModalFarmerId(paymentFarmerId)}
                        className="w-full min-h-[48px] rounded-xl bg-[#F4F7F4] hover:bg-emerald-50 text-[#15803D] border-2 border-[#15803D] font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Share2 className="w-4 h-4" />
                        <span>
                          निवडलेल्या शेतकऱ्याचे PDF बिल / WhatsApp पावती उघडा
                        </span>
                      </button>
                    </div>
                  </form>
                </div>

                {/* Bottom Section: Complete Farmer Payment Ledgers & Work History */}
                <div className="bg-white rounded-2xl border-2 border-[#D1E2D4] p-5 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#D1E2D4] pb-3">
                    <div>
                      <h3 className="text-lg font-extrabold text-[#0F291E]">
                        📒 शेतकरी निहाय पेमेंट हिस्ट्री व काम खातेवही (Payment & Work Ledger)
                      </h3>
                      <p className="text-xs font-semibold text-[#335441]">
                        पूर्ण जमा (Paid), अंशतः बाकी (Partial) आणि पूर्ण बाकी (Unpaid) स्थितीनुसार फिल्टर करा
                      </p>
                    </div>

                    {/* Status Filter Pills */}
                    <div className="flex flex-wrap items-center gap-1.5">
                      {[
                        { id: "ALL", label: "सर्व खाती" },
                        { id: "UNPAID", label: "पूर्ण बाकी (Unpaid)" },
                        { id: "PARTIAL", label: "अंशतः बाकी (Partial)" },
                        { id: "PAID", label: "पूर्ण जमा (Paid)" },
                      ].map((tab) => (
                        <button
                          key={tab.id}
                          type="button"
                          onClick={() =>
                            setLedgerStatusFilter(
                              tab.id as "ALL" | "UNPAID" | "PARTIAL" | "PAID"
                            )
                          }
                          className={`px-3 py-1.5 rounded-xl text-xs font-extrabold cursor-pointer transition ${
                            ledgerStatusFilter === tab.id
                              ? "bg-[#15803D] text-white"
                              : "bg-[#F4F7F4] text-[#0F291E] border border-[#D1E2D4]"
                          }`}
                        >
                          {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    {filteredFarmerLedgers.map((l) => (
                      <div
                        key={l.farmer.id}
                        className="rounded-2xl border-2 border-[#D1E2D4] bg-[#F4F7F4]/50 p-4 space-y-3"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-base sm:text-lg font-extrabold text-[#0F291E]">
                                {l.farmer.name}
                              </span>
                              <span
                                className={`px-2.5 py-0.5 rounded-full text-xs font-extrabold ${
                                  l.summary.status === "PAID"
                                    ? "bg-emerald-100 text-[#15803D]"
                                    : l.summary.status === "PARTIAL"
                                    ? "bg-amber-100 text-[#B45309]"
                                    : "bg-red-100 text-[#DC2626]"
                                }`}
                              >
                                {l.summary.marathiStatus}
                              </span>
                            </div>
                            <div className="text-xs font-bold text-[#335441]">
                              गाव: {l.farmer.village} • मो.: {l.farmer.mobile} •
                              एकूण क्षेत्र: {l.totalAcres.toFixed(2)} एकर
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center gap-3">
                            <div className="text-right font-tabular">
                              <div className="text-xs font-bold text-[#335441]">
                                एकूण: {formatINR(l.summary.totalBilled)} | जमा:{" "}
                                <span className="text-[#15803D]">
                                  {formatINR(l.summary.totalReceived)}
                                </span>
                              </div>
                              <div className="text-sm sm:text-base font-extrabold text-[#DC2626]">
                                येणे बाकी: {formatINR(l.summary.balanceAmount)}
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => setBillModalFarmerId(l.farmer.id)}
                              className="min-h-[44px] px-4 py-2 rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer shadow-xs"
                            >
                              <FileText className="w-4 h-4" />
                              <span>PDF बिल व WhatsApp पावती</span>
                            </button>
                          </div>
                        </div>

                        {/* Sub-grid: Work History & Payment History for this Farmer */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-[#D1E2D4]">
                          {/* Works */}
                          <div className="bg-white rounded-xl p-3 border border-[#D1E2D4]">
                            <div className="text-xs font-extrabold text-[#0F291E] mb-2">
                              🚜 कामाचा इतिहास ({l.works.length})
                            </div>
                            <div className="space-y-1.5 max-h-40 overflow-y-auto">
                              {l.works.map((w) => (
                                <div
                                  key={w.id}
                                  className="flex items-center justify-between text-xs border-b border-slate-100 pb-1"
                                >
                                  <div>
                                    <span className="font-bold text-[#0F291E]">
                                      {w.workType}
                                    </span>{" "}
                                    <span className="text-[#335441]">
                                      ({w.workDate} • {w.acres.toFixed(2)} एकर)
                                    </span>
                                  </div>
                                  <span className="font-extrabold font-tabular text-[#0F291E]">
                                    {formatINR(w.totalAmount)}
                                  </span>
                                </div>
                              ))}
                              {l.works.length === 0 && (
                                <div className="text-xs text-[#335441]">
                                  कामाची नोंद नाही.
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Payments */}
                          <div className="bg-white rounded-xl p-3 border border-[#D1E2D4]">
                            <div className="text-xs font-extrabold text-[#15803D] mb-2">
                              💰 पेमेंट पावती इतिहास ({l.payments.length})
                            </div>
                            <div className="space-y-1.5 max-h-40 overflow-y-auto">
                              {l.payments.map((p) => (
                                <div
                                  key={p.id}
                                  className="flex items-center justify-between text-xs border-b border-slate-100 pb-1"
                                >
                                  <div>
                                    <span className="font-mono-code font-bold text-[#0F291E]">
                                      {p.receiptNumber}
                                    </span>{" "}
                                    <span className="text-[#335441]">
                                      ({p.paymentDate} • {p.paymentMode})
                                    </span>
                                  </div>
                                  <span className="font-extrabold font-tabular text-[#15803D]">
                                    +{formatINR(p.amount)}
                                  </span>
                                </div>
                              ))}
                              {l.payments.length === 0 && (
                                <div className="text-xs text-[#335441]">
                                  कोणतेही पेमेंट जमा नाही.
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* MOBILE / FIELD BOTTOM NAVIGATION BAR */}
      <nav className="no-print lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-white border-t-2 border-[#15803D] shadow-lg grid grid-cols-4 h-16">
        <button
          type="button"
          onClick={() => setActiveTab("DASHBOARD")}
          className={`flex flex-col items-center justify-center gap-0.5 font-extrabold text-xs cursor-pointer ${
            activeTab === "DASHBOARD"
              ? "bg-emerald-50 text-[#15803D]"
              : "text-[#335441]"
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span>डॅशबोर्ड</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("SATELLITE_MAP")}
          className={`flex flex-col items-center justify-center gap-0.5 font-extrabold text-xs cursor-pointer ${
            activeTab === "SATELLITE_MAP"
              ? "bg-emerald-50 text-[#15803D]"
              : "text-[#335441]"
          }`}
        >
          <Map className="w-5 h-5" />
          <span>शेत मोजणी</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("FARMERS")}
          className={`flex flex-col items-center justify-center gap-0.5 font-extrabold text-xs cursor-pointer ${
            activeTab === "FARMERS"
              ? "bg-emerald-50 text-[#15803D]"
              : "text-[#335441]"
          }`}
        >
          <Users className="w-5 h-5" />
          <span>शेतकरी</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab("WORK_AND_PAYMENTS")}
          className={`flex flex-col items-center justify-center gap-0.5 font-extrabold text-xs cursor-pointer ${
            activeTab === "WORK_AND_PAYMENTS"
              ? "bg-emerald-50 text-[#15803D]"
              : "text-[#335441]"
          }`}
        >
          <Tractor className="w-5 h-5" />
          <span>काम व बिल</span>
        </button>
      </nav>

      {/* MARATHI PDF BILL & WHATSAPP RECEIPT MODAL */}
      {billModalFarmer && (
        <BillReceiptModal
          farmer={billModalFarmer}
          fields={fields}
          workRecords={workRecords}
          payments={payments}
          ownerName={settings.ownerName}
          ownerMobile={settings.ownerMobile}
          tractorModel={settings.tractorModel}
          onClose={() => setBillModalFarmerId(null)}
        />
      )}

      {/* NATIVE ANDROID KOTLIN + JETPACK COMPOSE STUDIO & UNIT TESTS MODAL */}
      {showKotlinStudioModal && (
        <AndroidKotlinStudioModal
          onClose={() => setShowKotlinStudioModal(false)}
        />
      )}

      {/* SECURITY (PIN LOCK), FIREBASE BACKUP & WORK RATES MODAL */}
      {showSettingsModal && (
        <SecurityAndSettingsModal
          pinCode={settings.pinCode}
          pinEnabled={settings.pinEnabled}
          ownerName={settings.ownerName}
          ownerMobile={settings.ownerMobile}
          tractorModel={settings.tractorModel}
          rates={activeWorkRates}
          lastBackupAt={settings.lastBackupAt}
          googleMapsApiKey={settings.googleMapsApiKey ?? ""}
          mapsKeyFromEnv={mapsKeyFromEnv}
          onSaveSettings={async (payload) => {
            const res = await fetch("/api/tractor", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                action: "UPDATE_SETTINGS",
                ...payload,
              }),
            });
            const data = await res.json();
            if (data.ok) {
              // The Maps script cannot switch keys in place, so reload when the key changes.
              const keyChanged =
                !mapsKeyFromEnv &&
                (payload.googleMapsApiKey ?? "").trim() !==
                  (settings.googleMapsApiKey ?? "").trim();
              await fetchAllData();
              if (keyChanged) window.location.reload();
              showToast("सेटिंग्ज, कामाचे दर आणि पिन कोड सेव्ह झाले!");
            }
          }}
          onTriggerFirebaseSync={async () => {
            await fetch("/api/tractor", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ action: "SYNC_FIREBASE_BACKUP" }),
            });
            await fetchAllData();
          }}
          onExportJsonBackup={handleExportJsonBackup}
          onRestoreJsonBackup={async (jsonData) => {
            const res = await fetch("/api/tractor", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                action: "RESTORE_BACKUP",
                backupData: jsonData,
              }),
            });
            const data = await res.json();
            if (data.ok) {
              await fetchAllData();
              showToast(data.message || "बॅकअप रिस्टोर पूर्ण झाले!");
            } else {
              throw new Error("restore failed");
            }
          }}
          onLockNow={() => {
            setShowSettingsModal(false);
            setIsPinLocked(true);
          }}
          onClose={() => setShowSettingsModal(false)}
        />
      )}
    </div>
  );
}
