"use client";

import React, { useState } from "react";
import {
   computePaymentSummary,
  formatINR,
  formatMarathiAreaBreakdown,
} from "@/lib/agri-math";
import {
  X,
  Printer,
  Share2,
  Copy,
  CheckCircle2,
  FileText,
  Phone,
  MapPin,
} from "lucide-react";
import type { FarmerItem, FieldItem } from "./SatelliteMapMeasurer";

export interface WorkRecordItem {
  id: number;
  farmerId: number;
  fieldId: number | null;
  workType: string;
  workDate: string;
  acres: number;
  gunthas: number;
  ratePerAcre: number;
  totalAmount: number;
  notes: string | null;
}

export interface PaymentItem {
  id: number;
  farmerId: number;
  workRecordId: number | null;
  amount: number;
  paymentType: string;
  paymentMode: string;
  paymentDate: string;
  receiptNumber: string;
  notes: string | null;
}

interface BillReceiptModalProps {
  farmer: FarmerItem;
  fields: FieldItem[];
  workRecords: WorkRecordItem[];
  payments: PaymentItem[];
  ownerName: string;
  ownerMobile: string;
  tractorModel: string;
  onClose: () => void;
}

export default function BillReceiptModal({
  farmer,
  fields,
  workRecords,
  payments,
  ownerName,
  ownerMobile,
  tractorModel,
  onClose,
}: BillReceiptModalProps) {
  const [copiedMsg, setCopiedMsg] = useState(false);

  const farmerWorks = workRecords.filter((w) => w.farmerId === farmer.id);
  const farmerPayments = payments.filter((p) => p.farmerId === farmer.id);

  const totalBilled = farmerWorks.reduce((s, w) => s + w.totalAmount, 0);
  const totalReceived = farmerPayments.reduce((s, p) => s + p.amount, 0);
  const totalAcres = farmerWorks.reduce((s, w) => s + w.acres, 0);

  const summary = computePaymentSummary(totalBilled, totalReceived);

  // Build Marathi WhatsApp Bill Message
  const whatsappText = [
    `🚜 *${ownerName}*`,
    `गाडी क्र.: ${tractorModel} | मो.: ${ownerMobile}`,
    `--------------------------------`,
    `📄 *ट्रॅक्टर शेतकाम बिल व पावती*`,
    `👤 *शेतकरी:* ${farmer.name}`,
    `📍 *गाव:* ${farmer.village} | *मो.:* ${farmer.mobile}`,
    `--------------------------------`,
    `*कामाचा तपशील:*`,
    ...(farmerWorks.length > 0
      ? farmerWorks.map(
          (w, i) =>
            `${i + 1}) ${w.workDate} - *${w.workType}*\n   क्षेत्र: ${w.acres.toFixed(
              2
            )} एकर (${w.gunthas.toFixed(0)} गुंठे) × दर ${formatINR(
              w.ratePerAcre
            )} = *${formatINR(w.totalAmount)}*`
        )
      : ["कोणतेही काम नोंदवलेले नाही."]),
    `--------------------------------`,
    `🌾 *एकूण क्षेत्रफळ:* ${totalAcres.toFixed(2)} एकर (${formatMarathiAreaBreakdown(
      totalAcres
    )})`,
    `💰 *एकूण बिल रक्कम:* ${formatINR(summary.totalBilled)}`,
    `✅ *जमा रक्कम (Paid):* ${formatINR(summary.totalReceived)}`,
    `🔔 *येणे बाकी (Balance):* *${formatINR(summary.balanceAmount)}*`,
    `📌 *स्थिती:* ${summary.marathiStatus}`,
    `--------------------------------`,
    `धन्यवाद! ट्रॅक्टर मॅनेजर मराठी ॲप द्वारे जनरेट केलेले अधिकृत बिल.`,
  ].join("\n");

  const handleShareWhatsApp = () => {
    const cleanPhone = farmer.mobile.replace(/\D/g, "");
    const phoneWithCountry =
      cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    const url = `https://wa.me/${phoneWithCountry}?text=${encodeURIComponent(
      whatsappText
    )}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const handleCopyWhatsAppText = async () => {
    try {
      await navigator.clipboard.writeText(whatsappText);
      setCopiedMsg(true);
      setTimeout(() => setCopiedMsg(false), 3000);
    } catch {
      // Fallback
    }
  };

  const handlePrintOrDownloadPdf = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-3xl border-2 border-[#15803D] max-w-3xl w-full overflow-hidden shadow-2xl my-auto">
        {/* Top Action Bar (Hidden in Print) */}
        <div className="no-print bg-[#0F291E] text-white px-5 py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <FileText className="w-6 h-6 text-[#22C55E]" />
            <div>
              <h2 className="text-lg font-extrabold">
                मराठी PDF बिल व पावती (Invoice & Receipt)
              </h2>
              <p className="text-xs text-emerald-200">
                प्रिंट करा, PDF सेव्ह करा किंवा थेट WhatsApp वर पाठवा
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/15 hover:bg-white/25 text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Marathi Invoice Body */}
        <div className="p-5 sm:p-8 space-y-6 max-h-[75vh] overflow-y-auto print:max-h-none">
          {/* Header Banner */}
          <div className="border-b-2 border-[#15803D] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="inline-block bg-[#15803D] text-white text-xs font-extrabold px-3 py-1 rounded-full mb-1.5">
                अधिकृत ट्रॅक्टर मशागत बिल / पावती
              </div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-[#0F291E]">
                {ownerName}
              </h1>
              <p className="text-sm font-bold text-[#335441] mt-0.5">
                ट्रॅक्टर क्र.: {tractorModel} | संपर्क मो.: +91 {ownerMobile}
              </p>
            </div>

            <div className="bg-[#F4F7F4] border-2 border-[#D1E2D4] rounded-xl p-3 text-left sm:text-right">
              <div className="text-xs font-bold text-[#335441]">
                बिल दिनांक (Date)
              </div>
              <div className="text-base font-extrabold text-[#0F291E] font-tabular">
                {new Date().toISOString().slice(0, 10)}
              </div>
              <div className="text-xs font-bold text-[#15803D] mt-0.5">
                खाते क्र.: TM-KHATA-{farmer.id}
              </div>
            </div>
          </div>

          {/* Farmer Details Box */}
          <div className="bg-[#F4F7F4] rounded-2xl p-4 border-2 border-[#D1E2D4] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-xs font-bold text-[#335441]">
                शेतकऱ्याचे नाव (Farmer Name):
              </div>
              <div className="text-lg sm:text-xl font-extrabold text-[#0F291E]">
                {farmer.name}
              </div>
              <div className="flex flex-wrap items-center gap-4 mt-1 text-xs sm:text-sm font-bold text-[#335441]">
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4 text-[#15803D]" />
                  {farmer.village}
                </span>
                <span className="flex items-center gap-1">
                  <Phone className="w-4 h-4 text-[#15803D]" />
                  +91 {farmer.mobile}
                </span>
              </div>
            </div>

            <div className="flex flex-col items-start sm:items-end">
              <span className="text-xs font-bold text-[#335441]">
                पेमेंट स्थिती (Status):
              </span>
              <span
                className={`mt-1 px-3.5 py-1.5 rounded-xl text-sm font-extrabold ${
                  summary.status === "PAID"
                    ? "bg-emerald-100 text-[#15803D] border border-[#16A34A]"
                    : summary.status === "PARTIAL"
                    ? "bg-amber-100 text-[#B45309] border border-amber-400"
                    : "bg-red-100 text-[#DC2626] border border-red-300"
                }`}
              >
                {summary.marathiStatus}
              </span>
            </div>
          </div>

          {/* Work Records Table */}
          <div>
            <h3 className="text-base font-extrabold text-[#0F291E] mb-2.5">
              १. ट्रॅक्टर शेतकाम तपशील (Work History)
            </h3>
            <div className="overflow-x-auto rounded-xl border-2 border-[#D1E2D4]">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-[#14532D] text-white">
                    <th className="p-3 font-bold">दिनांक</th>
                    <th className="p-3 font-bold">कामाचा प्रकार व शेत</th>
                    <th className="p-3 font-bold text-right">क्षेत्र (एकर/गुंठे)</th>
                    <th className="p-3 font-bold text-right">दर / एकर</th>
                    <th className="p-3 font-bold text-right">एकूण रक्कम (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D1E2D4]">
                  {farmerWorks.map((w) => {
                    const fItem = fields.find((fl) => fl.id === w.fieldId);
                    return (
                      <tr key={w.id} className="hover:bg-[#F4F7F4]/60">
                        <td className="p-3 font-bold font-tabular">
                          {w.workDate}
                        </td>
                        <td className="p-3">
                          <div className="font-extrabold text-[#0F291E]">
                            {w.workType}
                          </div>
                          <div className="text-xs text-[#335441] font-semibold">
                            {fItem ? fItem.fieldName : "शेत प्लॉट"}
                          </div>
                        </td>
                        <td className="p-3 text-right font-bold font-tabular">
                          {w.acres.toFixed(2)} एकर ({w.gunthas.toFixed(0)} गुंठे)
                        </td>
                        <td className="p-3 text-right font-bold font-tabular">
                          {formatINR(w.ratePerAcre)}
                        </td>
                        <td className="p-3 text-right font-extrabold text-[#0F291E] font-tabular">
                          {formatINR(w.totalAmount)}
                        </td>
                      </tr>
                    );
                  })}
                  {farmerWorks.length === 0 && (
                    <tr>
                      <td
                        colSpan={5}
                        className="p-4 text-center text-[#335441] font-semibold"
                      >
                        कोणतीही कामाची नोंद नाही.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Payment Receipts Table */}
          <div>
            <h3 className="text-base font-extrabold text-[#0F291E] mb-2.5">
              २. जमा पेमेंट पावती तपशील (Payment Receipts)
            </h3>
            <div className="overflow-x-auto rounded-xl border-2 border-[#D1E2D4]">
              <table className="w-full text-left border-collapse text-xs sm:text-sm">
                <thead>
                  <tr className="bg-[#F4F7F4] text-[#0F291E] border-b-2 border-[#D1E2D4]">
                    <th className="p-3 font-bold">पावती क्र.</th>
                    <th className="p-3 font-bold">दिनांक</th>
                    <th className="p-3 font-bold">प्रकार व माध्यम</th>
                    <th className="p-3 font-bold">तपशील</th>
                    <th className="p-3 font-bold text-right">जमा रक्कम (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D1E2D4]">
                  {farmerPayments.map((p) => (
                    <tr key={p.id}>
                      <td className="p-3 font-mono-code font-bold text-xs">
                        {p.receiptNumber}
                      </td>
                      <td className="p-3 font-bold font-tabular">
                        {p.paymentDate}
                      </td>
                      <td className="p-3 font-bold">
                        {p.paymentType === "ADVANCE"
                          ? "अॅडव्हान्स (Advance)"
                          : p.paymentType === "FINAL"
                          ? "पूर्ण जमा (Final)"
                          : "अंशतः हप्ता (Partial)"}{" "}
                        • {p.paymentMode}
                      </td>
                      <td className="p-3 text-xs font-semibold text-[#335441]">
                        {p.notes || "-"}
                      </td>
                      <td className="p-3 text-right font-extrabold text-[#15803D] font-tabular">
                        {formatINR(p.amount)}
                      </td>
                    </tr>
                  ))}
                  {farmerPayments.length === 0 && (
                    <tr>
                      <td
                        colSpan={5}
                        className="p-4 text-center text-[#335441] font-semibold"
                      >
                        अद्याप कोणतीही रक्कम जमा झालेली नाही.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Grand Total Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="bg-[#F4F7F4] rounded-2xl p-4 border-2 border-[#D1E2D4]">
              <div className="text-xs font-bold text-[#335441]">
                एकूण बिल रक्कम (Total Bill)
              </div>
              <div className="text-2xl font-extrabold text-[#0F291E] font-tabular mt-1">
                {formatINR(summary.totalBilled)}
              </div>
            </div>

            <div className="bg-emerald-50 rounded-2xl p-4 border-2 border-[#16A34A]">
              <div className="text-xs font-bold text-[#15803D]">
                एकूण मिळालेली रक्कम (Received)
              </div>
              <div className="text-2xl font-extrabold text-[#15803D] font-tabular mt-1">
                {formatINR(summary.totalReceived)}
              </div>
            </div>

            <div className="bg-amber-50 rounded-2xl p-4 border-2 border-amber-400">
              <div className="text-xs font-bold text-[#B45309]">
                निव्वळ येणे बाकी (Balance Due)
              </div>
              <div className="text-2xl font-extrabold text-[#DC2626] font-tabular mt-1">
                {formatINR(summary.balanceAmount)}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Large Action Buttons (Hidden in Print) */}
        <div className="no-print bg-[#F4F7F4] border-t-2 border-[#D1E2D4] p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handlePrintOrDownloadPdf}
            className="flex-1 min-h-[56px] px-5 py-3 rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-extrabold text-sm sm:text-base flex items-center justify-center gap-2 shadow-md cursor-pointer transition"
          >
            <Printer className="w-5 h-5" />
            <span>PDF बिल डाउनलोड / प्रिंट करा</span>
          </button>

          <button
            type="button"
            onClick={handleShareWhatsApp}
            className="flex-1 min-h-[56px] px-5 py-3 rounded-xl bg-[#16A34A] hover:bg-[#15803D] text-white font-extrabold text-sm sm:text-base flex items-center justify-center gap-2 shadow-md cursor-pointer transition"
          >
            <Share2 className="w-5 h-5" />
            <span>WhatsApp वर बिल पाठवा</span>
          </button>

          <button
            type="button"
            onClick={handleCopyWhatsAppText}
            className="min-h-[56px] px-4 py-3 rounded-xl bg-white hover:bg-emerald-50 text-[#0F291E] border-2 border-[#D1E2D4] font-bold text-sm flex items-center justify-center gap-2 cursor-pointer"
          >
            {copiedMsg ? (
              <>
                <CheckCircle2 className="w-5 h-5 text-[#16A34A]" />
                <span className="text-[#16A34A]">कॉपी झाले!</span>
              </>
            ) : (
              <>
                <Copy className="w-5 h-5 text-[#15803D]" />
                <span>मेसेज कॉपी करा</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
