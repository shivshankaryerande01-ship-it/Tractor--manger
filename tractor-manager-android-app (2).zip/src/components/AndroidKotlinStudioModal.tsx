"use client";

import React, { useState, useMemo } from "react";
import { ANDROID_KOTLIN_FILES } from "@/lib/android-kotlin-project";
import { runAgriMathTestSuite } from "@/lib/agri-math";
import {
  X,
  CheckCircle2,
  Copy,
  Download,
  Code2,
  Play,
  ShieldCheck,
} from "lucide-react";

interface AndroidKotlinStudioModalProps {
  onClose: () => void;
}

export default function AndroidKotlinStudioModal({
  onClose,
}: AndroidKotlinStudioModalProps) {
  const [activeTab, setActiveTab] = useState<"TESTS" | "KOTLIN_SOURCE">(
    "TESTS"
  );
  const [selectedFileIndex, setSelectedFileIndex] = useState<number>(0);
  const [copiedFile, setCopiedFile] = useState<boolean>(false);
  const [testRunCount, setTestRunCount] = useState<number>(1);

  const testResults = useMemo(() => {
    void testRunCount;
    return runAgriMathTestSuite();
  }, [testRunCount]);

  const allPassed = testResults.every((t) => t.passed);
  const currentFile = ANDROID_KOTLIN_FILES[selectedFileIndex];

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(currentFile.code);
      setCopiedFile(true);
      setTimeout(() => setCopiedFile(false), 2500);
    } catch {
      // ignore
    }
  };

  const handleDownloadAndroidBundle = () => {
    const bundleContent = ANDROID_KOTLIN_FILES.map(
      (f) =>
        `// ==========================================\n// FILE: ${f.path}\n// ${f.titleMarathi}\n// ==========================================\n\n${f.code}\n\n`
    ).join("\n");

    const blob = new Blob([bundleContent], {
      type: "text/plain;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "TractorManager_Android_Kotlin_JetpackCompose_Project.kt.txt";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-3xl border-2 border-[#15803D] max-w-5xl w-full overflow-hidden shadow-2xl my-auto">
        {/* Header */}
        <div className="bg-[#0F291E] text-white px-5 py-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#15803D] flex items-center justify-center">
              <Code2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold">
                Android Native (Kotlin + Jetpack Compose + Room DB) आर्किटेक्चर व युनिट टेस्ट्स
              </h2>
              <p className="text-xs text-emerald-200">
                Gradle KTS, Room Offline Entities, Spherical Polygon Area, PDF/WhatsApp आणि JUnit 4 टेस्ट सूट
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/15 hover:bg-white/25 text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub-navigation Tabs */}
        <div className="bg-[#F4F7F4] border-b-2 border-[#D1E2D4] px-5 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab("TESTS")}
              className={`px-4 py-2.5 rounded-xl font-extrabold text-sm flex items-center gap-2 cursor-pointer transition ${
                activeTab === "TESTS"
                  ? "bg-[#15803D] text-white shadow-xs"
                  : "bg-white text-[#0F291E] border border-[#D1E2D4]"
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>
                युनिट टेस्ट पडताळणी ({testResults.filter((t) => t.passed).length}/
                {testResults.length} PASSED)
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("KOTLIN_SOURCE")}
              className={`px-4 py-2.5 rounded-xl font-extrabold text-sm flex items-center gap-2 cursor-pointer transition ${
                activeTab === "KOTLIN_SOURCE"
                  ? "bg-[#15803D] text-white shadow-xs"
                  : "bg-white text-[#0F291E] border border-[#D1E2D4]"
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span>Kotlin + Jetpack Compose फाईल्स ({ANDROID_KOTLIN_FILES.length})</span>
            </button>
          </div>

          <a
            href="/app-debug.apk"
            download="app-debug.apk"
            className="px-4 py-2.5 rounded-xl bg-[#22C55E] hover:bg-emerald-400 text-[#0F291E] font-extrabold text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-md"
          >
            <Download className="w-4 h-4" />
            <span>app-debug.apk (22 MB)</span>
          </a>

          <button
            type="button"
            onClick={handleDownloadAndroidBundle}
            className="px-4 py-2.5 rounded-xl bg-[#0F291E] hover:bg-[#14532D] text-white font-bold text-xs sm:text-sm flex items-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>संपूर्ण Kotlin प्रोजेक्ट डाउनलोड करा</span>
          </button>
        </div>

        {/* Tab 1: Automated Unit Tests for Area, Billing & Payments */}
        {activeTab === "TESTS" && (
          <div className="p-5 sm:p-6 space-y-4 max-h-[70vh] overflow-y-auto">
            <div className="bg-emerald-50 border-2 border-[#16A34A] rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="text-base font-extrabold text-[#14532D] flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-[#16A34A]" />
                  <span>
                    {allPassed
                      ? `सर्व ${testResults.length} गणित टेस्ट्स यशस्वी`
                      : `${testResults.filter((t) => !t.passed).length} टेस्ट्स अयशस्वी`}
                  </span>
                </div>
                <p className="text-xs font-semibold text-[#335441] mt-0.5">
                  सॅटेलाईट बहुभुज क्षेत्रफळ (एकर/गुंठे/हेक्टर), ट्रॅक्टर दर बिलिंग आणि पेमेंट बाकी गणिताची स्वयंचलित चाचणी.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setTestRunCount((c) => c + 1)}
                className="px-4 py-2.5 rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Play className="w-4 h-4" />
                <span>टेस्ट्स पुन्हा चालवा</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {testResults.map((t) => (
                <div
                  key={t.id}
                  className="bg-[#F4F7F4] rounded-xl p-4 border-2 border-[#D1E2D4] space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-xs font-mono-code font-bold text-[#335441]">
                        {t.id} • {t.category}
                      </span>
                      <h4 className="font-extrabold text-[#0F291E] text-sm">
                        {t.nameMarathi}
                      </h4>
                      <p className="text-xs text-[#335441] font-medium">
                        {t.nameEnglish}
                      </p>
                    </div>
                    <span
                      className={`text-white text-xs font-extrabold px-2.5 py-1 rounded-lg shrink-0 ${
                        t.passed ? "bg-[#16A34A]" : "bg-[#DC2626]"
                      }`}
                    >
                      {t.passed ? "PASSED" : "FAILED"}
                    </span>
                  </div>

                  <div className="bg-white rounded-lg p-2.5 border border-[#D1E2D4] text-xs space-y-1 font-mono-code">
                    <div className="text-[#335441]">
                      <strong>अपेक्षित (Expected):</strong> {t.expected}
                    </div>
                    <div className="text-[#15803D] font-bold">
                      <strong>प्रत्यक्ष (Actual):</strong> {t.actual}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Native Android Kotlin + Jetpack Compose + Room Code Viewer */}
        {activeTab === "KOTLIN_SOURCE" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 max-h-[70vh] overflow-hidden">
            {/* File Sidebar */}
            <div className="lg:col-span-4 bg-[#F4F7F4] border-r-2 border-[#D1E2D4] p-3 space-y-2 overflow-y-auto">
              {ANDROID_KOTLIN_FILES.map((file, idx) => (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedFileIndex(idx)}
                  className={`w-full text-left p-3 rounded-xl border-2 transition cursor-pointer ${
                    selectedFileIndex === idx
                      ? "bg-[#15803D] text-white border-[#15803D]"
                      : "bg-white text-[#0F291E] border-[#D1E2D4] hover:border-[#15803D]"
                  }`}
                >
                  <div className="font-extrabold text-xs sm:text-sm">
                    {file.titleMarathi}
                  </div>
                  <div
                    className={`text-[11px] font-mono-code mt-1 truncate ${
                      selectedFileIndex === idx
                        ? "text-emerald-100"
                        : "text-[#335441]"
                    }`}
                  >
                    {file.path}
                  </div>
                </button>
              ))}
            </div>

            {/* Code Content */}
            <div className="lg:col-span-8 flex flex-col bg-[#0F291E] text-emerald-50 overflow-hidden">
              <div className="px-4 py-3 bg-black/30 border-b border-white/10 flex items-center justify-between gap-2">
                <div className="truncate">
                  <div className="text-xs font-mono-code text-emerald-300 truncate">
                    {currentFile.path}
                  </div>
                  <div className="text-xs text-white/80">
                    {currentFile.description}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="px-3 py-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-bold flex items-center gap-1.5 shrink-0 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedFile ? "कॉपी झाले!" : "कोड कॉपी करा"}</span>
                </button>
              </div>

              <pre className="p-4 text-xs font-mono-code overflow-auto flex-1 leading-relaxed">
                <code>{currentFile.code}</code>
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
