"use client";

import React, { useState } from "react";
import type { WorkTypeRate } from "@/db/schema";
import { formatINR } from "@/lib/agri-math";
import {
  Lock,
  Unlock,
  CloudUpload,
  Download,
  Upload,
  CheckCircle2,
  X,
  Settings,
  Delete,
  ShieldAlert,
} from "lucide-react";

interface PinLockScreenOverlayProps {
  expectedPin: string;
  ownerName: string;
  onUnlockSuccess: () => void;
}

export function PinLockScreenOverlay({
  expectedPin,
  ownerName,
  onUnlockSuccess,
}: PinLockScreenOverlayProps) {
  const [enteredPin, setEnteredPin] = useState<string>("");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleDigitPress = (digit: string) => {
    setErrorMsg(null);
    if (enteredPin.length >= 4) return;
    const nextPin = enteredPin + digit;
    setEnteredPin(nextPin);

    if (nextPin.length === 4) {
      if (nextPin === (expectedPin || "1234")) {
        onUnlockSuccess();
      } else {
        setErrorMsg("चुकीचा पिन कोड! कृपया पुन्हा प्रयत्न करा.");
        setTimeout(() => setEnteredPin(""), 500);
      }
    }
  };

  const handleBackspace = () => {
    setErrorMsg(null);
    setEnteredPin((prev) => prev.slice(0, -1));
  };

  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-b from-[#0F291E] via-[#14532D] to-[#0F291E] text-white flex flex-col items-center justify-center p-4 select-none">
      <div className="max-w-sm w-full bg-white text-[#0F291E] rounded-3xl p-6 sm:p-8 shadow-2xl border-4 border-[#22C55E] text-center space-y-5">
        <div className="w-16 h-16 rounded-2xl bg-[#15803D] text-white flex items-center justify-center mx-auto shadow-md">
          <Lock className="w-8 h-8" />
        </div>

        <div>
          <h1 className="text-2xl font-extrabold text-[#0F291E]">
            ट्रॅक्टर मॅनेजर पिन लॉक
          </h1>
          <p className="text-xs sm:text-sm font-bold text-[#335441] mt-1">
            {ownerName}
          </p>
          <p className="text-xs font-semibold text-[#15803D] mt-1">
            सुरक्षित प्रवेशासाठी ४-अंकी पिन टाका
          </p>
        </div>

        {/* 4 PIN Indicator Dots */}
        <div className="flex items-center justify-center gap-4 py-2">
          {[0, 1, 2, 3].map((idx) => {
            const filled = enteredPin.length > idx;
            return (
              <div
                key={idx}
                className={`w-5 h-5 rounded-full border-2 transition-all ${
                  filled
                    ? "bg-[#15803D] border-[#15803D] scale-110"
                    : "bg-[#F4F7F4] border-[#335441]"
                }`}
              />
            );
          })}
        </div>

        {errorMsg && (
          <div className="bg-red-50 border border-red-300 text-[#DC2626] text-xs font-extrabold px-3 py-2 rounded-xl flex items-center justify-center gap-1.5">
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Large Touch Numeric Keypad */}
        <div className="grid grid-cols-3 gap-3 pt-1">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleDigitPress(digit)}
              className="h-16 rounded-2xl bg-[#F4F7F4] hover:bg-emerald-100 active:bg-[#15803D] active:text-white border-2 border-[#D1E2D4] text-2xl font-extrabold text-[#0F291E] font-tabular shadow-xs cursor-pointer transition"
            >
              {digit}
            </button>
          ))}

          <button
            type="button"
            onClick={() => setEnteredPin("")}
            className="h-16 rounded-2xl bg-amber-50 hover:bg-amber-100 border-2 border-amber-200 text-xs font-extrabold text-[#B45309] cursor-pointer"
          >
            साफ करा
          </button>

          <button
            type="button"
            onClick={() => handleDigitPress("0")}
            className="h-16 rounded-2xl bg-[#F4F7F4] hover:bg-emerald-100 active:bg-[#15803D] active:text-white border-2 border-[#D1E2D4] text-2xl font-extrabold text-[#0F291E] font-tabular shadow-xs cursor-pointer transition"
          >
            0
          </button>

          <button
            type="button"
            onClick={handleBackspace}
            className="h-16 rounded-2xl bg-red-50 hover:bg-red-100 border-2 border-red-200 text-[#DC2626] flex items-center justify-center cursor-pointer"
          >
            <Delete className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
}

interface SecurityAndSettingsModalProps {
  pinCode: string;
  pinEnabled: boolean;
  ownerName: string;
  ownerMobile: string;
  tractorModel: string;
  rates: WorkTypeRate[];
  lastBackupAt: string;
  googleMapsApiKey: string;
  mapsKeyFromEnv: boolean;
  onSaveSettings: (payload: {
    pinCode: string;
    pinEnabled: boolean;
    ownerName: string;
    ownerMobile: string;
    tractorModel: string;
    ratesJson: WorkTypeRate[];
    googleMapsApiKey: string;
  }) => Promise<void>;
  onTriggerFirebaseSync: () => Promise<void>;
  onExportJsonBackup: () => void;
  onRestoreJsonBackup: (jsonData: unknown) => Promise<void>;
  onLockNow: () => void;
  onClose: () => void;
}

export function SecurityAndSettingsModal({
  pinCode,
  pinEnabled,
  ownerName,
  ownerMobile,
  tractorModel,
  rates,
  lastBackupAt,
  googleMapsApiKey,
  mapsKeyFromEnv,
  onSaveSettings,
  onTriggerFirebaseSync,
  onExportJsonBackup,
  onRestoreJsonBackup,
  onLockNow,
  onClose,
}: SecurityAndSettingsModalProps) {
  const [newPin, setNewPin] = useState(pinCode || "1234");
  const [enablePin, setEnablePin] = useState(pinEnabled);
  const [owner, setOwner] = useState(ownerName);
  const [mobile, setMobile] = useState(ownerMobile);
  const [tractor, setTractor] = useState(tractorModel);
  const [editableRates, setEditableRates] = useState<WorkTypeRate[]>(rates);
  const [mapsKey, setMapsKey] = useState(googleMapsApiKey);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const handleRateChange = (id: string, newRate: number) => {
    setEditableRates((prev) =>
      prev.map((r) =>
        r.id === id ? { ...r, ratePerAcre: Math.max(0, newRate) } : r
      )
    );
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\d{4}$/.test(newPin)) {
      setStatusMessage("पिन कोड बरोबर ४ अंकी असणे आवश्यक आहे (उदा. 1234).");
      return;
    }
    setSaving(true);
    try {
      await onSaveSettings({
        pinCode: newPin,
        pinEnabled: enablePin,
        ownerName: owner,
        ownerMobile: mobile,
        tractorModel: tractor,
        ratesJson: editableRates,
        googleMapsApiKey: mapsKey.trim(),
      });
      setStatusMessage("सर्व सेटिंग्ज, कामाचे दर आणि पिन कोड यशस्वीरीत्या जतन झाले!");
    } finally {
      setSaving(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      await onRestoreJsonBackup(parsed);
      setStatusMessage("बॅकअप फाईल यशस्वीरीत्या रिस्टोर केली (डुप्लिकेट रेकॉर्ड वगळले)!");
    } catch {
      setStatusMessage("बॅकअप फाईल वाचताना त्रुटी आली. कृपया वैध JSON फाईल निवडा.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-3xl border-2 border-[#15803D] max-w-4xl w-full overflow-hidden shadow-2xl my-auto">
        {/* Header */}
        <div className="bg-[#0F291E] text-white px-5 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Settings className="w-6 h-6 text-[#22C55E]" />
            <div>
              <h2 className="text-lg font-extrabold">
                सेटिंग्ज: Google Maps, पिन लॉक, बॅकअप आणि कामाचे दर
              </h2>
              <p className="text-xs text-emerald-200">
                सर्व माहिती या ॲपच्या डेटाबेसमध्ये सेव्ह होते
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/15 hover:bg-white/25 text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6 max-h-[78vh] overflow-y-auto">
          {statusMessage && (
            <div className="bg-emerald-50 border-2 border-[#16A34A] text-[#14532D] px-4 py-3 rounded-xl text-sm font-extrabold flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-[#16A34A] shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {/* Google Maps API key */}
          <div className="bg-white rounded-2xl p-4 sm:p-5 border-2 border-[#D1E2D4] space-y-3">
            <h3 className="text-base font-extrabold text-[#0F291E]">
              Google Maps API key
            </h3>
            {mapsKeyFromEnv ? (
              <p className="text-sm font-semibold text-[#15803D]">
                Google Maps API key सर्व्हरवर सेट केलेली आहे. ती येथे बदलता येत नाही.
              </p>
            ) : (
              <>
                <input
                  type="text"
                  value={mapsKey}
                  onChange={(e) => setMapsKey(e.target.value)}
                  placeholder="AIza..."
                  autoComplete="off"
                  spellCheck={false}
                  className="w-full min-h-[48px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-mono-code text-sm text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                />
                <p className="text-xs font-semibold text-[#335441]">
                  Google Cloud Console मध्ये Maps JavaScript API आणि Geocoding API
                  चालू करून key तयार करा. key रिकामी ठेवल्यास Esri सॅटेलाईट नकाशा
                  वापरला जाईल. key टाकून खालील सेव्ह बटण दाबा.
                </p>
              </>
            )}
          </div>

          {/* Backup, restore and quick lock */}
          <div className="bg-[#F4F7F4] rounded-2xl p-4 sm:p-5 border-2 border-[#D1E2D4] space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-extrabold text-[#0F291E]">
                  बॅकअप आणि रिस्टोर
                </h3>
                <p className="text-xs font-semibold text-[#335441]">
                  बॅकअप फाईल डाउनलोड करून सुरक्षित ठिकाणी ठेवा. या वेब ॲपमध्ये
                  क्लाउड बॅकअप नाही.
                </p>
              </div>
              <button
                type="button"
                onClick={onLockNow}
                className="px-4 py-2.5 rounded-xl bg-[#DC2626] hover:bg-red-700 text-white font-extrabold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Lock className="w-4 h-4" />
                <span>आता पिन लॉक करा</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  onExportJsonBackup();
                  setStatusMessage(
                    "संपूर्ण डेटा बॅकअप (.json) फाईल डाउनलोड झाली!"
                  );
                }}
                className="min-h-[54px] px-4 py-3 rounded-xl bg-white hover:bg-emerald-50 text-[#0F291E] border-2 border-[#15803D] font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-5 h-5 text-[#15803D]" />
                <span>ऑफलाईन बॅकअप डाउनलोड</span>
              </button>

              <label className="min-h-[54px] px-4 py-3 rounded-xl bg-white hover:bg-sky-50 text-[#0284C7] border-2 border-[#0284C7] font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer">
                <Upload className="w-5 h-5" />
                <span>बॅकअप फाईल रिस्टोर करा</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Section 2: PIN Security & Owner Details Form */}
          <form onSubmit={handleSave} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* PIN Config */}
              <div className="bg-white rounded-2xl p-4 border-2 border-[#D1E2D4] space-y-3">
                <h3 className="text-base font-extrabold text-[#0F291E] flex items-center gap-2">
                  <Unlock className="w-4 h-4 text-[#15803D]" />
                  <span>२. ४-अंकी पिन लॉक सेटिंग</span>
                </h3>
                <div>
                  <label className="block text-xs font-bold text-[#335441] mb-1">
                    ४-अंकी सुरक्षा पिन कोड (4-Digit PIN)
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    value={newPin}
                    onChange={(e) =>
                      setNewPin(e.target.value.replace(/\D/g, ""))
                    }
                    className="w-full min-h-[48px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-mono-code font-extrabold text-lg text-[#0F291E]"
                  />
                </div>
                <label className="flex items-center gap-2.5 text-sm font-bold text-[#0F291E] cursor-pointer pt-1">
                  <input
                    type="checkbox"
                    checked={enablePin}
                    onChange={(e) => setEnablePin(e.target.checked)}
                    className="w-5 h-5 accent-[#15803D]"
                  />
                  <span>ॲप उघडताना पिन लॉक अनिवार्य करा</span>
                </label>
              </div>

              {/* Tractor & Business Info */}
              <div className="bg-white rounded-2xl p-4 border-2 border-[#D1E2D4] space-y-3">
                <h3 className="text-base font-extrabold text-[#0F291E]">
                  🚜 ३. ट्रॅक्टर मालक व गाडी माहिती (बिलासाठी)
                </h3>
                <div>
                  <label className="block text-xs font-bold text-[#335441] mb-1">
                    व्यवसायाचे / मालकाचे नाव
                  </label>
                  <input
                    type="text"
                    value={owner}
                    onChange={(e) => setOwner(e.target.value)}
                    className="w-full min-h-[44px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3 py-1.5 font-bold text-sm text-[#0F291E]"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-bold text-[#335441] mb-1">
                      मोबाईल नंबर
                    </label>
                    <input
                      type="text"
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value)}
                      className="w-full min-h-[44px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3 py-1.5 font-bold text-sm text-[#0F291E]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-[#335441] mb-1">
                      ट्रॅक्टर मॉडेल / नंबर
                    </label>
                    <input
                      type="text"
                      value={tractor}
                      onChange={(e) => setTractor(e.target.value)}
                      className="w-full min-h-[44px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3 py-1.5 font-bold text-sm text-[#0F291E]"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Section 4: Editable Per-Acre Rates for Different Work Types */}
            <div className="bg-white rounded-2xl p-4 sm:p-5 border-2 border-[#D1E2D4] space-y-3">
              <div>
                <h3 className="text-base font-extrabold text-[#0F291E]">
                  💰 ४. विविध कामांचे प्रति-एकर दर पत्रक (Per-Acre Work Rates in ₹)
                </h3>
                <p className="text-xs font-semibold text-[#335441]">
                  येथे ठरवलेले दर काम नोंदवताना आपोआप लागू होतात
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {editableRates.map((r) => (
                  <div
                    key={r.id}
                    className="bg-[#F4F7F4] rounded-xl p-3 border border-[#D1E2D4] flex items-center justify-between gap-2"
                  >
                    <div>
                      <div className="font-extrabold text-xs sm:text-sm text-[#0F291E]">
                        {r.marathiName}
                      </div>
                      <div className="text-[11px] text-[#335441] font-semibold">
                        सध्याचा दर: {formatINR(r.ratePerAcre)} / एकर
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="font-bold text-sm text-[#15803D]">₹</span>
                      <input
                        type="number"
                        value={r.ratePerAcre}
                        onChange={(e) =>
                          handleRateChange(r.id, Number(e.target.value))
                        }
                        className="w-24 rounded-lg border-2 border-[#D1E2D4] bg-white px-2.5 py-1.5 font-extrabold text-sm text-right font-tabular text-[#0F291E]"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="min-h-[52px] px-5 py-2.5 rounded-xl bg-[#F4F7F4] text-[#0F291E] font-bold border border-[#D1E2D4] cursor-pointer"
              >
                बंद करा
              </button>
              <button
                type="submit"
                disabled={saving}
                className="min-h-[52px] px-6 py-2.5 rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-extrabold shadow-md cursor-pointer"
              >
                {saving ? "सेव्ह होत आहे..." : "सर्व सेटिंग्ज व दर सेव्ह करा"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
