"use client";

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type { GpsPoint } from "@/db/schema";
import {
  calculatePolygonLandArea,
  formatMarathiAreaBreakdown,
  MAHARASHTRA_VILLAGE_PRESETS,
} from "@/lib/agri-math";
import {
  latLngToScreen,
  screenToLatLng,
  visibleTiles,
  TILE_SIZE,
} from "@/lib/web-mercator";
import {
  MapPin,
  Navigation,
  Search,
  RotateCcw,
  Trash2,
  CheckCircle2,
  Edit3,
  Crosshair,
  Tractor,
  ZoomIn,
  ZoomOut,
  AlertTriangle,
  Maximize2,
  Minimize2,
  Save,
  KeyRound,
} from "lucide-react";

export interface FarmerItem {
  id: number;
  name: string;
  mobile: string;
  village: string;
  notes: string | null;
}

export interface FieldItem {
  id: number;
  farmerId: number;
  fieldName: string;
  village: string;
  gatNumber: string | null;
  polygonPoints: GpsPoint[];
  areaSqMeters: number;
  areaAcres: number;
  areaGunthas: number;
  areaHectares: number;
}

interface SatelliteMapMeasurerProps {
  farmers: FarmerItem[];
  fields: FieldItem[];
  selectedFarmerId: number | null;
  googleMapsApiKey: string;
  onOpenSettings: () => void;
  onSelectFarmerId: (id: number) => void;
  onSaveField: (payload: {
    id?: number;
    farmerId: number;
    fieldName: string;
    village: string;
    gatNumber: string;
    polygonPoints: GpsPoint[];
  }) => Promise<boolean>;
  onDeleteField: (fieldId: number) => Promise<void>;
  onStartWorkWithField: (field: FieldItem) => void;
}

declare global {
  interface Window {
    gm_authFailure?: () => void;
    __tractorGoogleMapsReady?: () => void;
  }
}

type GoogleState = "none" | "loading" | "ready" | "failed";
type StatusTone = "info" | "ok" | "error";

const ESRI_TILE_URL =
  "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile";
const MIN_ZOOM = 5;
const MAX_ZOOM = 19;

let googleMapsLoader: Promise<void> | null = null;
let googleMapsLoaderKey = "";

/** Loads the Google Maps JavaScript API once per page for the given key. */
function loadGoogleMaps(apiKey: string): Promise<void> {
  if (typeof window === "undefined") {
    return Promise.reject(new Error("no window"));
  }
  if (googleMapsLoader && googleMapsLoaderKey === apiKey) {
    return googleMapsLoader;
  }
  if (googleMapsLoader && googleMapsLoaderKey !== apiKey) {
    // The API cannot be re-initialised with another key without a page reload.
    return Promise.reject(new Error("reload required"));
  }
  googleMapsLoaderKey = apiKey;
  googleMapsLoader = new Promise<void>((resolve, reject) => {
    window.__tractorGoogleMapsReady = () => resolve();
    const script = document.createElement("script");
    script.src =
      "https://maps.googleapis.com/maps/api/js?key=" +
      encodeURIComponent(apiKey) +
      "&v=weekly&language=mr&region=IN&loading=async&callback=__tractorGoogleMapsReady";
    script.async = true;
    script.onerror = () => {
      googleMapsLoader = null;
      googleMapsLoaderKey = "";
      reject(new Error("script failed to load"));
    };
    document.head.appendChild(script);
  });
  return googleMapsLoader;
}

function round6(value: number): number {
  return Number(value.toFixed(6));
}

export default function SatelliteMapMeasurer({
  farmers,
  fields,
  selectedFarmerId,
  googleMapsApiKey,
  onOpenSettings,
  onSelectFarmerId,
  onSaveField,
  onDeleteField,
  onStartWorkWithField,
}: SatelliteMapMeasurerProps) {
  const apiKey = googleMapsApiKey.trim();

  const [center, setCenter] = useState<GpsPoint>({ lat: 18.1516, lng: 74.5775 });
  const [moveRequest, setMoveRequest] = useState(0);
  const [zoom, setZoom] = useState(17);
  const [points, setPoints] = useState<GpsPoint[]>([]);
  const [gps, setGps] = useState<GpsPoint | null>(null);
  const [status, setStatus] = useState<{ text: string; tone: StatusTone } | null>(
    null
  );
  const [searchQuery, setSearchQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [villageLabel, setVillageLabel] = useState("");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [googleState, setGoogleState] = useState<GoogleState>(
    apiKey ? "loading" : "none"
  );
  const [viewport, setViewport] = useState({ w: 0, h: 0 });
  const [tileError, setTileError] = useState(false);

  const [editingFieldId, setEditingFieldId] = useState<number | null>(null);
  const [farmerIdForSave, setFarmerIdForSave] = useState<number | null>(
    selectedFarmerId ?? farmers[0]?.id ?? null
  );
  const [fieldName, setFieldName] = useState("");
  const [gatNumber, setGatNumber] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [filterFarmerId, setFilterFarmerId] = useState<number | "ALL">("ALL");

  const googleDivRef = useRef<HTMLDivElement | null>(null);
  const esriDivRef = useRef<HTMLDivElement | null>(null);
  const formRef = useRef<HTMLFormElement | null>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const dragRef = useRef<{
    startX: number;
    startY: number;
    startCenter: GpsPoint;
    moved: boolean;
  } | null>(null);

  const useGoogle = googleState === "ready";
  const measurement = useMemo(() => calculatePolygonLandArea(points), [points]);

  const requestMove = useCallback((target: GpsPoint) => {
    setCenter(target);
    setMoveRequest((n) => n + 1);
  }, []);

  // Keep the owner selection valid as the farmer list loads or changes.
  useEffect(() => {
    if (selectedFarmerId && farmers.some((f) => f.id === selectedFarmerId)) {
      setFarmerIdForSave(selectedFarmerId);
    } else if (
      farmers.length > 0 &&
      !farmers.some((f) => f.id === farmerIdForSave)
    ) {
      setFarmerIdForSave(farmers[0].id);
    }
  }, [selectedFarmerId, farmers, farmerIdForSave]);

  // ---------------- Google Maps: load the API ----------------
  useEffect(() => {
    if (!apiKey) {
      setGoogleState("none");
      return;
    }
    let cancelled = false;
    setGoogleState("loading");
    window.gm_authFailure = () => {
      if (!cancelled) setGoogleState("failed");
    };
    loadGoogleMaps(apiKey)
      .then(() => {
        if (!cancelled) setGoogleState("ready");
      })
      .catch(() => {
        if (!cancelled) setGoogleState("failed");
      });
    return () => {
      cancelled = true;
    };
  }, [apiKey]);

  // ---------------- Google Maps: create the map ----------------
  useEffect(() => {
    if (googleState !== "ready" || !googleDivRef.current) return;
    const map = new google.maps.Map(googleDivRef.current, {
      center,
      zoom: Math.max(zoom, 17),
      mapTypeId: "hybrid",
      tilt: 0,
      gestureHandling: "greedy",
      clickableIcons: false,
      fullscreenControl: false,
      streetViewControl: false,
      mapTypeControl: true,
      zoomControl: true,
    });
    mapRef.current = map;
    const clickListener = map.addListener(
      "click",
      (event: google.maps.MapMouseEvent) => {
        if (!event.latLng) return;
        const point = {
          lat: round6(event.latLng.lat()),
          lng: round6(event.latLng.lng()),
        };
        setPoints((prev) => [...prev, point]);
      }
    );
    const idleListener = map.addListener("idle", () => {
      const c = map.getCenter();
      if (c) setCenter({ lat: round6(c.lat()), lng: round6(c.lng()) });
    });
    return () => {
      clickListener.remove();
      idleListener.remove();
      mapRef.current = null;
    };
    // The map is created once per API load; later moves go through moveRequest.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [googleState]);

  // ---------------- Google Maps: move when asked ----------------
  useEffect(() => {
    if (moveRequest === 0 || !mapRef.current) return;
    mapRef.current.panTo(center);
    if ((mapRef.current.getZoom() ?? 0) < 16) mapRef.current.setZoom(17);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [moveRequest]);

  // ---------------- Google Maps: draw boundary, markers, GPS ----------------
  useEffect(() => {
    const map = mapRef.current;
    if (googleState !== "ready" || !map) return;
    const created: Array<{ setMap: (m: google.maps.Map | null) => void }> = [];

    if (points.length >= 3) {
      created.push(
        new google.maps.Polygon({
          map,
          paths: points,
          strokeColor: "#22C55E",
          strokeWeight: 3,
          fillColor: "#22C55E",
          fillOpacity: 0.3,
          clickable: false,
        })
      );
    } else if (points.length === 2) {
      created.push(
        new google.maps.Polyline({
          map,
          path: points,
          strokeColor: "#22C55E",
          strokeWeight: 3,
          clickable: false,
        })
      );
    }

    measurement.segmentDistancesMeters.forEach((distance, index) => {
      const a = points[index];
      const b = points[(index + 1) % points.length];
      if (!a || !b) return;
      created.push(
        new google.maps.Marker({
          map,
          position: { lat: (a.lat + b.lat) / 2, lng: (a.lng + b.lng) / 2 },
          clickable: false,
          icon: { path: google.maps.SymbolPath.CIRCLE, scale: 0 },
          label: {
            text: `${distance} m`,
            color: "#FFFFFF",
            fontSize: "11px",
            fontWeight: "700",
            className: "tm-edge-label",
          },
        })
      );
    });

    points.forEach((point, index) => {
      const marker = new google.maps.Marker({
        map,
        position: point,
        draggable: true,
        label: {
          text: String(index + 1),
          color: "#FFFFFF",
          fontSize: "12px",
          fontWeight: "700",
        },
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 12,
          fillColor: "#15803D",
          fillOpacity: 1,
          strokeColor: "#FFFFFF",
          strokeWeight: 2.5,
        },
      });
      marker.addListener("dragend", (event: google.maps.MapMouseEvent) => {
        if (!event.latLng) return;
        const moved = {
          lat: round6(event.latLng.lat()),
          lng: round6(event.latLng.lng()),
        };
        setPoints((prev) => prev.map((p, i) => (i === index ? moved : p)));
      });
      created.push(marker);
    });

    if (gps) {
      created.push(
        new google.maps.Marker({
          map,
          position: gps,
          clickable: false,
          icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: "#0284C7",
            fillOpacity: 1,
            strokeColor: "#FFFFFF",
            strokeWeight: 3,
          },
        })
      );
    }

    return () => created.forEach((overlay) => overlay.setMap(null));
  }, [googleState, points, gps, measurement]);

  // ---------------- Fallback map: track its size on screen ----------------
  useEffect(() => {
    if (useGoogle) return;
    const el = esriDivRef.current;
    if (!el) return;
    const update = () => setViewport({ w: el.clientWidth, h: el.clientHeight });
    update();
    const observer = new ResizeObserver(update);
    observer.observe(el);
    return () => observer.disconnect();
  }, [useGoogle, isFullscreen]);

  // ---------------- Full screen: lock page scroll, Esc to exit ----------------
  useEffect(() => {
    if (!isFullscreen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setIsFullscreen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", onKey);
    };
  }, [isFullscreen]);

  const tiles = useMemo(
    () =>
      viewport.w > 0 && viewport.h > 0
        ? visibleTiles(center, zoom, viewport.w, viewport.h)
        : [],
    [center, zoom, viewport]
  );

  const screenPoints = useMemo(
    () =>
      points.map((p) => latLngToScreen(p, center, zoom, viewport.w, viewport.h)),
    [points, center, zoom, viewport]
  );

  const centroid = useMemo(() => {
    if (screenPoints.length === 0) return { x: 0, y: 0 };
    return {
      x: screenPoints.reduce((s, p) => s + p.x, 0) / screenPoints.length,
      y: screenPoints.reduce((s, p) => s + p.y, 0) / screenPoints.length,
    };
  }, [screenPoints]);

  // ---------------- Fallback map: drag to pan, tap to add a point ----------------
  const handlePointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId);
    dragRef.current = {
      startX: event.clientX,
      startY: event.clientY,
      startCenter: center,
      moved: false,
    };
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    if (!drag || viewport.w === 0) return;
    const dx = event.clientX - drag.startX;
    const dy = event.clientY - drag.startY;
    if (!drag.moved && Math.hypot(dx, dy) < 6) return;
    drag.moved = true;
    const next = screenToLatLng(
      viewport.w / 2 - dx,
      viewport.h / 2 - dy,
      drag.startCenter,
      zoom,
      viewport.w,
      viewport.h
    );
    setCenter({ lat: round6(next.lat), lng: round6(next.lng) });
  };

  const handlePointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    const drag = dragRef.current;
    dragRef.current = null;
    if (!drag || drag.moved || viewport.w === 0) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const tapped = screenToLatLng(
      event.clientX - rect.left,
      event.clientY - rect.top,
      center,
      zoom,
      viewport.w,
      viewport.h
    );
    setPoints((prev) => [
      ...prev,
      { lat: round6(tapped.lat), lng: round6(tapped.lng) },
    ]);
  };

  // ---------------- GPS: real position only ----------------
  const locate = (addPoint: boolean) => {
    if (typeof navigator === "undefined" || !("geolocation" in navigator)) {
      setStatus({ text: "या डिव्हाइसवर GPS उपलब्ध नाही.", tone: "error" });
      return;
    }
    setStatus({ text: "GPS ठिकाण शोधत आहे...", tone: "info" });
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const fix = {
          lat: round6(position.coords.latitude),
          lng: round6(position.coords.longitude),
        };
        setGps(fix);
        requestMove(fix);
        if (addPoint) setPoints((prev) => [...prev, fix]);
        setStatus({
          text: `GPS ठिकाण मिळाले (अचूकता सुमारे ${Math.round(
            position.coords.accuracy
          )} मीटर)`,
          tone: "ok",
        });
      },
      (error) => {
        setStatus({
          text:
            error.code === error.PERMISSION_DENIED
              ? "GPS परवानगी नाकारली. ब्राउझर सेटिंग्जमध्ये लोकेशन परवानगी द्या."
              : "GPS ठिकाण मिळाले नाही. GPS चालू करून पुन्हा प्रयत्न करा.",
          tone: "error",
        });
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  };

  // ---------------- Place search ----------------
  const goToPlace = (target: GpsPoint, label: string) => {
    requestMove(target);
    if (!useGoogle) setZoom((z) => Math.max(z, 16));
    setVillageLabel(label);
    setStatus({ text: `ठिकाण: ${label}`, tone: "ok" });
  };

  const runSearch = async () => {
    const query = searchQuery.trim();
    if (!query || searching) return;
    setSearching(true);
    setStatus({ text: "ठिकाण शोधत आहे...", tone: "info" });
    try {
      let found: GpsPoint | null = null;
      if (useGoogle) {
        const response = await new google.maps.Geocoder().geocode({
          address: query,
          region: "IN",
        });
        const location = response.results[0]?.geometry.location;
        if (location) found = { lat: location.lat(), lng: location.lng() };
      } else {
        const response = await fetch(
          "https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=in&q=" +
            encodeURIComponent(query),
          { headers: { Accept: "application/json" } }
        );
        const results: unknown = await response.json();
        if (Array.isArray(results) && results[0]) {
          const first = results[0] as { lat: string; lon: string };
          found = { lat: Number(first.lat), lng: Number(first.lon) };
        }
      }
      if (found && Number.isFinite(found.lat) && Number.isFinite(found.lng)) {
        goToPlace({ lat: round6(found.lat), lng: round6(found.lng) }, query);
      } else {
        setStatus({ text: "ठिकाण सापडले नाही. नाव तपासून पुन्हा शोधा.", tone: "error" });
      }
    } catch {
      setStatus({
        text: "ठिकाण सापडले नाही किंवा शोध सेवा उपलब्ध नाही. इंटरनेट तपासा.",
        tone: "error",
      });
    } finally {
      setSearching(false);
    }
  };

  // ---------------- Saved fields ----------------
  const handleLoadSavedField = (field: FieldItem) => {
    setEditingFieldId(field.id);
    setFarmerIdForSave(field.farmerId);
    setFieldName(field.fieldName);
    setGatNumber(field.gatNumber || "");
    setVillageLabel(field.village);
    const loaded = Array.isArray(field.polygonPoints) ? field.polygonPoints : [];
    setPoints(loaded);
    if (loaded.length > 0) {
      requestMove({
        lat: round6(loaded.reduce((s, p) => s + p.lat, 0) / loaded.length),
        lng: round6(loaded.reduce((s, p) => s + p.lng, 0) / loaded.length),
      });
      if (!useGoogle) setZoom((z) => Math.max(z, 17));
    }
    setStatus({
      text: `'${field.fieldName}' नकाशावर लोड केले. कोपरे बदलून पुन्हा सेव्ह करू शकता.`,
      tone: "info",
    });
  };

  const resetForm = () => {
    setEditingFieldId(null);
    setFieldName("");
    setGatNumber("");
  };

  const handleSave = async (event: React.FormEvent) => {
    event.preventDefault();
    if (points.length < 3) {
      setStatus({ text: "कृपया नकाशावर किमान ३ कोपरे निवडा.", tone: "error" });
      return;
    }
    if (!farmerIdForSave) {
      setStatus({ text: "कृपया आधी शेतकरी जोडा किंवा निवडा.", tone: "error" });
      return;
    }
    if (!fieldName.trim()) {
      setStatus({ text: "कृपया शेताचे नाव टाका.", tone: "error" });
      return;
    }
    setIsSaving(true);
    try {
      const saved = await onSaveField({
        id: editingFieldId ?? undefined,
        farmerId: farmerIdForSave,
        fieldName: fieldName.trim(),
        village: villageLabel,
        gatNumber: gatNumber.trim(),
        polygonPoints: points,
      });
      if (saved) {
        setStatus({
          text: `'${fieldName.trim()}' सेव्ह झाले (${measurement.areaAcres.toFixed(2)} एकर).`,
          tone: "ok",
        });
        resetForm();
      } else {
        setStatus({ text: "शेत सेव्ह झाले नाही. पुन्हा प्रयत्न करा.", tone: "error" });
      }
    } catch {
      setStatus({ text: "शेत सेव्ह झाले नाही. पुन्हा प्रयत्न करा.", tone: "error" });
    } finally {
      setIsSaving(false);
    }
  };

  const visibleFields = useMemo(
    () =>
      filterFarmerId === "ALL"
        ? fields
        : fields.filter((f) => f.farmerId === filterFarmerId),
    [fields, filterFarmerId]
  );

  const statusClasses: Record<StatusTone, string> = {
    info: "bg-sky-50 border-sky-300 text-sky-900",
    ok: "bg-emerald-50 border-[#16A34A] text-[#14532D]",
    error: "bg-red-50 border-red-300 text-[#B91C1C]",
  };

  const providerLabel = useGoogle
    ? "Google नकाशा (हायब्रिड सॅटेलाईट)"
    : "Esri सॅटेलाईट नकाशा";

  return (
    <div className="space-y-5">
      {/* Google Maps key notices */}
      {googleState === "none" && (
        <div className="bg-amber-50 border-2 border-amber-300 text-amber-900 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-2 text-sm font-semibold">
            <KeyRound className="w-5 h-5 shrink-0 mt-0.5" />
            <span>
              Google Maps वापरण्यासाठी Google Maps API key आवश्यक आहे. key
              टाकेपर्यंत Esri सॅटेलाईट नकाशा वापरला जाईल.
            </span>
          </div>
          <button
            type="button"
            onClick={onOpenSettings}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-bold text-sm cursor-pointer"
          >
            API key टाका
          </button>
        </div>
      )}
      {googleState === "failed" && (
        <div className="bg-red-50 border-2 border-red-300 text-[#B91C1C] rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-2 text-sm font-semibold">
            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
            <span>
              Google Maps लोड झाला नाही. API key चुकीची असू शकते किंवा Maps
              JavaScript API चालू नाही. सध्या Esri सॅटेलाईट नकाशा वापरला आहे.
            </span>
          </div>
          <button
            type="button"
            onClick={onOpenSettings}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-white border-2 border-red-300 text-[#B91C1C] font-bold text-sm cursor-pointer"
          >
            API key तपासा
          </button>
        </div>
      )}

      {/* Search + GPS toolbar */}
      <div className="bg-white rounded-2xl border-2 border-[#D1E2D4] p-4 shadow-sm space-y-3">
        <div className="flex flex-col lg:flex-row gap-3">
          <form
            className="flex-1 flex items-center gap-2 bg-[#F4F7F4] border-2 border-[#D1E2D4] focus-within:border-[#15803D] rounded-xl px-3.5 py-2"
            onSubmit={(event) => {
              event.preventDefault();
              void runSearch();
            }}
          >
            <Search className="w-5 h-5 text-[#15803D] shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              placeholder="गाव किंवा शेताचे ठिकाण शोधा"
              className="w-full bg-transparent text-[#0F291E] placeholder-[#335441]/70 font-medium focus:outline-none text-base"
            />
            <button
              type="submit"
              disabled={searching || !searchQuery.trim()}
              className="min-h-[40px] px-4 rounded-lg bg-[#15803D] hover:bg-[#14532D] text-white font-bold text-sm disabled:opacity-50 cursor-pointer"
            >
              {searching ? "शोधत आहे..." : "शोधा"}
            </button>
          </form>

          <div className="flex gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => locate(false)}
              className="flex-1 min-h-[52px] px-4 rounded-xl bg-[#0284C7] hover:bg-[#0369A1] text-white font-bold flex items-center justify-center gap-2 cursor-pointer"
            >
              <Crosshair className="w-5 h-5" />
              <span>माझे ठिकाण</span>
            </button>
            <button
              type="button"
              onClick={() => locate(true)}
              className="flex-1 min-h-[52px] px-4 rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-bold flex items-center justify-center gap-2 cursor-pointer"
            >
              <Navigation className="w-5 h-5" />
              <span>GPS कोपरा जोडा</span>
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {MAHARASHTRA_VILLAGE_PRESETS.map((village) => (
            <button
              key={village.nameEnglish}
              type="button"
              onClick={() =>
                goToPlace(
                  { lat: village.lat, lng: village.lng },
                  village.nameMarathi
                )
              }
              className="text-xs font-bold px-3 py-1.5 rounded-lg border bg-[#F4F7F4] text-[#0F291E] border-[#D1E2D4] hover:border-[#15803D] cursor-pointer"
            >
              {village.nameMarathi}
            </button>
          ))}
        </div>

        {status && (
          <div
            className={`border rounded-xl px-3.5 py-2.5 text-sm font-semibold ${statusClasses[status.tone]}`}
          >
            {status.text}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* ---------------- Map (normal card or full screen) ---------------- */}
        <div
          className={
            isFullscreen
              ? "fixed inset-0 z-40 bg-[#0F291E] flex flex-col"
              : "lg:col-span-7 bg-white rounded-2xl border-2 border-[#D1E2D4] overflow-hidden shadow-sm flex flex-col"
          }
        >
          <div className="bg-[#0F291E] text-white px-3 py-2.5 flex items-center justify-between gap-2">
            <div className="min-w-0">
              <div className="font-bold text-sm truncate">{providerLabel}</div>
              <div className="text-[11px] text-emerald-200 font-mono-code truncate">
                {center.lat.toFixed(5)}, {center.lng.toFixed(5)}
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              {!useGoogle && (
                <>
                  <button
                    type="button"
                    onClick={() => setZoom((z) => Math.min(MAX_ZOOM, z + 1))}
                    className="w-10 h-10 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center cursor-pointer"
                    aria-label="झूम इन"
                  >
                    <ZoomIn className="w-5 h-5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setZoom((z) => Math.max(MIN_ZOOM, z - 1))}
                    className="w-10 h-10 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center cursor-pointer"
                    aria-label="झूम आउट"
                  >
                    <ZoomOut className="w-5 h-5" />
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={() => setIsFullscreen((value) => !value)}
                className="h-10 px-3 rounded-lg bg-[#22C55E] hover:bg-emerald-400 text-[#0F291E] font-bold text-xs flex items-center gap-1.5 cursor-pointer"
              >
                {isFullscreen ? (
                  <Minimize2 className="w-4 h-4" />
                ) : (
                  <Maximize2 className="w-4 h-4" />
                )}
                <span>{isFullscreen ? "लहान करा" : "पूर्ण स्क्रीन"}</span>
              </button>
            </div>
          </div>

          <div
            className={
              isFullscreen
                ? "relative flex-1 min-h-0"
                : "relative w-full h-[62vh] min-h-[380px]"
            }
          >
            {useGoogle ? (
              <div ref={googleDivRef} className="absolute inset-0" />
            ) : (
              <div
                ref={esriDivRef}
                className="absolute inset-0 overflow-hidden bg-[#17331E] cursor-crosshair select-none"
                style={{ touchAction: "none" }}
                onPointerDown={handlePointerDown}
                onPointerMove={handlePointerMove}
                onPointerUp={handlePointerUp}
                onPointerCancel={() => {
                  dragRef.current = null;
                }}
              >
                {tiles.map((tile) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    key={tile.key}
                    src={`${ESRI_TILE_URL}/${zoom}/${tile.y}/${tile.x}`}
                    alt=""
                    draggable={false}
                    className="absolute max-w-none pointer-events-none"
                    style={{
                      left: Math.round(tile.left),
                      top: Math.round(tile.top),
                      width: TILE_SIZE,
                      height: TILE_SIZE,
                    }}
                    onLoad={() => setTileError(false)}
                    onError={() => setTileError(true)}
                  />
                ))}

                <svg
                  width={viewport.w}
                  height={viewport.h}
                  className="absolute inset-0 pointer-events-none"
                >
                  {gps &&
                    (() => {
                      const p = latLngToScreen(
                        gps,
                        center,
                        zoom,
                        viewport.w,
                        viewport.h
                      );
                      return (
                        <g transform={`translate(${p.x}, ${p.y})`}>
                          <circle r="18" fill="rgba(14,165,233,0.28)" />
                          <circle
                            r="7"
                            fill="#0284C7"
                            stroke="#FFFFFF"
                            strokeWidth="2.5"
                          />
                        </g>
                      );
                    })()}

                  {screenPoints.length >= 3 && (
                    <polygon
                      points={screenPoints.map((p) => `${p.x},${p.y}`).join(" ")}
                      fill="rgba(34,197,94,0.32)"
                      stroke="#22C55E"
                      strokeWidth="3"
                    />
                  )}
                  {screenPoints.length === 2 && (
                    <line
                      x1={screenPoints[0].x}
                      y1={screenPoints[0].y}
                      x2={screenPoints[1].x}
                      y2={screenPoints[1].y}
                      stroke="#22C55E"
                      strokeWidth="3"
                    />
                  )}

                  {measurement.segmentDistancesMeters.map((distance, index) => {
                    const a = screenPoints[index];
                    const b = screenPoints[(index + 1) % screenPoints.length];
                    if (!a || !b) return null;
                    const mx = (a.x + b.x) / 2;
                    const my = (a.y + b.y) / 2;
                    return (
                      <g key={`edge-${index}`}>
                        <rect
                          x={mx - 30}
                          y={my - 10}
                          width="60"
                          height="20"
                          rx="6"
                          fill="rgba(15,41,30,0.88)"
                          stroke="#86EFAC"
                        />
                        <text
                          x={mx}
                          y={my + 4}
                          textAnchor="middle"
                          fill="#FFFFFF"
                          fontSize="11"
                          fontWeight="700"
                        >
                          {distance} m
                        </text>
                      </g>
                    );
                  })}

                  {screenPoints.length >= 3 && (
                    <g transform={`translate(${centroid.x}, ${centroid.y})`}>
                      <rect
                        x="-62"
                        y="-14"
                        width="124"
                        height="28"
                        rx="8"
                        fill="rgba(20,83,45,0.92)"
                        stroke="#FFFFFF"
                        strokeWidth="1.5"
                      />
                      <text
                        x="0"
                        y="5"
                        textAnchor="middle"
                        fill="#FFFFFF"
                        fontSize="14"
                        fontWeight="800"
                      >
                        {measurement.areaAcres.toFixed(2)} एकर
                      </text>
                    </g>
                  )}

                  {screenPoints.map((p, index) => (
                    <g key={`vertex-${index}`} transform={`translate(${p.x}, ${p.y})`}>
                      <circle r="12" fill="#15803D" stroke="#FFFFFF" strokeWidth="2.5" />
                      <text
                        x="0"
                        y="4"
                        textAnchor="middle"
                        fill="#FFFFFF"
                        fontSize="11"
                        fontWeight="800"
                      >
                        {index + 1}
                      </text>
                    </g>
                  ))}
                </svg>

                <div className="absolute bottom-1 right-1 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded pointer-events-none">
                  Imagery © Esri, Maxar, Earthstar Geographics
                </div>
                {tileError && (
                  <div className="absolute top-2 left-2 right-2 bg-red-600/90 text-white text-xs font-bold px-3 py-2 rounded-lg pointer-events-none">
                    सॅटेलाईट नकाशा लोड झाला नाही. इंटरनेट तपासा किंवा झूम कमी करा.
                  </div>
                )}
              </div>
            )}

            {/* Compact live area readout, always visible on top of the map */}
            <div className="absolute top-2 left-2 z-10 bg-[#14532D]/95 text-white rounded-xl px-3 py-2 shadow-lg pointer-events-none max-w-[calc(100%-1rem)]">
              <div className="flex items-baseline gap-3 font-tabular">
                <span className="text-lg font-extrabold">
                  {measurement.areaAcres.toFixed(2)}{" "}
                  <span className="text-xs font-bold">एकर</span>
                </span>
                <span className="text-sm font-bold">
                  {measurement.areaGunthas.toFixed(1)}{" "}
                  <span className="text-xs">गुंठे</span>
                </span>
                <span className="text-sm font-bold">
                  {measurement.areaHectares.toFixed(3)}{" "}
                  <span className="text-xs">हेक्टर</span>
                </span>
              </div>
              <div className="text-[11px] text-emerald-200 font-semibold">
                कोपरे: {points.length} • परिघ: {measurement.perimeterMeters} मी.
              </div>
            </div>
          </div>

          <div className="p-2.5 bg-[#F4F7F4] border-t border-[#D1E2D4] grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => locate(true)}
              className="min-h-[48px] px-2 rounded-xl bg-white text-[#15803D] border-2 border-[#D1E2D4] font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Navigation className="w-4 h-4" />
              <span>GPS कोपरा जोडा</span>
            </button>
            <button
              type="button"
              onClick={() => setPoints((prev) => prev.slice(0, -1))}
              disabled={points.length === 0}
              className="min-h-[48px] px-2 rounded-xl bg-white text-[#0F291E] border-2 border-[#D1E2D4] font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 disabled:opacity-40 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-[#B45309]" />
              <span>मागील काढा</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setPoints([]);
                setEditingFieldId(null);
              }}
              disabled={points.length === 0}
              className="min-h-[48px] px-2 rounded-xl bg-white text-[#DC2626] border-2 border-red-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 disabled:opacity-40 cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>सर्व पुसा</span>
            </button>
            <button
              type="button"
              disabled={points.length < 3}
              onClick={() => {
                setIsFullscreen(false);
                window.setTimeout(
                  () =>
                    formRef.current?.scrollIntoView({
                      behavior: "smooth",
                      block: "center",
                    }),
                  50
                );
              }}
              className="min-h-[48px] px-2 rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 disabled:opacity-40 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>शेत सेव्ह करा</span>
            </button>
          </div>
        </div>

        {/* ---------------- Save form + saved fields ---------------- */}
        <div className="lg:col-span-5 space-y-5">
          <div className="bg-gradient-to-r from-[#14532D] to-[#15803D] text-white rounded-2xl p-4 shadow-sm">
            <div className="text-xs font-bold text-emerald-100">
              मोजलेले क्षेत्रफळ
            </div>
            <div className="grid grid-cols-3 gap-2 mt-2 font-tabular">
              <div className="bg-white/10 rounded-xl p-2.5">
                <div className="text-xl font-extrabold">
                  {measurement.areaAcres.toFixed(2)}
                </div>
                <div className="text-xs font-bold text-emerald-100">एकर</div>
              </div>
              <div className="bg-white/10 rounded-xl p-2.5">
                <div className="text-xl font-extrabold">
                  {measurement.areaGunthas.toFixed(1)}
                </div>
                <div className="text-xs font-bold text-emerald-100">गुंठे</div>
              </div>
              <div className="bg-white/10 rounded-xl p-2.5">
                <div className="text-xl font-extrabold">
                  {measurement.areaHectares.toFixed(3)}
                </div>
                <div className="text-xs font-bold text-emerald-100">हेक्टर</div>
              </div>
            </div>
            <div className="text-xs font-semibold text-emerald-100 mt-2">
              {formatMarathiAreaBreakdown(measurement.areaAcres)} •{" "}
              {measurement.areaSqMeters.toLocaleString("en-IN")} चौ.मी.
            </div>
          </div>

          <form
            ref={formRef}
            onSubmit={handleSave}
            className="bg-white rounded-2xl border-2 border-[#D1E2D4] p-5 shadow-sm space-y-4"
          >
            <div className="flex items-center justify-between border-b border-[#D1E2D4] pb-3">
              <h3 className="text-lg font-extrabold text-[#0F291E]">
                {editingFieldId ? "शेत बदला" : "शेत सेव्ह करा"}
              </h3>
              {editingFieldId && (
                <button
                  type="button"
                  onClick={() => {
                    resetForm();
                    setPoints([]);
                  }}
                  className="text-xs font-bold text-[#DC2626] underline cursor-pointer"
                >
                  नवीन शेत मोजा
                </button>
              )}
            </div>

            <div>
              <label className="block text-sm font-bold text-[#0F291E] mb-1">
                शेतकरी निवडा *
              </label>
              {farmers.length === 0 ? (
                <div className="text-sm font-semibold text-[#B45309] bg-amber-50 border border-amber-300 rounded-xl p-3">
                  अजून शेतकरी जोडलेला नाही. आधी शेतकरी टॅबमध्ये शेतकरी जोडा.
                </div>
              ) : (
                <select
                  value={farmerIdForSave ?? ""}
                  onChange={(event) => {
                    const id = Number(event.target.value);
                    setFarmerIdForSave(id);
                    onSelectFarmerId(id);
                  }}
                  className="w-full min-h-[50px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2.5 font-bold text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                >
                  {farmers.map((farmer) => (
                    <option key={farmer.id} value={farmer.id}>
                      {farmer.name} ({farmer.village})
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-sm font-bold text-[#0F291E] mb-1">
                  शेताचे नाव *
                </label>
                <input
                  type="text"
                  value={fieldName}
                  onChange={(event) => setFieldName(event.target.value)}
                  placeholder="उदा. विहिरीजवळचे शेत"
                  className="w-full min-h-[50px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-semibold text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-[#0F291E] mb-1">
                  गट नंबर
                </label>
                <input
                  type="text"
                  value={gatNumber}
                  onChange={(event) => setGatNumber(event.target.value)}
                  placeholder="उदा. १४२"
                  className="w-full min-h-[50px] rounded-xl border-2 border-[#D1E2D4] bg-[#F4F7F4] px-3.5 py-2 font-semibold text-[#0F291E] focus:border-[#15803D] focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSaving || points.length < 3 || farmers.length === 0}
              className="w-full min-h-[56px] rounded-xl bg-[#15803D] hover:bg-[#14532D] text-white font-extrabold text-base shadow-md flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>
                {isSaving
                  ? "सेव्ह होत आहे..."
                  : editingFieldId
                  ? "बदल सेव्ह करा"
                  : "शेत सेव्ह करा"}
              </span>
            </button>
            {points.length < 3 && (
              <p className="text-xs font-semibold text-[#335441]">
                नकाशावर टॅप करून किमान ३ कोपरे निवडा.
              </p>
            )}
          </form>

          <div className="bg-white rounded-2xl border-2 border-[#D1E2D4] p-5 shadow-sm space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#D1E2D4] pb-3">
              <h3 className="text-base font-extrabold text-[#0F291E]">
                सेव्ह केलेली शेते ({visibleFields.length})
              </h3>
              <select
                value={filterFarmerId}
                onChange={(event) =>
                  setFilterFarmerId(
                    event.target.value === "ALL"
                      ? "ALL"
                      : Number(event.target.value)
                  )
                }
                className="text-xs font-bold border-2 border-[#D1E2D4] rounded-lg px-2.5 py-1.5 bg-[#F4F7F4] text-[#0F291E]"
              >
                <option value="ALL">सर्व शेतकरी</option>
                {farmers.map((farmer) => (
                  <option key={farmer.id} value={farmer.id}>
                    {farmer.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
              {visibleFields.map((field) => {
                const owner = farmers.find((f) => f.id === field.farmerId);
                const isSelected = editingFieldId === field.id;
                return (
                  <div
                    key={field.id}
                    className={`rounded-xl p-3.5 border-2 ${
                      isSelected
                        ? "border-[#15803D] bg-emerald-50/70"
                        : "border-[#D1E2D4] bg-[#F4F7F4]/60"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="font-extrabold text-[#0F291E] text-sm sm:text-base">
                          {field.fieldName}
                        </div>
                        <div className="text-xs font-bold text-[#335441] mt-0.5 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 shrink-0" />
                          <span className="truncate">
                            {owner?.name ?? "-"}
                            {field.village ? ` • ${field.village}` : ""}
                            {field.gatNumber ? ` • ${field.gatNumber}` : ""}
                          </span>
                        </div>
                      </div>
                      <span className="bg-[#15803D] text-white text-xs font-extrabold px-2.5 py-1 rounded-lg shrink-0 font-tabular">
                        {field.areaAcres.toFixed(2)} एकर
                      </span>
                    </div>

                    <div className="mt-2 text-xs font-bold text-[#0F291E] font-tabular">
                      {field.areaGunthas.toFixed(1)} गुंठे •{" "}
                      {field.areaHectares.toFixed(3)} हेक्टर •{" "}
                      {field.areaSqMeters.toFixed(0)} चौ.मी.
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-[#D1E2D4] flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleLoadSavedField(field)}
                        className="flex-1 min-h-[42px] px-3 rounded-lg bg-white text-[#15803D] border border-[#15803D] text-xs font-extrabold flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>नकाशावर पहा / बदला</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onStartWorkWithField(field)}
                        className="flex-1 min-h-[42px] px-3 rounded-lg bg-[#15803D] hover:bg-[#14532D] text-white text-xs font-extrabold flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Tractor className="w-3.5 h-3.5" />
                        <span>काम नोंदवा</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (
                            window.confirm(
                              `'${field.fieldName}' हे शेत कायमचे हटवायचे का?`
                            )
                          ) {
                            if (editingFieldId === field.id) resetForm();
                            void onDeleteField(field.id);
                          }
                        }}
                        className="min-h-[42px] px-3 rounded-lg bg-red-50 text-[#DC2626] border border-red-200 text-xs font-bold flex items-center justify-center cursor-pointer"
                        aria-label="शेत हटवा"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}

              {visibleFields.length === 0 && (
                <div className="text-center py-6 text-sm font-semibold text-[#335441]">
                  अजून कोणतेही शेत सेव्ह केलेले नाही.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
