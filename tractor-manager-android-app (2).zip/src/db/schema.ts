import {
  pgTable,
  serial,
  text,
  integer,
  doublePrecision,
  boolean,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";

export interface GpsPoint {
  lat: number;
  lng: number;
}

export interface WorkTypeRate {
  id: string;
  marathiName: string;
  englishName: string;
  ratePerAcre: number;
  unitLabel: string;
}

export const farmers = pgTable("farmers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  mobile: text("mobile").notNull(),
  village: text("village").notNull(),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const fields = pgTable("fields", {
  id: serial("id").primaryKey(),
  farmerId: integer("farmer_id")
    .notNull()
    .references(() => farmers.id, { onDelete: "cascade" }),
  fieldName: text("field_name").notNull(),
  village: text("village").notNull(),
  gatNumber: text("gat_number").default(""),
  polygonPoints: jsonb("polygon_points").$type<GpsPoint[]>().notNull(),
  areaSqMeters: doublePrecision("area_sq_meters").notNull(),
  areaAcres: doublePrecision("area_acres").notNull(),
  areaGunthas: doublePrecision("area_gunthas").notNull(),
  areaHectares: doublePrecision("area_hectares").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const workRecords = pgTable("work_records", {
  id: serial("id").primaryKey(),
  farmerId: integer("farmer_id")
    .notNull()
    .references(() => farmers.id, { onDelete: "cascade" }),
  fieldId: integer("field_id").references(() => fields.id, {
    onDelete: "set null",
  }),
  workType: text("work_type").notNull(),
  workDate: text("work_date").notNull(),
  acres: doublePrecision("acres").notNull(),
  gunthas: doublePrecision("gunthas").notNull(),
  ratePerAcre: doublePrecision("rate_per_acre").notNull(),
  totalAmount: doublePrecision("total_amount").notNull(),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  farmerId: integer("farmer_id")
    .notNull()
    .references(() => farmers.id, { onDelete: "cascade" }),
  workRecordId: integer("work_record_id").references(() => workRecords.id, {
    onDelete: "set null",
  }),
  amount: doublePrecision("amount").notNull(),
  paymentType: text("payment_type").notNull(), // ADVANCE | PARTIAL | FINAL
  paymentMode: text("payment_mode").notNull(), // CASH | UPI | BANK
  paymentDate: text("payment_date").notNull(),
  receiptNumber: text("receipt_number").notNull(),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const appSettings = pgTable("app_settings", {
  id: serial("id").primaryKey(),
  pinCode: text("pin_code").notNull().default("1234"),
  pinEnabled: boolean("pin_enabled").notNull().default(false),
  ownerName: text("owner_name")
    .notNull()
    .default("सह्याद्री ट्रॅक्टर सर्व्हिसेस (संभाजी देशमुख)"),
  ownerMobile: text("owner_mobile").notNull().default("9850112233"),
  tractorModel: text("tractor_model")
    .notNull()
    .default("महिंद्रा ५७५ डीआय (MH-12-TR-4590)"),
  ratesJson: jsonb("rates_json").$type<WorkTypeRate[]>().notNull(),
  lastBackupAt: text("last_backup_at").default(""),
  firebaseSyncStatus: text("firebase_sync_status").notNull().default("SYNCED"),
  googleMapsApiKey: text("google_maps_api_key").notNull().default(""),
});
